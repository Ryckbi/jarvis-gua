@echo off
rem Double-click this file. It installs MARK LVII and opens it with no console.
call "%~dp0install\install.bat"
