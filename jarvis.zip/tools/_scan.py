import pathlib, re
p = 'core/gemini.py'
s = pathlib.Path(p).read_text(encoding='utf-8', errors='replace')
for i, line in enumerate(s.splitlines(), 1):
    t = line.strip()
    if t.startswith('def ') or t.startswith('FAST') or t.startswith('SMART') or t.startswith('MINI'):
        print(i, t[:100])
print('---match_forecast defs---')
s2 = pathlib.Path('plugins/match_forecast.py').read_text(encoding='utf-8', errors='replace')
for i, line in enumerate(s2.splitlines(), 1):
    if line.strip().startswith('def '):
        print(i, line.strip()[:90])
