"""tools/check_hush.py — measure the "diem" gate before trusting it.

Run:  python tools/check_hush.py [--voice path/to/model.onnx]

WHY THIS EXISTS
    The reported bug was "it goes quiet, then wakes up again before I say the
    name". Fixing that blind is how it got broken in the first place, so every
    threshold here is measured rather than guessed.

WHAT IT DOES
    Feeds real speech through the real HushGate and counts two things:

      false wake   quiet was asked for, nobody said the name, and it woke up.
                   This is the bug. It must be zero.
      missed name  the name was said, alone, and nothing happened.
                   The other way to fail, and just as bad.

    Sources of speech, best first:
      1. A Piper voice model, if one is present (`--voice` or the default path).
         This is speech-shaped audio with real formants, fricatives and timing,
         produced by a neural TTS — close enough that a feature which survives
         it will survive a microphone.
      2. Synthetic tones shaped like words, used only when no voice model is
         available. Weaker, and it is labelled as such in the output, because a
         tone has no /s/ and no formants and will flatter any detector.

    The exact numbers printed at the end are what set SIBILANCE_MIN_S and
    COARSE_ACCEPT in core/hush.py.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import numpy as np  # noqa: E402

from core.hush import (HushGate, _pcm_level, matches_name,  # noqa: E402
                      matches_stop, sibilance_s)

SR = 16000
FRAME = 1024

# Words a real room contains, used to test false wakes. The name is deliberately
# NOT in this list for the "chatter" test: a name-shaped word buried in a
# sentence is a separate question, covered by the isolation rule.
CHATTER = ["diem", "musik", "oke", "hello", "biasa", "gimana", "keren", "buka",
           "stop", "matikan"]

DEFAULT_VOICES = [
    Path("/tmp/tts/en_US-lessac-medium.onnx"),
    Path("/tmp/tts/en_US-ryan-medium.onnx"),
    Path("/tmp/tts/en_GB-alan-medium.onnx"),
    Path("/tmp/tts/en_US-amy-medium.onnx"),
]


# ── speech sources ──────────────────────────────────────────────────────────
def piper_say(model: Path, text: str, out: Path) -> np.ndarray | None:
    """One utterance from a Piper voice model, int16 at 16 kHz."""
    try:
        r = subprocess.run(
            [sys.executable, "-m", "piper", "-m", str(model), "-f", str(out)],
            input=text, capture_output=True, text=True)
        if r.returncode != 0:
            return None
        import wave
        with wave.open(str(out)) as w:
            sr = w.getframerate()
            x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
        x = np.asarray(x, dtype=np.float32)
        if x.ndim > 1:
            x = x[:, 0]
        if sr != SR:
            n = int(len(x) * SR / sr)
            x = np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x)
        # Trim leading/trailing quiet so the word stands alone, as it would
        # when someone addresses the assistant. The threshold is low on
        # purpose: the /s/ at the end of the name is a quiet fricative, and a
        # 7% cut removed the very part of the word the gate looks for.
        peak = np.abs(x).max() or 1.0
        loud = np.where(np.abs(x) > peak * 0.02)[0]
        if len(loud):
            x = x[max(0, loud[0] - 200):min(len(x), loud[-1] + 200)]
        return x
    except Exception:
        return None


def tone_word(env, f0, dur, amp=9000, rng=None):
    rng = rng or np.random.default_rng(0)
    n = int(SR * dur)
    t = np.arange(n) / SR
    sig = sum(a * np.sin(2 * np.pi * f0 * k * t) / k
              for k, a in ((1, 1.0), (2, 0.5), (3, 0.3)))
    e = np.interp(np.linspace(0, 1, n), np.linspace(0, 1, len(env)), env)
    return (sig * e * amp + rng.normal(0, 0.06 * amp, n)).astype(np.int16)


TONE_ENV = {
    "jarvis": ([0.25, 0.30, 0.28, 0.20, 0.19], 150, 0.55),
    "diem":   ([0.34, 0.36, 0.20, 0.10, 0.09], 150, 0.50),
    "musik":  ([0.30, 0.34, 0.26, 0.18, 0.14], 160, 0.55),
    "oke":    ([0.32, 0.36, 0.22, 0.14, 0.10], 180, 0.42),
    "hello":  ([0.28, 0.30, 0.26, 0.22, 0.16], 200, 0.55),
}


def silence(seconds: float) -> np.ndarray:
    return np.zeros(int(SR * seconds), dtype=np.int16)


def to_int16(x: np.ndarray, level: float = 9000.0) -> np.ndarray:
    y = np.asarray(x, dtype=np.float32)
    y = y / (np.abs(y).max() or 1.0) * level
    return y.astype(np.int16)


# ── harness ─────────────────────────────────────────────────────────────────
def run(parts, grace=0.0, settle=1.2, kind="name"):
    hits = []
    logs = []
    gate = HushGate(lambda: hits.append(time.monotonic()), kind=kind,
                    level_of=_pcm_level, logger=logs.append, grace_s=grace)
    gate.start()
    x = np.concatenate(parts) if parts else silence(0)
    for i in range(0, max(0, len(x) - FRAME), FRAME):
        gate.feed(x[i:i + FRAME, None])
    time.sleep(settle)
    gate.stop()
    return len(hits), gate, logs


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--voice", action="append", default=None,
                    help="Path to a Piper .onnx voice model (repeatable)")
    args = ap.parse_args()

    voices = [Path(v) for v in args.voice] if args.voice else DEFAULT_VOICES
    voices = [v for v in voices if v.exists()]
    tmp = Path(tempfile.mkdtemp())

    words: dict[str, np.ndarray] = {}
    if voices:
        print(f"Using {len(voices)} Piper voice(s) — real speech-shaped audio.")
        for vi, model in enumerate(voices):
            for w in ["jarvis", "atlas"] + CHATTER:
                x = piper_say(model, w.capitalize() + ".", tmp / f"{vi}_{w}.wav")
                if x is not None:
                    words.setdefault(w, []).append(to_int16(x))
    else:
        print("No Piper voice model found — falling back to TONE audio.")
        print("  Tones have no /s/ and no formants: treat these numbers as a")
        print("  sanity check, not as evidence about a real microphone.\n")
        rng = np.random.default_rng(0)
        for w, (env, f0, d) in TONE_ENV.items():
            words[w] = [tone_word(env, f0, d, rng=rng)]

    if "jarvis" not in words:
        print("Could not produce the name — nothing to test.")
        return 1

    name = words["jarvis"][0]
    failures = []

    def check(label, expect_wake, parts, **kw):
        n, gate, _ = run(parts, **kw)
        ok = (n > 0) == expect_wake
        detail = f"score {gate.last_score:.2f}"
        if gate.last_reject:
            detail += f", reject '{gate.last_reject}'"
        print(f"  {'PASS' if ok else 'FAIL'}  {label}: fired {n}x ({detail})")
        if not ok:
            failures.append(label)

    print("\nThe name, alone after a pause — must wake:")
    for i, nv in enumerate(words["jarvis"][:4]):
        check(f"  voice {i + 1}", True, [silence(0.6), nv, silence(0.7)])

    print("\nRight after 'diem' — must stay quiet, tail included:")
    for grace in (2.0, 1.5):
        check(f"  grace {grace}s", False,
              [silence(0.6), words["diem"][0], silence(0.05),
               words["jarvis"][0][-3000:], silence(0.8)], grace=grace)

    print("\nRoom chatter — must stay quiet:")
    rng = np.random.default_rng(4)
    talk = [silence(0.6)]
    for _ in range(10):
        for w in rng.permutation(CHATTER):
            pool = words.get(w)
            if not pool:
                continue
            talk += [pool[int(rng.integers(len(pool)))],
                     silence(float(rng.uniform(0.04, 0.18)))]
    talk.append(silence(0.8))
    check("  10 rounds of mixed words", False, talk)

    print("\nThe second name ('atlas') — must wake too:")
    for i, nv in enumerate(words.get("atlas", [])[:4]):
        check(f"  atlas voice {i + 1}", True, [silence(0.6), nv, silence(0.7)])

    print("\nThe name twice — one wake-up, not two:")
    # 0.35 s apart: a real repeated address, and longer than the 0.30 s pause
    # that separates one utterance from the next. Closer than that the two
    # merge into one 1.1 s utterance and are correctly rejected as a phrase.
    n, _, _ = run([silence(0.6), name, silence(0.35), name, silence(0.8)])
    print(f"  {'PASS' if n == 1 else 'FAIL'}  fired {n}x")
    if n != 1:
        failures.append("double address")

    print("\nQuiet mode is the button now — nothing spoken may arm it:")
    # The stop gate is gone on purpose. Its whole job was to detect "diem"
    # through the speakers, which cannot be done reliably: the assistant's own
    # playback and the user's word are the same sound through the same
    # microphone. This asserts the removal, so a future edit that quietly adds
    # it back fails here instead of in the user's living room.
    src = open(os.path.join(ROOT, "main.py"), encoding="utf-8").read()
    leftover = [n for n in ("_feed_stop_gate", "_start_stop_gate_soon",
                            "_speaks_stop_word", "_stop_gate")
                if n in src]
    print(f"  {'PASS' if not leftover else 'FAIL'}  no stop gate in main.py"
          + (f"  ({leftover})" if leftover else ""))
    if leftover:
        failures.append("stop gate code returned")

    hush_src = open(os.path.join(ROOT, "actions", "hush.py"),
                    encoding="utf-8").read()
    refused = ("quiet mode is the DIEM button" in hush_src and
               "return outcome.failed" in hush_src)
    print(f"  {'PASS' if refused else 'FAIL'}  hush tool refuses to arm quiet")
    if not refused:
        failures.append("hush tool can still go quiet")

    print("\nMeasurements that set the thresholds:")
    for w, pool in words.items():
        sib = [sibilance_s(p) for p in pool]
        nm = [matches_name(p) for p in pool]
        st = [matches_stop(p) for p in pool]
        print(f"  {w:8s} /s/ {min(sib):.2f}-{max(sib):.2f}  "
              f"name {max(nm):.2f}  stop {max(st):.2f}")

    print()
    if failures:
        print("FAILED:", ", ".join(failures))
        return 1
    print("All gate checks passed.")
    shutil.rmtree(tmp, ignore_errors=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
