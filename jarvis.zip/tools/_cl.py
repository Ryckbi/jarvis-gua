p = 'plugins/parlay.py'
s = open(p, encoding='utf-8', newline='').read()

a = s.index('def _leg_item(leg: dict) -> dict:')
b = s.index('def _leg_item_full(p: dict, leg: dict) -> dict:')
s = s[:a] + s[b:]

assert '_split_values' not in s
open(p, 'w', encoding='utf-8', newline='').write(s)
print('cleaned', len(s), 'chars left')
