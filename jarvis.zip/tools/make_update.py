"""
tools/make_update.py — build the next numbered update ZIP.

WHY NUMBERS
    Two files called MARK-LVII-update.zip, one downloaded last week and one
    today, are indistinguishable in a Downloads folder. So every package now
    carries a number in its name and on the first line of its own read-me:
    MARK-LVII-update-001.zip, -002.zip, and so on, never reusing a number.

HOW IT WORKS
    `update/` is the staging folder: it mirrors the project layout with only
    the files that changed, plus the read-me body. This script
    1. finds the highest number already in the project root,
    2. copies every staged file in, unchanged,
    3. writes BACA-UPDATE.txt with an "UPDATE #NNN — date" header,
    4. writes MARK-LVII-update-NNN.zip and prints what went in.

    Run it from the project root:

        /tmp/venv/bin/python tools/make_update.py
        /tmp/venv/bin/python tools/make_update.py --note "fixes the news default"

    It never overwrites an existing package: if the number it computed is
    already on disk it stops rather than replacing a file the user may have.
"""
from __future__ import annotations

import argparse
import re
import sys
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STAGE = ROOT / "update"
PATTERN = re.compile(r"^MARK-LVII-update-(\d{3})\.zip$")
README = "BACA-UPDATE.txt"


def next_number() -> int:
    used = []
    for p in ROOT.iterdir():
        m = PATTERN.match(p.name)
        if m:
            used.append(int(m.group(1)))
    return (max(used) + 1) if used else 1


def staged_files() -> list[Path]:
    """Everything in update/, read-me body included, minus stale build output."""
    files = [
        p for p in sorted(STAGE.rglob("*"))
        if p.is_file()
        and p.suffix != ".zip"
        # Byte-compiled leftovers are not source, differ per machine, and were
        # once shipped by accident: the check must exclude the FOLDER, which
        # `p.parts` does — a test of `p.name` would only catch the directory
        # itself, and rglob yields files.
        and "__pycache__" not in p.parts
        and p.suffix not in (".pyc", ".pyo")
        and not p.name.startswith(".")
    ]
    if not files:
        sys.exit(f"nothing staged in {STAGE}/ — nothing to build")
    return files


def readme_body() -> str:
    src = STAGE / README
    if not src.exists():
        return "UPDATE MARK LVII\n================\n"
    return src.read_text(encoding="utf-8")


def build(number: int, note: str) -> Path:
    out = ROOT / f"MARK-LVII-update-{number:03d}.zip"
    if out.exists():
        sys.exit(f"{out.name} already exists — refusing to replace it")

    header = (
        f"UPDATE MARK LVII  —  #{number:03d}\n"
        f"dibuat {datetime.now().strftime('%d %b %Y %H:%M')}\n"
        + (f"catatan: {note}\n" if note else "")
        + "=" * 60 + "\n"
    )
    body = readme_body()
    # Drop the plain title the body starts with; the header above replaces it.
    lines = body.splitlines()
    if lines and lines[0].strip().upper().startswith("UPDATE MARK LVII"):
        lines = lines[1:]
    while lines and not lines[0].strip():
        lines.pop(0)
    body = "\n".join(lines)

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr(README, header + body)
        for p in staged_files():
            if p.name == README:
                continue
            z.write(p, p.relative_to(STAGE).as_posix())
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description="Build the next numbered update ZIP.")
    ap.add_argument("--note", default="", help="one line shown in the read-me header")
    args = ap.parse_args()

    number = next_number()
    out = build(number, args.note.strip())
    with zipfile.ZipFile(out) as z:
        names = z.namelist()
        bad = z.testzip()
    print(f"built  {out.name}  ({out.stat().st_size / 1024:.0f} KB, {len(names)} files)")
    if bad:
        sys.exit(f"archive is corrupt at {bad}")
    for n in names:
        print("   ", n)


if __name__ == "__main__":
    main()
