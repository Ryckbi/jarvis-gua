#!/bin/sh
cd /home/ubuntu/project || exit 1
python3 -m py_compile plugins/parlay.py && echo COMPILES_OK
