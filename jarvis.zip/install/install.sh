#!/bin/sh
# One-click installer for Linux. Right-click -> Properties -> allow executing,
# or run:  sh install/install.sh
set -e
cd "$(dirname "$0")/.." || exit 1
ROOT="$(pwd)"

echo "MARK LVII installer — $ROOT"

PY=""
for c in python3.12 python3.11 python3; do
    if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
    echo "Python 3.11+ not found. Install python3 and try again."
    exit 1
fi

if [ ! -x ".venv/bin/python" ]; then
    echo "Creating private environment..."
    "$PY" -m venv .venv
fi

echo "Installing dependencies (this takes a few minutes)..."
./.venv/bin/python -m pip install --upgrade pip --quiet
./.venv/bin/python -m pip install -r requirements.txt --quiet
./.venv/bin/python -m playwright install chromium >/dev/null 2>&1 || true

echo "Creating the launcher and shortcut..."
./.venv/bin/python install/make_shortcut.py --root "$ROOT"

echo "Starting MARK LVII..."
nohup ./.venv/bin/python main.py >/dev/null 2>&1 &
echo "Done. Double-click 'MARK LVII' on your desktop, or find it in the app menu."
