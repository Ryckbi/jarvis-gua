"""
install/make_shortcut.py — desktop and Start-menu shortcuts, no console window.

Run by install.bat on Windows and by install.sh on Linux/macOS, and safe to run
again at any time.

  Windows : .lnk pointing at pythonw.exe (so no console appears) + the reactor
            icon, on the Desktop and in the Start menu.
  Linux   : a .desktop entry in ~/.local/share/applications and on the Desktop,
            launching through a tiny no-terminal wrapper.
  macOS   : a .command-free launcher is worse than offering the real thing, so a
            proper .app bundle is built with an executable inside — double-click
            and no Terminal opens.

This file runs on the *base* Python that install.bat called, not from inside the
app, so it avoids importing anything from the project.
"""
from __future__ import annotations

import argparse
import os
import stat
import subprocess
import sys
from pathlib import Path

APP_NAME = "MARK LVII"


def _desktop_dir() -> Path:
    home = Path.home()
    win = home / "Desktop"
    if sys.platform == "win32":
        # A relocated Desktop (OneDrive) is read from the registry; falling back
        # to %USERPROFILE%\Desktop would put the icon somewhere invisible.
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders")
            val, _ = winreg.QueryValueEx(key, "Desktop")
            return Path(os.path.expandvars(val))
        except Exception:
            return win
    for name in ("Desktop", "Escritorio", "Schreibtisch", "Bureau"):
        p = home / name
        if p.is_dir():
            return p
    return win


def _ico(root: Path) -> Path:
    return root / "config" / "jarvis.ico"


# ── Windows ──────────────────────────────────────────────────────────────────

def windows_shortcuts(root: Path, pythonw: str) -> None:
    lnk_script = (
        "import sys\n"
        "try:\n"
        "    import win32com.client as w\n"
        "except Exception as e:\n"
        "    print('pywin32 missing:', e); sys.exit(2)\n"
        "shell = w.Dispatch('WScript.Shell')\n"
        "target, workdir, icon, lnk = sys.argv[1:5]\n"
        "s = shell.CreateShortCut(lnk)\n"
        "s.TargetPath = target\n"
        "s.Arguments = denv = sys.argv[5] if len(sys.argv) > 5 else ''\n"
        "s.WorkingDirectory = workdir\n"
        "s.IconLocation = icon\n"
        "s.WindowStyle = 7\n"          # 7 = minimised: no flash of a console
        "s.Description = 'MARK LVII personal AI assistant'\n"
        "s.Save()\n"
    )
    script = root / "install" / "_lnk.py"
    script.write_text(lnk_script, encoding="utf-8")

    exe = pythonw if Path(pythonw).exists() else sys.executable
    main_py = str(root / "main.py")
    icon = str(_ico(root)) if _ico(root).exists() else f"{exe},0"

    targets = [_desktop_dir() / f"{APP_NAME}.lnk"]
    start = Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / \
        "Start Menu" / "Programs"
    if start.exists():
        targets.append(start / f"{APP_NAME}.lnk")

    ok = 0
    for lnk in targets:
        r = subprocess.run(
            [sys.executable, str(script), exe, str(root), icon, str(lnk), main_py],
            capture_output=True, text=True, timeout=60,
        )
        if r.returncode == 0 and lnk.exists():
            ok += 1
            print(f"        shortcut: {lnk}")
        else:
            print(f"        [!] could not create {lnk}: "
                  f"{(r.stdout or r.stderr).strip()[:200]}")
    try:
        script.unlink()
    except OSError:
        pass
    if not ok:
        # A visible fallback is better than a silent failure: a .cmd that
        # launches pythonw is still one double-click and still no console.
        cmd = _desktop_dir() / f"{APP_NAME}.cmd"
        cmd.write_text(
            "@echo off\r\n"
            f'start "" "{exe}" "{main_py}"\r\n', encoding="utf-8")
        print(f"        fallback launcher: {cmd}")


# ── Linux ────────────────────────────────────────────────────────────────────

def linux_shortcuts(root: Path) -> None:
    wrapper = root / "install" / "launch.sh"
    wrapper.write_text(
        "#!/bin/sh\n"
        f'cd "{root}"\n'
        'PY=""\n'
        f'[ -x "{root}/.venv/bin/python" ] && PY="{root}/.venv/bin/python"\n'
        '[ -z "$PY" ] && PY="$(command -v python3)"\n'
        'exec "$PY" "' + str(root / "main.py") + '" "$@"\n',
        encoding="utf-8",
    )
    wrapper.chmod(wrapper.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    icon = root / "config" / "jarvis.ico"
    entry = (
        "[Desktop Entry]\n"
        "Type=Application\n"
        f"Name={APP_NAME}\n"
        "Comment=Personal AI assistant\n"
        f"Exec={wrapper}\n"
        f"Path={root}\n"
        f"Icon={icon}\n"
        "Terminal=false\n"
        "Categories=Utility;\n"
    )
    apps = Path.home() / ".local" / "share" / "applications"
    apps.mkdir(parents=True, exist_ok=True)
    target = apps / "mark-lvii.desktop"
    target.write_text(entry, encoding="utf-8")
    target.chmod(0o755)

    desk = _desktop_dir() / "mark-lvii.desktop"
    try:
        desk.write_text(entry, encoding="utf-8")
        desk.chmod(0o755)
        print(f"        shortcut: {desk}")
    except OSError:
        pass
    print(f"        launcher: {target}")


# ── macOS ────────────────────────────────────────────────────────────────────

def mac_bundle(root: Path) -> None:
    app = _desktop_dir() / f"{APP_NAME}.app"
    macos = app / "Contents" / "MacOS"
    macos.mkdir(parents=True, exist_ok=True)
    exe = macos / "MARKLVII"
    py = root / ".venv" / "bin" / "python"
    exe.write_text(
        "#!/bin/sh\n"
        f'cd "{root}"\n'
        f'exec "{py if py.exists() else "python3"}" "{root / "main.py"}"\n',
        encoding="utf-8",
    )
    exe.chmod(0o755)
    (app / "Contents" / "Info.plist").write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
        '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
        '<plist version="1.0"><dict>'
        f'<key>CFBundleName</key><string>{APP_NAME}</string>'
        '<key>CFBundleExecutable</key><string>MARKLVII</string>'
        '<key>CFBundleIdentifier</key><string>com.mark.lvii</string>'
        '<key>CFBundlePackageType</key><string>APPL</string>'
        '</dict></plist>\n', encoding="utf-8")
    print(f"        app bundle: {app}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(Path(__file__).resolve().parent.parent))
    ap.add_argument("--python", default="", help="pythonw.exe to target (Windows)")
    args = ap.parse_args()
    root = Path(args.root).resolve()

    print(f"        platform: {sys.platform}, root: {root}")
    try:
        if sys.platform == "win32":
            windows_shortcuts(root, args.python)
        elif sys.platform == "darwin":
            mac_bundle(root)
        else:
            linux_shortcuts(root)
    except Exception as e:
        print(f"        [!] shortcut step failed: {e}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
