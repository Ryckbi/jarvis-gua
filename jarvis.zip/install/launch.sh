#!/bin/sh
cd "/home/ubuntu/project"
PY=""
[ -x "/home/ubuntu/project/.venv/bin/python" ] && PY="/home/ubuntu/project/.venv/bin/python"
[ -z "$PY" ] && PY="$(command -v python3)"
exec "$PY" "/home/ubuntu/project/main.py" "$@"
