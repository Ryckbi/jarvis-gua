@echo off
setlocal EnableDelayedExpansion
title MARK LVII - Installer

rem ─────────────────────────────────────────────────────────────────────────────
rem  One-click installer. Double-click this file; it does everything:
rem    1. finds a supported Python
rem    2. creates a private .venv inside this folder (nothing global is touched)
rem    3. installs the requirements into it
rem    4. creates a desktop and Start-menu shortcut that opens MARK with no
rem       console window, using the reactor icon
rem    5. launches it
rem
rem  Re-running it is safe: existing steps are skipped, so it doubles as a
rem  repair tool.
rem ─────────────────────────────────────────────────────────────────────────────

cd /d "%~dp0.."
set "ROOT=%CD%"
set "VENV=%ROOT%\.venv"
set "PYEXE=%VENV%\Scripts\python.exe"
set "PYWEXE=%VENV%\Scripts\pythonw.exe"

echo.
echo   ==========================================================
echo      MARK LVII  -  one-click install
echo      folder: %ROOT%
echo   ==========================================================
echo.

rem ── 1. find Python ──────────────────────────────────────────────────────────
set "BOOTPY="
py -3.12 -c "import sys" >nul 2>&1 && set "BOOTPY=py -3.12"
if not defined BOOTPY py -3.11 -c "import sys" >nul 2>&1 && set "BOOTPY=py -3.11"
if not defined BOOTPY py -3 -c "import sys" >nul 2>&1 && set "BOOTPY=py -3"
if not defined BOOTPY python -c "import sys" >nul 2>&1 && set "BOOTPY=python"

if not defined BOOTPY (
    echo   [X] Python was not found on this PC.
    echo.
    echo       Install Python 3.11 or newer from https://python.org/downloads
    echo       During setup tick "Add python.exe to PATH", then run this again.
    echo.
    pause
    exit /b 1
)

for /f "delims=" %%v in ('%BOOTPY% -c "import sys;print(sys.version.split()[0])"') do set "PYVER=%%v"
echo   [1/5] Python %PYVER% found.

rem ── 2. virtual environment ─────────────────────────────────────────────────
if exist "%PYEXE%" (
    echo   [2/5] Existing environment reused.
) else (
    echo   [2/5] Creating a private environment in .venv ...
    %BOOTPY% -m venv "%VENV%"
    if errorlevel 1 (
        echo   [X] Could not create the environment. Is "venv" available?
        pause
        exit /b 1
    )
)

rem ── 3. dependencies ────────────────────────────────────────────────────────
echo   [3/5] Installing dependencies (this is the slow part) ...
"%PYEXE%" -m pip install --upgrade pip --quiet --disable-pip-version-check
"%PYEXE%" -m pip install -r "%ROOT%\requirements.txt" --quiet --disable-pip-version-check
if errorlevel 1 (
    echo.
    echo   [X] Dependency installation failed.
    echo       Check your internet connection and run this installer again.
    echo.
    pause
    exit /b 1
)
echo         Dependencies installed.

rem ── 3b. browser automation, optional ───────────────────────────────────────
"%PYEXE%" -m playwright install chromium --with-deps >nul 2>&1
if errorlevel 1 (
    echo         [!] Browser automation was skipped - everything else works.
)

rem ── 4. shortcuts ───────────────────────────────────────────────────────────
echo   [4/5] Creating shortcuts ...
"%PYEXE%" "%ROOT%\install\make_shortcut.py" --root "%ROOT%" --python "%PYWEXE%"
if errorlevel 1 (
    echo         [!] Shortcut creation reported a problem - see the message above.
)

rem ── 5. launch ──────────────────────────────────────────────────────────────
echo   [5/5] Starting MARK LVII ...
if exist "%PYWEXE%" (
    start "" "%PYWEXE%" "%ROOT%\main.py"
) else (
    start "" "%PYEXE%" "%ROOT%\main.py"
)

echo.
echo   Done. MARK LVII is starting with no console window.
echo   A shortcut named "MARK LVII" is on your Desktop.
echo.
timeout /t 4 >nul
endlocal
exit /b 0
