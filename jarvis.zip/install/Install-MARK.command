#!/bin/sh
# One-click installer for macOS. Double-click in Finder.
# (macOS may need one right-click -> Open the first time, because the file is
#  not notarised. After that a double-click works.)
cd "$(dirname "$0")/.." || exit 1
ROOT="$(pwd)"

echo "MARK LVII installer — $ROOT"

PY=""
for c in python3.12 python3.11 python3; do
    if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
    echo "Python 3.11+ not found. Install it from https://python.org and try again."
    read -r _
    exit 1
fi

if [ ! -x ".venv/bin/python" ]; then
    echo "Creating private environment..."
    "$PY" -m venv .venv || { echo "venv failed"; read -r _; exit 1; }
fi

echo "Installing dependencies (this takes a few minutes)..."
./.venv/bin/python -m pip install --upgrade pip --quiet
./.venv/bin/python -m pip install -r requirements.txt --quiet || {
    echo "Dependency install failed — check your internet connection."
    read -r _
    exit 1
}
./.venv/bin/python -m playwright install chromium >/dev/null 2>&1 || true

echo "Creating the app icon..."
./.venv/bin/python install/make_shortcut.py --root "$ROOT"

echo "Starting MARK LVII..."
nohup ./.venv/bin/python main.py >/dev/null 2>&1 &
echo "Done. 'MARK LVII' is on your Desktop."
sleep 2
