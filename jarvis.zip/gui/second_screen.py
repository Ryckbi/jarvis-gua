"""
gui/second_screen.py — MARK on two displays at once.

WHAT THIS IS, AND WHAT IT IS NOT
    Not a second copy of the app. One assistant, one voice, one conversation:
    two full HUDs would fight over the microphone, the wake word and the
    session, and the user would hear everything twice.

    It is a companion panel — a small always-on-top window, on the display the
    main HUD is NOT on, that shows what is happening while the user is looking
    somewhere else:

        STATE      idle / listening / thinking / speaking, as one calm line
        LAST LINE  the most recent thing MARK said, wrapped
        NOW        whatever the content panel is showing (news, football,
                   code job…), first few lines only

    That is the part people actually want on the second monitor: the state and
    the last answer, visible from across the desk, without stealing a screen
    from the game.

WHY A QWidget AND NOT A SECOND WINDOW CLASS
    Same reason the football pop-out is one: borderless, draggable, always on
    top, no taskbar entry, no focus stealing. It is a child of nothing, owned
    by the main window, and closes with it.

HOW IT STAYS CHEAP
    It repaints only when the text it shows actually changes. The main window
    calls update_state()/update_line()/update_content(), each of which diffs
    first. Idle cost is one small window compositing nothing.
"""
from __future__ import annotations

from PyQt6.QtCore import QRectF, Qt
from PyQt6.QtGui import QColor, QFont, QPainter, QPen
from PyQt6.QtWidgets import QWidget

from gui.theme import C, qcol

_W_UNITS = 300            # base width in HUD units; scaled by the caller
_PAD = 14


class SecondScreenPanel(QWidget):
    """The companion display window. Created once, shown on demand."""

    def __init__(self, name: str = "JARVIS", parent=None):
        super().__init__(None)
        self.setWindowFlags(
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        self._name = (name or "JARVIS").upper()
        self._state = "IDLE"
        self._line = ""
        self._content_title = ""
        self._content = ""
        self._drag = None

        self.resize(_W_UNITS, 190)

    # ── data ────────────────────────────────────────────────────────────────
    def update_state(self, state: str) -> None:
        state = (state or "IDLE").upper()
        if state == self._state:
            return
        self._state = state
        self.update()

    def update_line(self, text: str) -> None:
        text = " ".join(str(text or "").split())
        if text == self._line:
            return
        self._line = text
        self.update()

    def update_content(self, title: str, text: str) -> None:
        title = str(title or "").strip()
        text = str(text or "").strip()
        if title == self._content_title and text == self._content:
            return
        self._content_title = title
        self._content = text
        self.update()

    def set_assistant_name(self, name: str) -> None:
        name = (name or "JARVIS").upper()
        if name != self._name:
            self._name = name
            self.update()

    # ── placement ───────────────────────────────────────────────────────────
    def place_on(self, screen) -> None:
        """Put it in the top-right corner of `screen`, inset a little.

        A corner rather than centre: the point of this window is to be readable
        at a glance without covering the middle of whatever is running there.
        """
        if screen is None:
            return
        geo = screen.availableGeometry()
        scale = max(1.0, geo.height() / 1080.0)
        w = int(_W_UNITS * 1.6)
        h = int(190 * scale * 1.1)
        x = geo.x() + geo.width() - w - int(28 * scale)
        y = geo.y() + int(28 * scale)
        self.resize(w, h)
        self.move(x, y)

    # ── painting ────────────────────────────────────────────────────────────
    def _font(self, px: int, bold: bool = False, mono: bool = False) -> QFont:
        f = QFont("Consolas" if mono else "Segoe UI")
        f.setPixelSize(max(8, px))
        f.setWeight(QFont.Weight.Bold if bold else QFont.Weight.Normal)
        return f

    def paintEvent(self, _e) -> None:
        p = QPainter(self)
        if not p.isActive():
            return
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        W, H = self.width(), self.height()

        bg = QColor(7, 11, 16, 228)
        p.setPen(QPen(qcol(C.PRI), 1.2))
        p.setBrush(bg)
        p.drawRoundedRect(QRectF(0.8, 0.8, W - 1.6, H - 1.6), 10, 10)

        # corner ticks, the same language as the HUD's frame
        p.setPen(QPen(qcol(C.PRI), 1.6))
        for sx, sy in ((0, 0), (1, 0), (0, 1), (1, 1)):
            x = 2 if sx == 0 else W - 2
            y = 2 if sy == 0 else H - 2
            arm = 12
            p.drawLine(x, y, x + (arm if sx == 0 else -arm), y)
            p.drawLine(x, y, x, y + (arm if sy == 0 else -arm))

        x0, y0 = _PAD, _PAD
        inner_w = W - _PAD * 2

        # header: name + state
        p.setFont(self._font(13, bold=True))
        p.setPen(QPen(qcol(C.WHITE)))
        p.drawText(QRectF(x0, y0, inner_w * 0.55, 18),
                   Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, self._name)

        state_col = qcol(C.PRI)
        if self._state in ("THINKING", "PROCESSING", "QUIET"):
            state_col = qcol(C.ACC)
        elif self._state == "SPEAKING":
            state_col = qcol(C.GREEN)
        p.setFont(self._font(11, bold=True))
        p.setPen(QPen(state_col))
        # "quiet" is true but reads like "off". Say what it is waiting for,
        # since the whole point is that the assistant is still listening.
        shown = ("menunggu jarvis / atlas" if self._state.upper() == "QUIET"
                 else self._state.lower())
        p.drawText(QRectF(x0, y0, inner_w, 18),
                   Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                   shown)

        y = y0 + 26
        p.setPen(QPen(QColor(255, 255, 255, 26), 1))
        p.drawLine(x0, y, x0 + inner_w, y)
        y += 10

        # last spoken line
        if self._line:
            p.setFont(self._font(11))
            p.setPen(QPen(QColor(226, 238, 245, 235)))
            rect = QRectF(x0, y, inner_w, 58)
            flags = int(Qt.TextFlag.TextWordWrap | Qt.AlignmentFlag.AlignLeft
                        | Qt.AlignmentFlag.AlignTop)
            p.drawText(rect, flags, self._line[:260])
            y += 62

        # content block
        if self._content_title or self._content:
            p.setFont(self._font(9, bold=True))
            p.setPen(QPen(qcol(C.TEXT_DIM)))
            p.drawText(QRectF(x0, y, inner_w, 14),
                       Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                       (self._content_title or "CONTENT")[:40].upper())
            y += 17
            p.setFont(self._font(10))
            p.setPen(QPen(QColor(200, 214, 222, 210)))
            room = max(14.0, H - y - _PAD)
            p.drawText(QRectF(x0, y, inner_w, room),
                       int(Qt.TextFlag.TextWordWrap | Qt.AlignmentFlag.AlignLeft
                           | Qt.AlignmentFlag.AlignTop),
                       self._content[:400])
        p.end()

    # ── dragging, so it can be put where the user wants ────────────────────
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._drag is not None and e.buttons() & Qt.MouseButton.LeftButton:
            self.move(e.globalPosition().toPoint() - self._drag)
            e.accept()

    def mouseReleaseEvent(self, e):
        self._drag = None
        e.accept()
