# Rules for coding agents working on JARVIS

The built-in coding agent (`actions/dev_agent.py`) reads this file before every
change it makes to this project, and so should any other agent or contributor.
Each rule below exists because breaking it produced code that looked right,
passed a syntax check and did nothing when used.

## How the app runs

- `main.py` holds the voice session on an asyncio event loop in a background
  thread. The window — the `gui/` package, built by `ui.py` — lives on the
  **Qt main thread**.
- Tools — `actions/*.py` and `plugins/*.py` — run on **worker threads**, never
  on the Qt main thread.
- There is exactly **one** `QApplication`, created by `ui.py`.
- Long work the user asks for in the background — research, drafting — is the
  task engine's job (`core/tasks/`, agents in `agents/*.md`), not a plugin's.

## Threading: the rule that breaks most generated code

Code in `actions/` and `plugins/` must **never create or touch a Qt widget**.
That means no `QApplication`, `QWidget`, `QMainWindow`, `QDialog`, `QThread` or
anything else from `PyQt6.QtWidgets` or `PyQt6.QtGui`. Creating a widget from a
worker thread prints `QObject::setParent: Cannot set parent, new parent is in a
different thread` and nothing appears on screen.

To show something, call the **thread-safe methods on `player`** (the `JarvisUI`
object passed to every tool). They hand the work to the Qt thread for you. The
current list, with signatures, is appended below this file by the coding agent
automatically. The ones plugins usually need:

| Need | Call |
|---|---|
| A line in the activity log | `player.write_log("text")` |
| Text in the panel under the head | `player.show_content(title, text)` |
| A quiz the user answers on screen | `player.show_quiz(topic, questions, grade=None)` |
| A structured review | `player.show_review(title, summary, findings)` |
| Play a video in the HUD | `player.show_video(path_or_url, title)` |

`show_quiz` takes `questions` as a list of dicts:
`{"question": str, "options": [str, ...] (empty list for a typed answer),
"answer": str, "note": str (shown after answering, optional)}`.
`grade(question, given) -> True | False | None` is optional; `None` means
"let the assistant judge this answer". The user answers at their own pace and
the result comes back to the conversation by itself — `run()` returns at once.

Do **not** start a separate GUI program (`subprocess` running a PyQt script)
to work around this rule. It hides every error from the user, and the app
already has a screen for it.

## Plugins

A plugin is one file `plugins/<name>.py` (no leading underscore) with:

- `PLUGIN = {"name": ..., "description": ..., "parameters": {"type": "OBJECT", ...}}`
- `def run(parameters: dict, player=None, session_memory=None) -> str`

`run()` must:

- return a **short string** — the assistant turns it into speech;
- **never raise** — catch errors and return a sentence saying what went wrong;
- return **within a few seconds** — put slow work on a `threading.Thread`
  and show its result through `player` when it is done;
- treat `player` as possibly `None` (tests and the phone dashboard).

Helper modules may live beside it with a leading underscore
(`plugins/_helper.py`); the loader skips those. See `plugins/_template.py`.

A new plugin is **enabled automatically** the moment its file exists — nothing
needs to be registered or switched on. Never edit `config/api_keys.json` to
"enable" one; that file holds the user's API keys and settings.

## Asking a model for something

Always go through `core.gemini` — it has deadlines, a fallback ladder and the
user's chosen provider:

```python
from core import gemini
text = gemini.text(prompt, tier=gemini.FAST)       # short answers
data = gemini.as_json(prompt, tier=gemini.SMART)    # structured, may return None
```

Every call can fail or return `None`. Code must handle that — for example with
a small built-in fallback — instead of crashing.

## Changing the window (`gui/`)

- The window is the `gui/` package: `window.py` (MainWindow — columns, drawers,
  content panel), `widgets.py`, `overlays.py`, `providers_panel.py`, `hud.py`.
  `ui.py` keeps only `JarvisUI` and re-exports every older name.
- Widgets are created and changed only on the Qt thread.
- To let other threads trigger a change: add a `pyqtSignal` to `MainWindow` in
  `gui/window.py`, connect it to a slot in its `__init__`, and add a thin public
  method on `JarvisUI` in `ui.py` that only emits the signal. `show_content` /
  `_content_sig` / `_show_content` is the pattern to copy.
- Colours come from the `C` palette in `gui/theme.py`; stylesheets use only its
  hex values, so the live re-theme can repaint them. Fonts come from
  `gui/style.py` — `hud_font(size)`, `mono_font(size)`, `px_font(px)` — never a
  hard-coded family.

## General

- Never send a child process's output to `DEVNULL` without logging it, and
  never report success without checking that the thing actually happened.
- Settings and keys live in `config/api_keys.json` through
  `memory/config_manager.py`; never write that file directly.
- Keep to the libraries already in `requirements.txt`.

## Mark LVIII additions (football forecast + one-click install)

- `core/football.py` computes match forecasts from ESPN's public soccer API
  (no key, ~220 competitions). It uses the **league standings endpoint**
  (`/apis/v2/sports/soccer/<slug>/standings`) as its strength input, NOT the
  per-club schedule endpoint — the latter costs one request per club and made a
  ten-match slate take 17s instead of 1.3s. Keep it that way.
- `plugins/match_forecast.py` is the voice/chat entry point. It is
  `NON_BLOCKING`: network work runs on a daemon thread and results reach the UI
  through `player.show_football(items)` (thread-safe signal emit).
- `gui/football_window.py` is a borderless always-on-top `QWidget`, **not** an
  overlay. It is created by `MainWindow._show_football` (Qt thread) and capped at
  10 cards. Refreshing goes pop-out → `_football_req_sig` → `MainWindow` →
  `ui.on_football_refresh` callback → worker thread. Never fetch on the Qt thread.
- Fixtures for *all* leagues come from one request per day against
  `/soccer/all/scoreboard?dates=YYYYMMDD&limit=1000` (226 matches on a normal
  Saturday), then are ranked so top-five leagues and continental cups fill the
  ten slots before youth/reserve fixtures.
- Liga Indonesia is **not** in ESPN's feed. Do not claim coverage; say so.
- `install/` holds the one-click installers: `INSTALL.cmd` (root, Windows) →
  `install/install.bat`; `install.sh` (Linux); `Install-MARK.command` (macOS).
  All three build a private `.venv`, then call `install/make_shortcut.py`, which
  creates a no-console shortcut (pythonw.exe on Windows, a `.desktop` with
  `Terminal=false` on Linux, an `.app` bundle on macOS). Keep shortcuts pointing
  at `pythonw.exe`/`.app` — a console window on launch is a reported bug.

## Voice / personality (do not regress this)

- `core/prompt.txt` `[WHO YOU ARE]` is the personality block: a friend their own
  age, opinionated, dry humour, honest about limits, no praise, no "anything
  else I can help with". It replaced an older "most experienced person in the
  room / trusted operator" voice that assumed a formal register.
- `main.py`'s identity injection no longer forces "sir". It used the
  respectful-for-a-superior form in every language, which fought the new voice
  and applied `[LANGUAGE]`-style rules to the address form. Now: the configured
  user name wins, otherwise a friend's casual address.
- Indonesian replies may code-switch English words in (that is how people talk).
  English replies stay English. `main.py` still saves
  `identity/language`, and `plugins/match_forecast.py` reads it via
  `_user_lang()` to pick which language its summaries are written in — do not
  try to guess language from a team name.
- `core/cloud.py` builds the Telegram prompt by swapping out `[SELF]` with a
  regex that stops at the next `[ALLCAPS]` heading. `[WHO YOU ARE]` matches that
  pattern, so it is not swallowed; keep new section headings in that style and
  re-run the probe if you rename one.
- The update ZIP is built from a staging folder `update/` (mirrors the project
  layout, plus `BACA-UPDATE.txt`) with Python's `zipfile` — there is no `zip`
  binary in this image. Never ship `dist/` (gitignored); the deliverable lives
  at the repo root as `MARK-LVII-update.zip` and is `git add`-ed so the
  workspace download button can hand it over.
- New bundled actions are discovered by `core/action_loader.py` from a module
  `TOOL` dict that MUST include `"handler": <callable>`; without it the file is
  skipped silently. `cpu_temp` follows this.
- CPU temperature is read live through `gui.metrics._metrics.live_temp()`
  (instance name is `_metrics`, not a `_SAMPLER`), falling back to
  `actions.system_monitor._get_cpu_temp`. Sensor-less machines get an honest
  failure, never a fabricated number.
- Update packages are numbered: `MARK-LVII-update-NNN.zip`, built by
  `tools/make_update.py` from the `update/` staging folder. Numbers only ever
  increase, the script refuses to overwrite an existing package, and each
  package is cumulative — the newest one replaces all earlier ones. The read-me
  inside carries the same number on its first line. Do not hand-name these.
- Display moving lives in `gui/window.py` (`_move_to_screen`, `_cycle_screen`,
  F12 + settings button) and `actions/display_control.py` for voice. Qt's
  screen list is 0-based, everything the user says is 1-based —
  `ui.move_to_screen()` converts once, and `cycle_screen()` steps in 0-based
  space before converting. Do not mix them again; that bug sent "the other
  screen" back to the same one.
- News is opt-in: `main.py` requires `options["news"] is True`, the seeded
  briefing and news_watch are created disabled, and
  `core/routines/desktop.migrate_defaults()` (ROUTINES_VERSION = 2) switches
  them off for existing installs — but only when the routine has no `edited`
  flag, so a user's own choice survives.
- CPU temperature has exactly one probe: `core/sensors.py`. The HUD sampler,
  `actions/cpu_temp` and `actions/system_monitor` all call it; never add a
  fourth copy. It reads psutil → Windows ACPI thermal zones (hottest plausible
  zone, not the first) → LibreHardwareMonitor HTTP on 8085/8086 → Linux hwmon,
  caches a reading for 3 s, and retries: a real exception cools a method down
  for 30 s, an empty-but-working method only 5 s. The old probe set
  `_wmi_ok = False` forever on one failure, which is why temperature stayed N/A
  for a whole session on machines that could report it.
- "Lighter" work that was done, so it is not re-added: HUD timer is 60 Hz while
  active and 40 ms when idle (`gui/hud.py` `_tmr_ms`); `TaskStore.recent(n)`
  copies only the newest n (the panel used to deep-copy every task every 2 s);
  `TaskRow.set_task` skips a repaint when nothing changed; the sampler refreshes
  GPU/temp every 2nd cycle.
- Update ZIPs must not contain `__pycache__` or `.pyc`; `tools/make_update.py`
  filters by `p.parts` and by suffix. It caught real leftovers once.
- The HUD core is cached in `gui/hud.py` `_paint_core_cached`: a pixmap keyed
  on size/colours/style/name/speaking/muted/state/coarse amp. Verified
  pixel-identical (0.18% differing px, max delta 2). Do not call
  `_paint_core_classic` directly from the paint path — that bypasses the cache.
- The HUD timer never stops: hidden/minimised crawls at 250 ms instead. Stopping
  it looked cheaper but would never restart on minimise (show() is not called),
  freezing the HUD. Active 16 ms, idle 40 ms.
- Second display is `gui/second_screen.py` — a status companion (state, last
  line, content), NOT a second HUD: one session, one mic. F10 / settings button /
  `display_control action=second`. Shown on the display the main window is not
  on; refused with one screen. `closeEvent` takes it down with the app.
- `LogWidget` types text only when `MARK_LVII_TYPE_LOG=1`; the per-character
  6 ms timer was real work for decoration.
- Screen capture now defaults to ALL monitors: `actions/screen_processor.py`
  `_capture_screen(which=0)` returns `(bytes, mime, caption)`; 0 = virtual
  desktop encompassing every screen, N = monitor N (1-based), out-of-range
  falls back to all. `screen_inventory()` lists displays for the vision
  prompt. The old code grabbed `monitors[1]` only — that was the "can't see my
  second screen" bug. The caption travels in the same user turn as the image
  (`[IMAGE SOURCE: SCREEN CAPTURE] — all N monitors…`), not only the tool result.
- Double chance is in the pop-out card (`gui/football_window.py`), the reasons
  (`core/football.py` step 6) and the spoken reply (`_best_dc`). Slate items
  carry `dc_1x`/`dc_12`/`dc_x2`.
- HUD cadence is adaptive: `paintEvent` records `_paint_ms`; `_step()` raises
  `_cadence_floor` after 6 slow frames and relaxes it 6 ms at a time when
  frames are cheap. Smooth-30 beats ragged-60 under load. Never stop the timer.
- Quiet ("diem") is a THIRD state, not mute/sleep: `core/hush.py` `HushGate`
  (kind="name"|"stop"); mic stays open, frames go only to the local matcher,
  nothing is streamed; name wakes. `STOP_ACCEPT=0.86` (strict, only while
  speaking — a false positive costs one truncated sentence), `COARSE_ACCEPT=0.82`.
  `actions/hush.py` is the tool; F9 / `_hush_btn` / `toggle_hush()`.
- Once called, awake until told to stop: `stay_awake` (default True) makes
  `_run_sleep_watch` skip the 2-minute timeout entirely.
- Gmail is IMAP + app password (`actions/gmail.py`), read-only, no OAuth.
  Actions can now declare `TOOL["settings"]`/`TOOL["test"]`;
  `ActionRegistry.settings_schemas()` returns the plugin-settings shape so one
  overlay draws both (`main.py` `_all_settings_schemas`). Email always wrapped
  in `[UNTRUSTED EMAIL CONTENT …]`.
- Football schedule vs forecast are two modes of one window:
  `core.football.schedule()` (fixtures only, one league or all, day range,
  noise filter for youth/college/friendly/women) vs `slate()` (10 max, with
  model numbers). Schedule draws `_ScheduleRow` + day headers and streams rows
  in via `_drain_pending` (~12/tick) — 600 rows paint in ~10 ms, 970 in ~90 ms/tick.
- `fixtures(league=...)` MUST fetch per day: the scoreboard endpoint rejects a
  date range with 400, and the old code only fetched today then filtered.
- Hush is enforced in three places, all needed: `_silence_now()` (drain queue
  TWICE + clear `_interrupted`), `_play_muted` checked in the play loop and in
  response.data, and `unhush` clearing `_interrupted`. Otherwise "diem" while
  silent leaves the flag set and the next post-"Jarvis" answer is discarded.
- Local "diem" detection only runs while speaking. Measured: "oke"/"bos" score
  within 0.02 of "diem" on energy shape, so an idle-path trigger would hush on
  "okay"; idle uses the model + `hush` tool instead.
- Over/under is FOUR lines (1.5/2.5/3.5/4.5), not one: `_market()` accumulates
  them in the grid walk and returns `over_lines`; `predict()` exposes
  `over_under` ({line: {over, under}}) plus a top-level `expected_goals`
  (a COUNT — never run it through `_pct`, that produced "290%"). `slate()`
  items carry `over_under` too; the card draws one chip per line with the
  closest-to-50 line in ACC.
- Match pop-outs: TWO kinds. One board window (`_football_window`) for
  slate/schedule; up to THREE analysis windows (`_football_pops`) for single
  matches, each opened with `show_football(..., slot="analysis")`. The fourth
  request reuses the oldest. Analysis windows run with `set_autorefresh(False)`
  — a card is a snapshot, the board is a live scoreboard.
- `core/football.squad()` reads club rosters for goals/assists/cards. ESPN's
  soccer feed has NO injury data (empty `injuries` on every roster, `count: 0`
  league-wide), so `squads["injuries_available"]` is always False and the card
  says so instead of implying fitness. Never phrase that data as injuries.
- Mic: `_pcm_level` (floor 60, full 2600 on int16) is THE loudness scale. Every
  HushGate must be built with `level_of=_pcm_level`; the module's own default is
  a different, far stricter scale and silently made "jarvis" undetectable at
  normal volume. Software gain lives in `mic_gain` (0.5–4.0, default 1.0),
  applied once at the top of the mic callback.

## Football forecast windows (update 016)
- `schedule(..., forecast=True)` attaches model numbers; `forecast_limit=20`
  caps the all-competitions case. `slate()` and `schedule()` share
  `forecast_item()`/`_forecast_block()` so the two can never disagree.
- Pop-out slots: `"board"` (shared), `"analysis"` (per match, max 3),
  `"league:<slug>"` (per competition, kept in `_football_boards`, cascaded
  side by side). `ui.show_football` passes the slot through — flattening it to
  board/analysis puts every league back into one window.
- A window's timer refreshes into its OWN slot: `request_refresh` hands
  `slot_key` to the fetcher, and `_ensure_refresh`'s `_fetch(which)` targets it.
  Without that a league window refilled the shared board and looked frozen.
- Schedule mode draws `_MatchCard` when the row has a forecast, `_ScheduleRow`
  otherwise, and drops to 6-row chunks when cards are in play.
- `_OFF_TABLE_LEAGUES` exists because ESPN's dropdown omits `idn.1` while the
  scoreboard serves it; an alias to a slug missing from the dropdown now
  resolves instead of reporting the league as non-existent.
- "champions league" must stay aliased to `uefa.champions`: the fuzzy pass
  scores the CAF name higher on the shared words.

## User uploads (`uploads/`)
- When the user sends a `.py` file directly in chat, save it **verbatim** under
  `uploads/<date>/<filename>.py` and note it in `uploads/README.md`. That folder
  is a reference archive: not imported, not in `update/SYNC.txt`, never shipped.
- Reason: this workspace cannot always run commands, and the tree can drift from
  the user's real machine. The newest upload is the source of truth for what
  their build looks like; diff against it before merging or packaging.
- Never write `config/api_keys.json` into `uploads/`, and never copy an upload
  over a live file in one step — reconcile first (see the divergence note in
  `uploads/README.md` about `avatar_popout` vs `avatar_floating`).
