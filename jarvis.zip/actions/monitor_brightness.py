"""
actions/monitor_brightness.py — brightness for EVERY monitor, not just the laptop panel.

WHY computer_settings COULD NOT DO THIS
    Its brightness goes through WMI (WmiMonitorBrightness), and WMI only exists
    for a laptop's built-in panel. A desktop monitor — or the second screen on a
    laptop — has no WMI brightness at all, so "brightness to 70" quietly did
    nothing and the tool said it could not read the level back.

HOW THIS DOES IT
    The same way Monitorian does: DDC/CI, the channel a monitor listens on over
    its video cable for "set brightness". Windows exposes it directly in
    dxva2.dll (Get/SetMonitorBrightness), so there is nothing to install and no
    other program has to be running. Called through ctypes.

        1. DDC/CI, per display          external monitors
        2. WMI, through computer_settings   the laptop's own panel
        3. Monitorian                   what to do when 1 and 2 both fail

    About 3, honestly: Monitorian is a window with sliders. As far as its
    documentation goes it has no command line or script interface that sets a
    level, and it only lists monitors that answer DDC/CI — the very thing step 1
    uses. So a monitor Monitorian can drive, this can drive; and one it cannot
    see, this cannot either. What this does when a display will not answer is say
    so, name the usual cause (DDC/CI switched off in the monitor's own menu) and
    — on request — open Monitorian so the user can see what it reports.

NUMBERING
    Screen 1 is the primary display, the rest follow left to right — the same
    order display_control uses, so "screen 2" means the same screen in both.

WHAT IT REPORTS
    A level is only reported after reading it back from the monitor. DDC/CI is
    slow and some monitors accept a write and ignore it, so a mismatch is
    "unverified", never "done".
"""
from __future__ import annotations

import ctypes
import platform
import sys
import time
from contextlib import contextmanager
from ctypes import wintypes

from core import outcome

_OS = platform.system()

_ALL_WORDS = {"all", "both", "every", "everything", "semua", "kedua", "dua-duanya",
              "keduanya", "duaduanya", "dua duanya", "semuanya"}
_OTHER_WORDS = {"other", "others", "second", "lain", "lainnya", "satunya"}
_NUMBER_WORDS = {"1": 1, "2": 2, "3": 3, "4": 4, "satu": 1, "dua": 2, "tiga": 3,
                 "empat": 4, "one": 1, "two": 2, "three": 3, "four": 4,
                 "first": 1, "third": 3, "primary": 1, "utama": 1, "main": 1}

# A monitor that was just told a new level takes a moment to report it.
_SETTLE_S = 0.35
_TOLERANCE = 3        # percentage points: DDC/CI monitors round to their own steps


# ═════════════════════════════════════════════════════════════════════════════
#  Windows backend — dxva2 via ctypes
# ═════════════════════════════════════════════════════════════════════════════
class _Mon:
    """One physical monitor: a handle and the name Windows gives it."""
    __slots__ = ("name", "handle")

    def __init__(self, name: str, handle):
        self.name = name
        self.handle = handle


class _Display:
    """One logical display (what Windows numbers) with its physical monitors."""
    __slots__ = ("n", "device", "primary", "left", "top", "mons")

    def __init__(self, device: str, primary: bool, left: int, top: int):
        self.n = 0
        self.device = device
        self.primary = primary
        self.left = left
        self.top = top
        self.mons: list[_Mon] = []


class _WinDDC:
    """DDC/CI brightness through Windows' own monitor-configuration API."""

    class _PHYSICAL_MONITOR(ctypes.Structure):
        _pack_ = 1
        _fields_ = [("hPhysicalMonitor", ctypes.c_void_p),
                    ("szPhysicalMonitorDescription", wintypes.WCHAR * 128)]

    class _MONITORINFOEXW(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                    ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD),
                    ("szDevice", wintypes.WCHAR * 32)]

    def __init__(self):
        self._user32 = ctypes.windll.user32
        self._dxva2 = ctypes.windll.dxva2
        u, d = self._user32, self._dxva2
        self._enum_proc = ctypes.WINFUNCTYPE(
            wintypes.BOOL, ctypes.c_void_p, ctypes.c_void_p,
            ctypes.POINTER(wintypes.RECT), wintypes.LPARAM)
        u.EnumDisplayMonitors.argtypes = [ctypes.c_void_p, ctypes.c_void_p,
                                          self._enum_proc, wintypes.LPARAM]
        u.EnumDisplayMonitors.restype = wintypes.BOOL
        u.GetMonitorInfoW.argtypes = [ctypes.c_void_p, ctypes.POINTER(self._MONITORINFOEXW)]
        u.GetMonitorInfoW.restype = wintypes.BOOL
        d.GetNumberOfPhysicalMonitorsFromHMONITOR.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD)]
        d.GetNumberOfPhysicalMonitorsFromHMONITOR.restype = wintypes.BOOL
        d.GetPhysicalMonitorsFromHMONITOR.argtypes = [
            ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(self._PHYSICAL_MONITOR)]
        d.GetPhysicalMonitorsFromHMONITOR.restype = wintypes.BOOL
        d.GetMonitorBrightness.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD),
                                           ctypes.POINTER(wintypes.DWORD),
                                           ctypes.POINTER(wintypes.DWORD)]
        d.GetMonitorBrightness.restype = wintypes.BOOL
        d.SetMonitorBrightness.argtypes = [ctypes.c_void_p, wintypes.DWORD]
        d.SetMonitorBrightness.restype = wintypes.BOOL
        d.DestroyPhysicalMonitors.argtypes = [wintypes.DWORD,
                                              ctypes.POINTER(self._PHYSICAL_MONITOR)]
        d.DestroyPhysicalMonitors.restype = wintypes.BOOL

    @contextmanager
    def open(self):
        """Every display, numbered, with live handles — released on exit."""
        handles: list = []
        logical: list = []

        def _cb(hmon, _hdc, _rect, _lp):
            handles.append(hmon)
            return True

        cb = self._enum_proc(_cb)           # keep a reference alive for the call
        self._user32.EnumDisplayMonitors(None, None, cb, 0)

        owned: list = []                    # (count, array) to destroy on exit
        try:
            for hmon in handles:
                info = self._MONITORINFOEXW()
                info.cbSize = ctypes.sizeof(info)
                if not self._user32.GetMonitorInfoW(hmon, ctypes.byref(info)):
                    continue
                disp = _Display(info.szDevice, bool(info.dwFlags & 1),
                                info.rcMonitor.left, info.rcMonitor.top)
                count = wintypes.DWORD(0)
                if self._dxva2.GetNumberOfPhysicalMonitorsFromHMONITOR(
                        hmon, ctypes.byref(count)) and count.value:
                    arr = (self._PHYSICAL_MONITOR * count.value)()
                    if self._dxva2.GetPhysicalMonitorsFromHMONITOR(hmon, count.value, arr):
                        owned.append((count.value, arr))
                        for pm in arr:
                            disp.mons.append(_Mon(pm.szPhysicalMonitorDescription,
                                                  pm.hPhysicalMonitor))
                logical.append(disp)
            # primary first, then left to right — display_control's order
            logical.sort(key=lambda d: (not d.primary, d.left, d.top))
            for i, d in enumerate(logical, 1):
                d.n = i
            yield logical
        finally:
            for count, arr in owned:
                try:
                    self._dxva2.DestroyPhysicalMonitors(count, arr)
                except Exception:
                    pass

    def read(self, mon: _Mon):
        """(minimum, current, maximum) raw values, or None when it won't answer."""
        lo, cur, hi = wintypes.DWORD(), wintypes.DWORD(), wintypes.DWORD()
        for _ in range(2):          # DDC/CI drops the odd request; one retry is normal
            if self._dxva2.GetMonitorBrightness(
                    mon.handle, ctypes.byref(lo), ctypes.byref(cur), ctypes.byref(hi)):
                return lo.value, cur.value, hi.value
            time.sleep(0.1)
        return None

    def write(self, mon: _Mon, raw: int) -> bool:
        for _ in range(2):
            if self._dxva2.SetMonitorBrightness(mon.handle, int(raw)):
                return True
            time.sleep(0.1)
        return False


# ═════════════════════════════════════════════════════════════════════════════
#  The logic — backend-independent, so it can be tested without a monitor
# ═════════════════════════════════════════════════════════════════════════════
def _pct(t) -> int:
    lo, cur, hi = t
    return 100 if hi <= lo else max(0, min(100, round((cur - lo) * 100 / (hi - lo))))


def _raw(t, pct: int) -> int:
    lo, _cur, hi = t
    return lo + round(max(0, min(100, pct)) * (hi - lo) / 100)


def _wmi_get():
    """The laptop panel's level through computer_settings, or None."""
    try:
        from actions import computer_settings as cs
        return cs.brightness_get()
    except Exception:
        return None


def _wmi_set(value: int) -> None:
    from actions import computer_settings as cs
    cs.brightness_set(value)


def _resolve(displays, screen) -> tuple[list[int], str | None]:
    """Which display numbers a spoken `screen` means. (numbers, problem)."""
    count = len(displays)
    text = str(screen if screen is not None else "all").strip().lower()
    if text in ("", "none"):
        text = "all"
    if text in _ALL_WORDS:
        return [d.n for d in displays], None
    if text in _OTHER_WORDS:
        rest = [d.n for d in displays if d.n != 1]
        return (rest, None) if rest else ([], "there is only one display")
    n = _NUMBER_WORDS.get(text)
    if n is None:
        try:
            n = int(float(text))
        except ValueError:
            return [], f"'{screen}' is not a screen — use a number, 'all' or 'other'"
    if not 1 <= n <= count:
        return [], f"there is no screen {n}; this computer has {count}"
    return [n], None


def _levels(be, displays, wmi_get) -> dict:
    """{n: {"name", "mon", "range", "pct", "via"}} for every display, read now.

    A display that will not answer DDC/CI is given the WMI panel when exactly
    that is what it is: the first unreachable display, if WMI can read a level.
    """
    out: dict = {}
    internal_taken = False
    for d in displays:
        row = {"name": "", "mon": None, "range": None, "pct": None, "via": None}
        for m in d.mons:
            t = be.read(m)
            if t is not None:
                row.update(name=m.name, mon=m, range=t, pct=_pct(t), via="ddc")
                break
        if row["via"] is None and not internal_taken:
            w = wmi_get()
            if w is not None:
                internal_taken = True
                row.update(name="built-in panel", pct=int(w), via="wmi")
        out[d.n] = row
    return out


def _write_level(be, displays, rows, n: int, pct: int, wmi_set) -> bool:
    row = rows[n]
    if row["via"] == "ddc":
        disp = next(d for d in displays if d.n == n)
        ok = False
        for m in disp.mons:             # a cloned display has several; set them all
            t = row["range"] if m is row["mon"] else be.read(m)
            if t is not None and be.write(m, _raw(t, pct)):
                ok = True
        return ok
    if row["via"] == "wmi":
        try:
            wmi_set(pct)
            return True
        except Exception:
            return False
    return False


def change(be, action: str, value, screen, wmi_get=_wmi_get, wmi_set=_wmi_set,
           sleep=time.sleep) -> dict:
    """Do the work. Returns {"error"?, "rows": [...], "undo": {n: pct}}.

    action: get | set | up | down.  Each row: n, name, before, target, after,
    state (ok | mismatch | unreachable | unread).
    """
    with be.open() as displays:
        if not displays:
            return {"error": "no display was found"}
        nums, problem = _resolve(displays, screen)
        if problem:
            return {"error": problem}
        rows = _levels(be, displays, wmi_get)

        result, undo = [], {}
        for n in nums:
            r = rows[n]
            item = {"n": n, "name": r["name"], "before": r["pct"], "target": None,
                    "after": None, "state": "ok", "via": r["via"]}
            if r["via"] is None:
                item["state"] = "unreachable"
                result.append(item)
                continue
            if action == "get":
                item["after"] = r["pct"]
                result.append(item)
                continue
            if action == "set":
                target = int(value)
            else:
                step = abs(int(value)) if value is not None else 10
                target = r["pct"] + (step if action == "up" else -step)
            target = max(0, min(100, target))
            item["target"] = target
            undo[n] = r["pct"]
            if not _write_level(be, displays, rows, n, target, wmi_set):
                item["state"] = "unreachable"
                result.append(item)
                continue
            result.append(item)

        if action != "get":
            sleep(_SETTLE_S)            # let the monitors catch up before reading back
            after = _levels(be, displays, wmi_get)
            for item in result:
                if item["state"] != "ok":
                    continue
                now = after[item["n"]]["pct"]
                item["after"] = now
                if now is None:
                    item["state"] = "unread"
                elif abs(now - item["target"]) > _TOLERANCE:
                    item["state"] = "mismatch"
        return {"rows": result, "undo": undo, "count": len(displays)}


def restore(be, levels: dict, wmi_get=_wmi_get, wmi_set=_wmi_set) -> str:
    """Put back what an earlier change() replaced. Used by undo."""
    with be.open() as displays:
        rows = _levels(be, displays, wmi_get)
        done = []
        for n, pct in levels.items():
            if n in rows and rows[n]["via"] and pct is not None:
                if _write_level(be, displays, rows, n, pct, wmi_set):
                    done.append(f"screen {n} to {pct}%")
        return ("Brightness back: " + ", ".join(done) + ".") if done else \
               "Could not put the brightness back."


# ═════════════════════════════════════════════════════════════════════════════
#  Tool
# ═════════════════════════════════════════════════════════════════════════════
_HINT = ("it did not answer DDC/CI. Usually DDC/CI is switched off in the "
         "monitor's own on-screen menu (look under Display or System settings), "
         "or the cable/dock/KVM does not pass it. Monitorian only lists monitors "
         "that answer DDC/CI, so if Monitorian does not show it either, that is "
         "the cause")

_backend = None


def _be():
    """The backend, built once. None where this build cannot drive monitors."""
    global _backend
    if _backend is None and _OS == "Windows":
        _backend = _WinDDC()
    return _backend


def _number(v):
    if v is None or isinstance(v, bool):
        return None
    try:
        return int(round(float(str(v).strip().rstrip("%"))))
    except ValueError:
        return None


def run(parameters: dict | None = None, player=None, session_memory=None) -> str:
    p = parameters or {}
    action = str(p.get("action") or "").strip().lower()
    action = {"brightness_set": "set", "level": "set", "to": "set", "turn_up": "up",
              "increase": "up", "brighter": "up", "turn_down": "down",
              "decrease": "down", "dimmer": "down", "darker": "down", "read": "get",
              "status": "get", "list": "get", "check": "get"}.get(action, action)

    if action in ("monitorian", "open_monitorian"):
        try:
            from actions.open_app import open_app
            return open_app({"app_name": "Monitorian"}, player=player)
        except Exception as e:
            return outcome.failed("monitor_brightness",
                                  f"Monitorian could not be opened: {e}")

    be = _be()
    if be is None:
        return outcome.failed(
            "monitor_brightness",
            "monitor control through DDC/CI is Windows-only here; use "
            "computer_settings brightness for this machine's own screen")

    value = _number(p.get("value") if p.get("value") is not None else p.get("level"))
    if action not in ("set", "up", "down", "get"):
        # No verb but a number: "brightness 60" is a level.
        action = "set" if value is not None else "get"
    if action == "set" and value is None:
        return outcome.ask("monitor_brightness",
                           "what brightness, from 0 to 100?")
    screen = p.get("screen") or p.get("monitor") or p.get("display") or "all"

    try:
        res = change(be, action, value, screen)
    except Exception as e:
        return outcome.failed("monitor_brightness", f"the monitors could not be read: {e}")
    if res.get("error"):
        return outcome.failed("monitor_brightness", res["error"])

    rows = res["rows"]
    facts: dict = {}
    for r in rows:
        key = f"screen_{r['n']}"
        label = f" ({r['name']})" if r["name"] and r["name"] != "Generic PnP Monitor" else ""
        if r["state"] == "unreachable":
            facts[key] = "not controllable" + label
        elif action == "get":
            facts[key] = f"{r['after']}%{label}"
        elif r["state"] == "unread":
            facts[key] = f"{r['before']}% -> asked {r['target']}%, could not be read back{label}"
        else:
            facts[key] = f"{r['before']}% -> {r['after']}%{label}"

    bad = [r for r in rows if r["state"] == "unreachable"]
    if action == "get":
        if all(r["state"] == "unreachable" for r in rows):
            return outcome.failed("monitor_brightness", _HINT, **facts)
        return outcome.done("monitor_brightness", **facts)

    # An undo that puts back every screen exactly as it was.
    if res["undo"]:
        try:
            from core.undo import push_undo
            levels = dict(res["undo"])
            push_undo("monitor brightness " + ", ".join(
                f"screen {n} {v}%" for n, v in levels.items()),
                lambda lv=levels: restore(be, lv))
        except Exception:
            pass

    if len(bad) == len(rows):
        return outcome.failed("monitor_brightness", _HINT, **facts)
    mismatch = [r for r in rows if r["state"] in ("mismatch", "unread")]
    if mismatch or bad:
        why = []
        if bad:
            why.append("screen " + ", ".join(str(r["n"]) for r in bad) + ": " + _HINT)
        if mismatch:
            why.append("screen " + ", ".join(str(r["n"]) for r in mismatch) +
                       " accepted the command but reports a different level")
        return outcome.unverified("monitor_brightness", "; ".join(why), **facts)
    return outcome.done("monitor_brightness", verified=True, **facts)


TOOL = {
    "name": "monitor_brightness",
    "description": (
        "Sets or reads the brightness of the user's monitors — all of them, or one "
        "— including external monitors, which computer_settings cannot do. Use it "
        "for 'kecerahan layar jadi 60', 'terangin kedua monitor', 'redupin layar "
        "2', 'brightness 40 di semua layar', 'what's my brightness'. A level the "
        "user names is action 'set' with value; a change by an amount is 'up' / "
        "'down' with value = the amount (no amount = 10). `screen` is 'all' "
        "(default — both monitors), a number (1 = primary, then left to right), "
        "or 'other'. It reads every level back from the monitor, so report what "
        "it says, not what was asked. If a monitor is 'not controllable', its "
        "DDC/CI is usually off in its own menu — say so, and offer action "
        "'monitorian' to open the Monitorian app. Reversible with `undo`."
    ),
    "brief": "Set or read brightness on one or all monitors (external ones too).",
    "handler": run,
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'set' (to `value`), 'up' / 'down' (by `value`, default "
                               "10), 'get' (read the levels), 'monitorian' (open the "
                               "Monitorian app).",
            },
            "value": {
                "type": "INTEGER",
                "description": "A level 0-100 for 'set', or the amount for up/down.",
            },
            "screen": {
                "type": "STRING",
                "description": "'all' (default), a number (1 = primary), or 'other'.",
            },
        },
        "required": [],
    },
}
