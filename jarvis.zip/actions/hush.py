"""
actions/hush.py — "diem" / "stop talking" / "quiet".

WHAT THIS TOOL IS FOR
    Quiet mode is a BUTTON now (DIEM / F9), and this tool exists only around
    that fact: it reports the state, wakes the assistant back up, and refuses
    to put it to sleep. Nothing spoken can arm quiet mode any more.

    It used to arm it, and that was the problem. While an answer played, the
    microphone heard that answer; at speaker volume the soft parts of our own
    voice fell under the level floor and read as the silence before a word, so
    fragments of its own sentences put it to sleep mid-answer with nobody
    asking. Every guard that cut those false hits cut the user's real "diem" by
    the same amount — same sound, same microphone.

    Waking stays available by voice because it costs nothing to be wrong about:
    a false wake just starts listening.

WHY THE REPLY IS SO SHORT
    The tool is called mid-answer, so anything long becomes the last thing
    said before going quiet, which is the opposite of the request. One short
    line, then silence. The state itself is enforced by main.py, not by this
    file — if this returned and the gate stayed open, the feature would be a
    polite fiction.
"""
from __future__ import annotations

from core import outcome


def _player_hush(player) -> bool | None:
    """Current hush state, or None when the interface does not expose it."""
    fn = getattr(player, "hush_state", None)
    if not callable(fn):
        return None
    try:
        return bool(fn())
    except Exception:
        return None


def run(parameters: dict | None = None, player=None, response=None,
        session_memory=None) -> str:
    params = parameters or {}
    mode = str(params.get("mode") or "quiet").strip().lower()

    toggle = getattr(player, "hush_toggle", None)
    if not callable(toggle):
        return outcome.failed(
            "hush",
            "this build has no quiet mode — update to the newest package")

    if mode in ("status", "state"):
        now = _player_hush(player)
        if now is None:
            return outcome.failed("hush", "quiet mode state is unavailable")
        return outcome.done("hush", quiet=now,
                            detail="quiet — waiting for the name" if now
                            else "awake")

    if mode in ("wake", "resume", "bangun"):
        now = _player_hush(player)
        if now is False:
            return outcome.done("hush", quiet=False, detail="already awake")
        if now is None:
            # Unknown state plus a blind toggle is how "wake up" would END UP
            # quiet. Refuse rather than guess.
            return outcome.failed(
                "hush", "quiet mode state is unavailable, so waking would be a "
                        "guess — the DIEM button still works")
        # The toggle is the only mutator; flipping it once from quiet is
        # exactly "wake up".
        try:
            toggle()
        except Exception as e:
            return outcome.failed("hush", f"could not wake up: {e}")
        return outcome.done("hush", quiet=False, detail="listening again")

    if mode in ("toggle",):
        try:
            now = bool(toggle())
        except Exception as e:
            return outcome.failed("hush", f"could not change quiet mode: {e}")
        return outcome.done("hush", quiet=now)

    # default: go quiet — REFUSED. Quiet mode is the button only.
    #
    # The user's words and this tool were never a reliable pair: the assistant
    # would hush itself on its own sentence, or mid-answer when its own voice
    # through the speakers looked like the word. Making the trigger stricter
    # always cost the real request too, because both are the same sound.
    #
    # So it is now a physical action. Press DIEM (or F9), it goes quiet; say the
    # name (or press again), it comes back. Saying "diem" out loud is just talk,
    # and the assistant stays awake and keeps listening — which is exactly what
    # was asked for.
    return outcome.failed(
        "hush",
        "quiet mode is the DIEM button (or F9) only — nothing spoken can arm it. "
        "If the user told you to be quiet, do not go silent: say in one short line "
        "that quiet is the button, and stay listening so they are not stranded.")


TOOL = {
    "name": "hush",
    "description": (
        "Check or change quiet mode. Quiet mode itself is the DIEM button (or "
        "F9) on the window — it cannot be switched on by talking, and mode "
        "'quiet' here is refused for that reason. Use 'status' to report whether "
        "quiet is on, and 'wake' to bring the assistant back when the user asks "
        "it to start listening again. If the user TELLS you to be quiet, do not "
        "go silent: say in one short line that quiet is the button, and keep "
        "talking normally so they are not left with a dead window."
    ),
    "brief": "Quiet is the button; this only checks state or wakes up.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {
                "type": "STRING",
                "description": "'quiet' (default) to stop and wait for the name, "
                               "'wake' to resume now, 'status' to check, "
                               "'toggle' to flip.",
            },
        },
    },
    "handler": run,
}
