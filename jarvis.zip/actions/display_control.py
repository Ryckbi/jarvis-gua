"""
actions/display_control.py — move MARK's window to another monitor, fullscreen.

The HUD is one window on one screen. A game on the primary display and the
assistant on the second is the setup this exists for: "pindah ke layar satunya",
"fullscreen di monitor 2", "bring it to this screen".

F11 (fullscreen) and F12 (next display) already do this from the keyboard. This
tool is the same two operations for the voice channel, so the answer is spoken
rather than needing the keyboard while a game has focus.

WHAT IT DOES NOT DO
    It never guesses which monitor the user means beyond "the number they said"
    and "the next one". Two screens of identical size are indistinguishable
    from inside the app, so screen numbers follow Qt's order with the primary
    first — the same order "screen 1" reads as in Windows Display settings when
    the primary is the leftmost.
"""
from __future__ import annotations

from core import outcome

_DISPLAY_WORDS = {
    "1": 1, "2": 2, "3": 3, "4": 4,
    "satu": 1, "dua": 2, "tiga": 3, "empat": 4,
    "one": 1, "two": 2, "three": 3, "four": 4,
    "first": 1, "second": 2, "third": 3,
    "primary": 1, "utama": 1, "main": 1,
}


def _index_from(value) -> int | None:
    """'2' / 'dua' / 'second' -> 2 (1-based); None when it is not a display."""
    if value is None:
        return None
    if isinstance(value, int):
        return value if 1 <= value <= 4 else None
    text = str(value).strip().lower()
    if not text:
        return None
    return _DISPLAY_WORDS.get(text)


def _fullscreen_from(params: dict) -> bool | None:
    """Explicit true/false, or None to keep what the window is doing now."""
    raw = params.get("fullscreen")
    if isinstance(raw, bool):
        return raw
    text = str(raw if raw is not None else params.get("mode") or "").strip().lower()
    if text in ("on", "true", "yes", "full", "fullscreen", "penuh"):
        return True
    if text in ("off", "false", "no", "windowed", "normal", "jendela"):
        return False
    return None


def _no_window(player) -> bool:
    return player is None or not callable(getattr(player, "move_to_screen", None))


def run(parameters: dict | None = None, player=None, response=None,
        session_memory=None) -> str:
    params = parameters or {}
    action = str(params.get("action") or "").strip().lower()

    if _no_window(player):
        return outcome.failed(
            "display_control",
            "the interface is not running yet, so there is no window to move")

    try:
        if action in ("list", "displays", "info"):
            summary = player._win._screen_summary()
            count = len(player._win._screens())
            return outcome.done("display_control", displays=summary, count=count)

        if action in ("second", "companion", "mirror"):
            # Toggle the small panel on the OTHER display. Deliberately not a
            # second copy of the HUD: one assistant, one microphone, one voice.
            if not callable(getattr(player, "toggle_second_display", None)):
                return outcome.failed(
                    "display_control",
                    "this build has no companion display — update to the newest package")
            res = player.toggle_second_display()
            if not res.get("ok"):
                return outcome.failed("display_control",
                                      res.get("reason") or "could not open it")
            return outcome.done("display_control",
                                companion_display="on" if res["shown"] else "off")

        want_fs = _fullscreen_from(params)
        target = _index_from(params.get("screen") or params.get("monitor")
                             or params.get("display"))

        if action in ("next", "other", "swap", "cycle") or (
                action in ("move", "send", "switch") and target is None):
            # "The other one" — with two displays this is simply the other one,
            # which is what the phrase means; with three it takes the next.
            result = player.cycle_screen()
        elif action in ("fullscreen", "maximise", "maximize", "full"):
            here = player._win._screen_index() + 1
            result = player.move_to_screen(here or 1, True)
        elif action in ("windowed", "restore", "normal"):
            here = player._win._screen_index() + 1
            result = player.move_to_screen(here or 1, False)
        elif target is not None:
            result = player.move_to_screen(target, want_fs)
        else:
            # No useful parameter at all. Asking beats moving the window to a
            # screen the user did not mean.
            return outcome.ask(
                "display_control",
                "which screen — 'the other one', or a number like screen 2?")

        if not result.get("ok"):
            return outcome.failed(
                "display_control",
                result.get("error") or "the window did not move")

        if result.get("screen") == 0:
            return outcome.unverified(
                "display_control", "the window moved but no display was matched")

        where = f"screen {result['screen']}"
        state = "fullscreen" if result.get("fullscreen") else "windowed"
        return outcome.done(
            "display_control",
            screen=result["screen"], state=state,
            size=f"{result.get('width')}x{result.get('height')}",
            displays=result.get("displays"),
            note=f"now on {where}, {state}",
        )
    except Exception as e:
        return outcome.failed("display_control", f"the window could not be moved: {e}")


TOOL = {
    "name": "display_control",
    "description": (
        "Moves MARK's own window to another monitor, and can make it fullscreen "
        "there. Use it for 'pindah ke layar satunya', 'pindahin ke monitor 2', "
        "'fullscreen di layar lain', 'bring it to this screen', 'send it to my "
        "other monitor', 'make it fullscreen on screen 2', 'balikin ke jendela'. "
        "Action 'next' is the usual one — it means the other display. 'second' "
        "toggles the companion panel on the other monitor ('tampilin di dua "
        "layar', 'pake dua monitor', 'buka panel di layar kedua') — a status "
        "panel, not a second HUD. Do not use "
        "computer_settings fullscreen for this: that presses F11 on whatever "
        "window has focus (a game), while this moves MARK itself and reports "
        "which screen it actually landed on."
    ),
    "brief": "Move MARK's window to another monitor, optionally fullscreen.",
    "handler": run,
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'next' (the other display), 'move' (to `screen`), "
                               "'fullscreen' (here, fullscreen), 'windowed' "
                               "(here, back to a window), 'list' (which displays), "
                               "'second' (toggle the companion panel on the other "
                               "monitor: state + last answer).",
            },
            "screen": {
                "type": "STRING",
                "description": "Which display, 1-based (1 = primary). '2', 'dua', "
                               "'second' are all understood.",
            },
            "fullscreen": {
                "type": "BOOLEAN",
                "description": "true to go fullscreen on arrival, false to stay "
                               "windowed, omit to keep the current state.",
            },
        },
        "required": [],
    },
}
