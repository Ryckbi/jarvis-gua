"""
actions/media_control.py — "play music" and "play video" are two different things.

THE PROBLEM THIS SOLVES
    The old route for both was one blind key: the system Play/Pause media key.
    That key goes to whichever app Windows last treated as "the" player — so
    "play music" would resume a paused YouTube tab, and "pause the video" would
    stop Spotify. Two requests, one ambiguous key.

THE TWO MEANINGS
    music  ->  Spotify, and only Spotify. Plays what Spotify has (or launches it
               first if it is closed).
    video  ->  every video/audio the user has open in the browser (Brave is the
               user's browser; any other browser is used only when Brave has
               nothing). "All" means all: every paused browser media session is
               resumed, every playing one is paused.
    all    ->  pause/stop only: shut up both.

HOW (Windows)
    Windows keeps a list of media sessions (the same list behind the volume
    flyout's "now playing" card). Each session knows WHICH app it belongs to and
    can be told Play / Pause / Next / Previous directly — no key press, no window
    focus, no guessing. It is reached through PowerShell's built-in WinRT bridge,
    so nothing needs installing. After the command the session is read back, and
    the answer reports what Windows says is now playing, not what was sent.

    Fallbacks, in order: Spotify's own window (WM_APPCOMMAND — also focus-free),
    then the plain media key (reported as unverified, because it is a guess).
    Linux uses playerctl with an explicit player name. macOS has no equivalent
    here and says so.

HONEST LIMITS
    - A specific SONG cannot be started by name: Spotify has no desktop command
      for that without a Web API login. With `query`, Spotify is opened on the
      search results and that is what is reported.
    - The browser only shows up in the session list while it holds media. A tab
      that never played anything has no session to resume.
"""
from __future__ import annotations

import base64
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from urllib.parse import quote

from core import outcome

_OS = platform.system()

_MUSIC_RE   = r"spotify"
_BRAVE_RE   = r"brave"
_BROWSER_RE = r"brave|chrome|msedge|edge|firefox|opera|vivaldi|arc|zen"

_ACTIONS = ("play", "pause", "toggle", "next", "previous", "stop", "status")

# ── Windows: media sessions through PowerShell's WinRT bridge ────────────────
_PS = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, $type) {
    $t = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
    [void]$t.Wait(8000)
    $t.Result
}
$mgrT = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType=WindowsRuntime]
$proT = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType=WindowsRuntime]
$mgr = Await ($mgrT::RequestAsync()) $mgrT
$pattern = '__PATTERN__'
$action  = '__ACTION__'
$prefer  = '__PREFER__'
$rows = @()
$mine = @($mgr.GetSessions() | Where-Object { ([string]$_.SourceAppUserModelId) -match $pattern })
if ($prefer -ne '') {
    $pref = @($mine | Where-Object { ([string]$_.SourceAppUserModelId) -match $prefer })
    if ($pref.Count -gt 0) { $mine = $pref }
}
foreach ($s in $mine) {
    $id = [string]$s.SourceAppUserModelId
    $before = [string]$s.GetPlaybackInfo().PlaybackStatus
    $sent = $false
    switch ($action) {
        'play'     { if ($before -ne 'Playing') { $sent = Await ($s.TryPlayAsync()) ([bool]) } else { $sent = $true } }
        'pause'    { if ($before -eq 'Playing') { $sent = Await ($s.TryPauseAsync()) ([bool]) } else { $sent = $true } }
        'toggle'   { $sent = Await ($s.TryTogglePlayPauseAsync()) ([bool]) }
        'stop'     { $sent = Await ($s.TryStopAsync()) ([bool]) }
        'next'     { $sent = Await ($s.TrySkipNextAsync()) ([bool]) }
        'previous' { $sent = Await ($s.TrySkipPreviousAsync()) ([bool]) }
        default    { $sent = $true }
    }
    if ($action -ne 'status') { Start-Sleep -Milliseconds 450 }
    $after = [string]$s.GetPlaybackInfo().PlaybackStatus
    $title = ''; $artist = ''
    try { $p = Await ($s.TryGetMediaPropertiesAsync()) $proT; $title = [string]$p.Title; $artist = [string]$p.Artist } catch {}
    $rows += [pscustomobject]@{ app = $id; before = $before; after = $after; sent = [bool]$sent; title = $title; artist = $artist }
}
Write-Output ('MCJSON:' + (ConvertTo-Json -InputObject @($rows) -Compress))
"""


def _run_ps(pattern: str, action: str, prefer: str = "", timeout: float = 25.0):
    """Run the session script. Returns (rows, error). rows is None on failure."""
    if (action not in _ACTIONS or not re.fullmatch(r"[a-z|]+", pattern)
            or not re.fullmatch(r"[a-z|]*", prefer)):
        return None, "bad arguments"
    script = (_PS.replace("__PATTERN__", pattern).replace("__ACTION__", action)
              .replace("__PREFER__", prefer))
    enc = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    try:
        r = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
             "-EncodedCommand", enc],
            capture_output=True, text=True, timeout=timeout,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as e:                                          # noqa: BLE001
        return None, f"powershell could not run ({e})"
    for line in (r.stdout or "").splitlines():
        if line.startswith("MCJSON:"):
            try:
                data = json.loads(line[7:] or "[]")
            except Exception as e:                                  # noqa: BLE001
                return None, f"unreadable answer ({e})"
            return (data if isinstance(data, list) else [data]), ""
    err = (r.stderr or r.stdout or "").strip().splitlines()
    return None, (err[-1][:160] if err else "no answer from the media session list")


# ── Windows fallbacks ────────────────────────────────────────────────────────
_APPCOMMAND = {"play": 46, "pause": 47, "toggle": 14, "stop": 13, "next": 11, "previous": 12}


def _spotify_hwnds() -> list[int]:
    """Top-level windows that belong to Spotify.exe."""
    import ctypes
    from ctypes import wintypes
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    found: list[int] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _lp):
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        h = kernel32.OpenProcess(0x1000, False, pid.value)       # QUERY_LIMITED_INFORMATION
        if h:
            try:
                buf = ctypes.create_unicode_buffer(520)
                n = wintypes.DWORD(520)
                if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                    if buf.value.lower().endswith("spotify.exe"):
                        cls = ctypes.create_unicode_buffer(128)
                        user32.GetClassNameW(hwnd, cls, 128)
                        if cls.value.startswith("Chrome_WidgetWin"):
                            found.append(hwnd)
            finally:
                kernel32.CloseHandle(h)
        return True

    user32.EnumWindows(cb, 0)
    return found


def _spotify_appcommand(action: str) -> bool:
    """Send Spotify's own window a media command. No focus needed."""
    import ctypes
    cmd = _APPCOMMAND.get(action)
    if cmd is None:
        return False
    sent = False
    for hwnd in _spotify_hwnds():
        # WM_APPCOMMAND = 0x0319; command lives in the high word of lParam.
        ctypes.windll.user32.SendMessageW(hwnd, 0x0319, hwnd, cmd << 16)
        sent = True
    return sent


def _media_key(action: str) -> bool:
    """Last resort: the global media key. It cannot choose WHICH player."""
    import ctypes
    vk = {"play": 0xB3, "pause": 0xB3, "toggle": 0xB3,
          "next": 0xB0, "previous": 0xB1, "stop": 0xB2}.get(action)
    if vk is None:
        return False
    user32 = ctypes.windll.user32
    user32.keybd_event(vk, 0, 0, 0)
    user32.keybd_event(vk, 0, 2, 0)
    return True


def _launch_spotify() -> bool:
    try:
        if _OS == "Windows":
            try:
                os.startfile("spotify:")                            # type: ignore[attr-defined]
                return True
            except Exception:
                exe = os.path.join(os.environ.get("APPDATA", ""), "Spotify", "Spotify.exe")
                if os.path.isfile(exe):
                    subprocess.Popen([exe])
                    return True
                return False
        if _OS == "Darwin":
            subprocess.Popen(["open", "-a", "Spotify"])
            return True
        for cmd in (["spotify"], ["flatpak", "run", "com.spotify.Client"]):
            if shutil.which(cmd[0]):
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
    except Exception:
        pass
    return False


# ── Linux: playerctl, with an explicit player ────────────────────────────────
def _playerctl(players_re: str, action: str, prefer: str = ""):
    """(rows, error) using playerctl; rows mimic the Windows shape."""
    if not shutil.which("playerctl"):
        return None, "playerctl is not installed (sudo apt install playerctl)"
    try:
        names = subprocess.run(["playerctl", "-l"], capture_output=True, text=True,
                               timeout=5).stdout.split()
    except Exception as e:                                          # noqa: BLE001
        return None, str(e)
    mine = [n for n in names if re.search(players_re, n, re.I)]
    if prefer:
        pref = [n for n in mine if re.search(prefer, n, re.I)]
        mine = pref or mine
    verb = {"play": "play", "pause": "pause", "toggle": "play-pause", "stop": "stop",
            "next": "next", "previous": "previous", "status": "status"}[action]
    rows = []
    for n in mine:
        def q(*a):
            return subprocess.run(["playerctl", "-p", n, *a], capture_output=True,
                                  text=True, timeout=5).stdout.strip()
        before = q("status")
        if action != "status":
            q(verb)
            time.sleep(0.4)
        rows.append({"app": n, "before": before, "after": q("status"), "sent": True,
                     "title": q("metadata", "xesam:title"),
                     "artist": q("metadata", "xesam:artist")})
    return rows, ""


# ── shared ───────────────────────────────────────────────────────────────────
def _sessions(pattern: str, action: str, prefer: str = ""):
    if _OS == "Windows":
        return _run_ps(pattern, action, prefer)
    if _OS == "Linux":
        return _playerctl(pattern, action, prefer)
    return None, "this platform has no per-app media control here"


_WANT_AFTER = {"play": "Playing", "pause": ("Paused", "Stopped", "Closed"),
               "stop": ("Stopped", "Paused", "Closed")}


def _reached(action: str, row: dict) -> bool:
    want = _WANT_AFTER.get(action)
    after = str(row.get("after") or "").capitalize()
    if want is None:
        return bool(row.get("sent"))
    return after in ((want,) if isinstance(want, str) else want)


def _label(row: dict) -> str:
    t, a = (row.get("title") or "").strip(), (row.get("artist") or "").strip()
    return f"{a} - {t}" if a and t else (t or a or "")


def _do(kind: str, action: str, query: str) -> str:
    music = kind == "music"
    pattern = _MUSIC_RE if music else _BROWSER_RE
    name = "media_control"
    who = "Spotify" if music else "browser"

    # ---- music: Spotify must be running -----------------------------------
    launched = False
    if music and (query or action in ("play", "toggle")):
        rows, _e = _sessions(_MUSIC_RE, "status")
        running = bool(rows) or (_OS == "Windows" and bool(_spotify_hwnds()))
        if not running:
            if not _launch_spotify():
                return outcome.failed(name, "Spotify is not running and could not be started "
                                            "(is it installed?)", kind=kind)
            launched = True
            for _ in range(24):                       # up to ~12 s for it to appear
                time.sleep(0.5)
                rows, _e = _sessions(_MUSIC_RE, "status")
                if rows or (_OS == "Windows" and _spotify_hwnds()):
                    break
            time.sleep(1.5)

    if music and query:
        uri = "spotify:search:" + quote(query)
        try:
            if _OS == "Windows":
                os.startfile(uri)                                   # type: ignore[attr-defined]
            elif _OS == "Darwin":
                subprocess.Popen(["open", uri])
            else:
                subprocess.Popen(["xdg-open", uri])
        except Exception as e:                                      # noqa: BLE001
            return outcome.failed(name, f"could not open Spotify's search ({e})", kind=kind)
        return outcome.done(
            name, kind=kind, opened_search=query, playing=False,
            note="Spotify is showing the search results. A specific song cannot be "
                 "started from here — tell the user to pick it; do not say it is playing.")

    # Brave first; another browser only when Brave has no session of its own.
    rows, err = _sessions(pattern, action, "" if music else "brave")

    if rows is None or (not rows and _OS == "Windows" and music):
        # The session list failed or Spotify has no session yet — go to the app.
        if _OS == "Windows" and music and action != "status":
            if _spotify_appcommand(action):
                return outcome.unverified(
                    name, "the command went to Spotify's window but its state could not "
                          "be read back", kind=kind, wanted=action)
        if rows is None:
            if _OS == "Windows" and not music and action != "status" and _media_key(action):
                return outcome.unverified(
                    name, "the media list was unreachable, so a plain media key was sent — "
                          "it cannot choose the player", kind=kind, wanted=action,
                    reason=err)
            return outcome.failed(name, f"could not reach the {who} media control: {err}",
                                  kind=kind)

    if not rows:
        if music:
            return outcome.failed(name, "Spotify is not running. Say 'play music' to open it.",
                                  kind=kind)
        return outcome.failed(
            name, "no video or audio is open in the browser right now (a tab only appears "
                  "here once it has played something).", kind=kind)

    items = [{"app": r.get("app"), "state": r.get("after"), "now": _label(r)} for r in rows]
    if action == "status":
        return outcome.done(name, kind=kind, sessions=items)

    ok = [r for r in rows if _reached(action, r)]
    if len(ok) == len(rows):
        return outcome.done(name, kind=kind, wanted=action, verified=True,
                            count=len(rows), launched=launched or None, sessions=items)
    if ok:
        return outcome.unverified(
            name, f"{len(ok)} of {len(rows)} reached the state", kind=kind,
            wanted=action, sessions=items)
    if action in ("next", "previous") and all(r.get("sent") for r in rows):
        return outcome.done(name, kind=kind, wanted=action, sessions=items)
    return outcome.unverified(
        name, f"the command was sent but {who} did not report the change", kind=kind,
        wanted=action, sessions=items)


def run(parameters: dict | None = None, player=None, response=None,
        session_memory=None) -> str:
    p = parameters or {}
    kind = str(p.get("kind") or p.get("target") or "").strip().lower()
    action = str(p.get("action") or "toggle").strip().lower()
    query = str(p.get("query") or "").strip()

    kind = {"musik": "music", "lagu": "music", "spotify": "music", "song": "music",
            "video": "video", "browser": "video", "youtube": "video", "film": "video",
            "semua": "all", "everything": "all", "both": "all"}.get(kind, kind)
    action = {"resume": "play", "start": "play", "continue": "play",
              "prev": "previous", "back": "previous", "skip": "next",
              "pause_all": "pause", "playpause": "toggle", "play_pause": "toggle"}.get(
                  action, action)

    if kind not in ("music", "video", "all"):
        return outcome.ask("media_control", "music (Spotify) or video (browser)?")
    if action not in _ACTIONS:
        return outcome.failed("media_control", f"unknown action '{action}'",
                              allowed=list(_ACTIONS))
    if kind == "all":
        if action not in ("pause", "stop", "status"):
            return outcome.ask("media_control",
                               "'all' only works for pause/stop — music or video?")
        a = _do("music", action, "")
        b = _do("video", action, "")
        return f"music: {a}\nvideo: {b}"

    result = _do(kind, action, query if kind == "music" else "")
    if player is not None:
        try:
            player.write_log(f"SYS: {kind} {action}")
        except Exception:
            pass
    return result


TOOL = {
    "name": "media_control",
    "description": (
        "Plays, pauses, skips or reports on media — and tells MUSIC and VIDEO apart. "
        "kind='music' (the user says music / musik / lagu / song / Spotify): controls "
        "SPOTIFY only, directly; if Spotify is closed, 'play' opens it first. "
        "kind='video' (the user says video / YouTube / film, or 'play video' with no "
        "title): controls EVERY video or audio the user already has open in their "
        "browser (Brave), not Spotify. 'play video' resumes all paused browser media, "
        "'pause video' pauses all playing ones. kind='all' with action pause/stop "
        "quiets both. Use this for a bare 'play / pause / next' request. "
        "Do NOT use it to open a NEW video by name or link (that is video_player or "
        "browser_control). It cannot start a specific song: with 'query' it opens "
        "Spotify's search results and you must say so, not claim it is playing. "
        "Report what the result says is playing now; if the result is unverified, say "
        "it was sent but not confirmed."
    ),
    "brief": "Play/pause/next for Spotify (kind=music) or browser videos (kind=video).",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "kind": {
                "type": "STRING",
                "description": "'music' = Spotify, 'video' = everything open in the "
                               "browser, 'all' = both (pause/stop only).",
                "enum": ["music", "video", "all"],
            },
            "action": {
                "type": "STRING",
                "description": "'play' (resume), 'pause', 'toggle', 'next', "
                               "'previous', 'stop', 'status' (what is playing).",
                "enum": list(_ACTIONS),
            },
            "query": {
                "type": "STRING",
                "description": "kind='music' only: a song/artist to look up. Opens "
                               "Spotify's search; does NOT start playback.",
            },
        },
        "required": ["kind", "action"],
    },
    "handler": run,
}
