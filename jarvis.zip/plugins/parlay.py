"""
Parlay — build a multi-match accumulator from the model's own numbers.

WHY THIS IS A SEPARATE TOOL FROM MATCH FORECAST
    match_forecast answers "who wins this match". A parlay is a different
    question: given several matches, which legs are worth combining, what is
    the joint probability, and where is the weakest link. Answering that by
    asking the model to multiply numbers it read out loud is how parlay advice
    becomes fiction.

    Every leg here comes from core.football.predict() for that exact fixture —
    the same season table and the same Poisson grid the single-match answer
    uses. The joint figure is those probabilities multiplied, and it is
    reported as a probability, never as a promise.

WHAT "ACCURATE" MEANS HERE, HONESTLY
    Each leg is a model estimate from this season's results. The product is
    only valid because different fixtures are independent, which is why two
    legs from the SAME match are refused: "City win" and "over 2.5" in one
    accumulator are one outcome sold twice with the odds multiplied.

    A leg below 50% is dropped rather than included to reach a leg count. An
    accumulator is a product; padding it with a coin flip does not raise the
    payout, it quarter the chance of winning.

SPEED
    The pop-out is opened BEFORE any prediction runs, with the note saying so,
    and filled when the legs are ready. The user asked for a fast window, not a
    fast answer: an empty window that fills in two seconds beats a card that
    appears after eight. Predictions run in parallel because each one is an
    independent network fetch behind a cache.
"""
from __future__ import annotations

import concurrent.futures as cf
import re
import threading
import time

PLUGIN = {
    "name": "parlay",
    "description": (
        "Build and check football parlays (accumulators / mix parlay) with a "
        "real probability for each leg and a combined probability for the "
        "whole ticket. Use this when the user says 'parlay', 'akumulator', "
        "'mix parlay', 'pasang beberapa laga sekaligus', or asks which matches "
        "to combine. Parameters: mode='build' picks the best legs from "
        "upcoming fixtures — give `league` (or leave empty for the big "
        "leagues), `days` (default 3) and `legs` (default 3, max 15). "
        "mode='check' evaluates matches the user already chose — put them in "
        "`matches` as 'Team A vs Team B, Team C vs Team D'. Every leg carries "
        "the model's own probability; the combined number is those "
        "probabilities multiplied, so do not present it as a guarantee — at "
        "ten or fifteen legs the joint figure is small and must be stated "
        "as-is, with the weakest leg named. "
        "Do NOT use web_search for this — the numbers are computed here from "
        "season data."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {"type": "STRING",
                     "description": "'build' (pick legs for the user) or "
                                    "'check' (evaluate matches they named)."},
            "matches": {"type": "STRING",
                        "description": "check mode: 'Team A vs Team B, Team C "
                                       "vs Team D'."},
            "league": {"type": "STRING",
                       "description": "build mode: competition to draw legs "
                                      "from, e.g. 'premier league'. Empty "
                                      "means the main leagues."},
            "days": {"type": "INTEGER",
                     "description": "How many days ahead to look. Default 3."},
            "legs": {"type": "INTEGER",
                     "description": "How many legs the ticket should have. "
                                    "Default 3, max 15."},
            "market": {"type": "STRING",
                       "description": "'auto' (default: the safest price on "
                                      "each match) or 'dc' (double chance "
                                      "only, lower risk per leg)."},
        },
        "required": ["mode"],
    },
    "behavior": "NON_BLOCKING",
}


def _say(player, text: str) -> None:
    if player is None:
        return
    try:
        player.write_log(f"JARVIS: {text}")
    except Exception:
        pass


# A league list and a match list are both "things separated by punctuation".
_SPLIT = re.compile(r"\s*(?:,|;|\n|\+|/|\bdan\b|\band\b)\s*", re.IGNORECASE)
# "City vs Fulham", "City v Fulham", "City lawan Fulham", "City - Fulham".
_PAIR = re.compile(r"\s+(?:vs\.?|v|lawan|versus|against|–|—|-)\s+", re.IGNORECASE)


def _pairs(raw: str) -> list[tuple[str, str]]:
    """'A vs B, C vs D' -> [('A','B'), ('C','D')]. Unparseable parts are kept
    as (chunk, '') so the caller can say which one it could not read instead
    of silently dropping half a ticket."""
    out: list[tuple[str, str]] = []
    for chunk in _SPLIT.split(raw or ""):
        chunk = chunk.strip()
        if not chunk:
            continue
        parts = _PAIR.split(chunk, maxsplit=1)
        if len(parts) == 2:
            out.append((parts[0].strip(), parts[1].strip()))
        else:
            out.append((chunk, ""))
    return out


def _options(p: dict, home: str, away: str) -> list[tuple[float, str, str]]:
    """Every price on one match: (probability, market key, plain-language pick).

    Double chance sits in the same list on purpose. It is the same model
    output, and on an even match 1X at 78% is a better leg than 1 at 41% —
    refusing it would make the tool pick the worse bet out of politeness.
    """
    pr = p["probabilities"]
    dc = p["double_chance"]
    return [
        (float(pr["home_win"]), "1", f"{home} menang"),
        (float(pr["draw"]), "X", "seri"),
        (float(pr["away_win"]), "2", f"{away} menang"),
        (float(dc["1X"]), "1X", f"{home} menang atau seri"),
        (float(dc["X2"]), "X2", f"seri atau {away} menang"),
        (float(dc["12"]), "12", f"{home} atau {away} menang"),
    ]


def _pick_leg(p: dict, home: str, away: str, market: str = "auto"):
    """The leg to take on one match, or None when nothing is worth taking."""
    opts = _options(p, home, away)
    if market == "dc":
        opts = [o for o in opts if o[1] in ("1X", "X2", "12")]
    # Highest probability wins; on a near-tie the straight result is preferred
    # because it pays more than the same match's double chance.
    best = max(opts, key=lambda o: (round(o[0], 1), 0 if o[1] in ("1", "X", "2") else 1))
    prob, key, label = best
    if prob < 50.0:
        return None
    return {
        "home": home,
        "away": away,
        "market": key,
        "pick": label,
        "prob": prob,
        "confidence": float(p.get("confidence") or 0.0),
        "score": (p.get("top_scores") or [{}])[0].get("score", ""),
        "league_name": p.get("league_name") or p.get("league") or "",
        "xg": p.get("expected_goals"),
    }


def _rank_key(leg: dict) -> float:
    """Sort key: a confident 72% leg beats a lucky 74% one."""
    return leg["prob"] * (0.55 + min(100.0, leg["confidence"]) / 220.0)


def _leg_item_full(p: dict, leg: dict) -> dict:
    """The full card for a leg: real split, real DC, real over/under."""
    pr = p["probabilities"]
    ou = p.get("over_under") or {}
    top = (p.get("top_scores") or [{}])[0]
    return {
        "league": p.get("league") or "",
        "league_name": p.get("league_name") or "",
        "home": leg["home"],
        "away": leg["away"],
        "when": "",
        "state": "pre",
        "score": None,
        "parlay_leg": {"market": leg["market"], "pick": leg["pick"],
                       "prob": leg["prob"]},
        "forecast": {
            "home_win": pr["home_win"],
            "draw": pr["draw"],
            "away_win": pr["away_win"],
            "btts": pr["btts_yes"],
            "over_2_5": pr["over_2_5"],
            "over_under": ou,
            "expected_goals": p.get("expected_goals"),
            "dc_1x": p["double_chance"]["1X"],
            "dc_12": p["double_chance"]["12"],
            "dc_x2": p["double_chance"]["X2"],
            "top_score": top.get("score", ""),
            "top_score_prob": top.get("prob", 0),
            "confidence": p.get("confidence", 0),
        },
    }


def _combined(legs: list[dict]) -> tuple[float, float]:
    """(joint probability %, fair decimal odds) for the whole ticket."""
    joint = 1.0
    for leg in legs:
        joint *= max(0.0, min(1.0, leg["prob"] / 100.0))
    pct = joint * 100.0
    return pct, (1.0 / joint if joint > 0 else 0.0)


def _summary(legs: list[dict], days: int | None = None) -> str:
    pct, odds = _combined(legs)
    weakest = min(legs, key=lambda l: l["prob"])
    lines = [
        f"{len(legs)} leg · peluang gabungan {pct:.1f}% "
        f"(adil {odds:.2f}) · gagal {100 - pct:.1f}%",
        f"Leg paling lemah: {weakest['home']} v {weakest['away']} — "
        f"{weakest['pick']} {weakest['prob']:.0f}%",
        "Angka dari model liga musim ini. Produk peluang cuma valid kalau "
        "tiap laga beda, jadi nggak ada dua leg dari satu pertandingan.",
    ]
    return "\n".join(lines)


def _spoken(legs: list[dict]) -> str:
    pct, odds = _combined(legs)
    lines = [f"Parlay {len(legs)} leg, peluang gabungan {pct:.1f}% "
             f"(adil {odds:.2f})."]
    for i, leg in enumerate(legs, 1):
        lines.append(f"{i}. {leg['home']} v {leg['away']} — {leg['pick']} "
                     f"{leg['prob']:.0f}%")
    lines.append("Itu estimasi dari data musim ini, bukan jaminan.")
    return " ".join(lines)


def _predict_many(pairs: list[tuple[str, str]], league: str = "",
                  deadline_s: float = 14.0) -> list[dict]:
    """Predict several fixtures in parallel, keeping the input order.

    Sequential prediction cost eight seconds for twenty matches; the fetch
    behind each one is mostly waiting, so the threads are the whole speed fix.
    Anything past the deadline is dropped instead of holding the pop-out.
    """
    from core import football

    results: dict[int, dict] = {}
    deadline = time.monotonic() + deadline_s
    with cf.ThreadPoolExecutor(max_workers=6) as pool:
        futures = {
            pool.submit(football.predict, home, away, league): (i, home, away)
            for i, (home, away) in enumerate(pairs)
        }
        for fut in cf.as_completed(futures, timeout=None):
            i, home, away = futures[fut]
            if time.monotonic() > deadline:
                continue
            try:
                results[i] = fut.result()
            except Exception:
                continue
    return [results[i] for i in sorted(results)]


def _open(player, legs: list[dict], note: str) -> None:
    if player is None or not hasattr(player, "show_football"):
        return
    items = [leg["_item"] for leg in legs]
    try:
        player.show_football(items, note, mode="parlay", slot="parlay")
    except Exception:
        pass


def _build(player, league: str, days: int, legs_wanted: int,
           market: str) -> str:
    from core import football

    # 1. Fixtures first: this is the cheap call, and it is what the window can
    #    announce while the model work happens.
    try:
        rows = football.schedule(league=league, days_ahead=days, limit=60)
    except Exception as e:
        return f"Gagal ambil jadwal buat parlay: {e}"
    if league:
        try:
            comp = football.find_league(league)
        except Exception:
            comp = None
        if comp is None:
            return (f"Liga '{league}' gak ada di daftar gue. Coba 'premier "
                    f"league', 'la liga', 'champions league', atau kosongin "
                    f"buat liga besar.")
    if not rows:
        return f"Gak ada laga dalam {days} hari buat nyusun parlay."

    # 2. Say so immediately, so the window exists before the numbers do.
    _say(player, f"Ngitung {legs_wanted} leg dari {len(rows)} laga...")
    try:
        player and player.show_football(
            [], f"Ngitung {legs_wanted} leg dari {len(rows)} laga…",
            mode="parlay", slot="parlay")
    except Exception:
        pass

    # 3. Only the fixtures worth predicting. A world-wide day is 200+, and the
    #    budget is spent on the competitions people actually bet on.
    priority = {
        "eng.1": 0, "esp.1": 0, "ita.1": 0, "ger.1": 0, "fra.1": 0,
        "uefa.champions": 1, "uefa.europa": 1, "idn.1": 1,
        "ned.1": 2, "por.1": 2, "tur.1": 2, "bra.1": 2, "arg.1": 2, "usa.1": 2,
    }
    ranked = sorted(rows, key=lambda r: (priority.get(r.get("league", ""), 5),
                                         str(r.get("when", ""))))
    # Three fixtures predicted per leg wanted, so the 50% filter and the
    # one-leg-per-match rule still leave enough to fill a long ticket. A
    # fifteen-leg request needs a bigger pool than a three-leg one, otherwise
    # the ticket quietly comes back short and looks like a data problem.
    pool = ranked[:min(len(ranked), max(12, legs_wanted * 3))]

    preds = _predict_many([(r["home"], r["away"]) for r in pool],
                          league="",
                          deadline_s=18.0 if legs_wanted > 8 else 14.0)

    # 4. One leg per match, best first, never two legs from the same fixture.
    candidates: list[tuple[dict, dict]] = []
    seen: set[tuple[str, str]] = set()
    for p in preds:
        home = (p.get("home") or {}).get("name") or ""
        away = (p.get("away") or {}).get("name") or ""
        key = (home.lower(), away.lower())
        if not home or key in seen:
            continue
        seen.add(key)
        leg = _pick_leg(p, home, away, market)
        if leg is not None:
            candidates.append((p, leg))
    candidates.sort(key=lambda pl: _rank_key(pl[1]), reverse=True)
    chosen = candidates[:max(1, min(15, legs_wanted))]
    if not chosen:
        return ("Nggak ada laga yang peluangnya cukup buat dijadiin leg — "
                "semua di bawah 50%. Coba liga lain atau rentang hari lain.")

    legs = []
    for p, leg in chosen:
        leg["_item"] = _leg_item_full(p, leg)
        legs.append(leg)

    note = _summary(legs)
    _open(player, legs, note)
    return _spoken(legs)


def _check(player, raw: str, market: str) -> str:
    pairs = _pairs(raw)
    if not pairs:
        return ("Sebutin laganya: 'Man City vs Fulham, Arsenal vs Chelsea'. "
                "Pisahin pakai koma.")
    bad = [a for a, b in pairs if not b]
    if bad:
        return (f"Gak kebaca: {', '.join(bad[:3])}. Formatnya 'Tim A vs Tim B'.")
    if len(pairs) > 15:
        pairs = pairs[:15]

    _say(player, f"Ngitung {len(pairs)} leg...")
    try:
        player and player.show_football(
            [], f"Ngitung {len(pairs)} leg…", mode="parlay", slot="parlay")
    except Exception:
        pass

    preds = _predict_many(pairs, deadline_s=16.0)
    legs = []
    failed = []
    for p in preds:
        home = (p.get("home") or {}).get("name") or ""
        away = (p.get("away") or {}).get("name") or ""
        leg = _pick_leg(p, home, away, market)
        if leg is None:
            failed.append(f"{home} v {away}")
            continue
        leg["_item"] = _leg_item_full(p, leg)
        legs.append(leg)
    if not legs:
        return ("Semua laga itu peluang terbaiknya di bawah 50%, jadi gue "
                "nggak masukin. Ganti market atau pilih laga lain.")

    _open(player, legs, _summary(legs))
    msg = _spoken(legs)
    if failed:
        msg += f" Yang gue skip karena peluangnya di bawah 50%: {', '.join(failed)}."
    return msg


def run(parameters: dict, player=None, session_memory=None) -> str:
    params = parameters or {}
    mode = str(params.get("mode") or "build").strip().lower()
    market = str(params.get("market") or "auto").strip().lower()
    if market not in ("auto", "dc"):
        market = "auto"

    try:
        from core import football
    except Exception as e:
        return f"Modul data bola gagal dimuat: {e}"

    try:
        legs_wanted = int(params.get("legs") or 3)
    except (TypeError, ValueError):
        legs_wanted = 3
    legs_wanted = max(1, min(15, legs_wanted))

    try:
        days = int(params.get("days") if params.get("days") is not None else 3)
    except (TypeError, ValueError):
        days = 3
    days = max(0, min(14, days))

    league = str(params.get("league") or "").strip()
    matches = str(params.get("matches") or "").strip()

    try:
        if mode in ("check", "cek", "evaluate") or matches:
            if not matches:
                return ("Buat cek parlay, sebutin laganya dulu: "
                        "'Man City vs Fulham, Arsenal vs Chelsea'.")
            return _check(player, matches, market)
        return _build(player, league, days, legs_wanted, market)
    except Exception as e:
        return f"Parlay gagal: {e}"
