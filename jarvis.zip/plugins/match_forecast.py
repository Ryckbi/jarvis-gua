"""
Match forecast plugin — analysis and prediction for football matches.

Two things this does:

  * forecasts one named fixture, in words, with the win/draw/win split, both
    teams to score, over/under, double chance and the likeliest scorelines;
  * opens the MATCH FORECAST pop-out, which lists the next ten fixtures across
    every competition and country ESPN covers, each with a full forecast.

Data is ESPN's public soccer API (no key, no quota, 220 competitions). Every
number comes from this season's league table; nothing is invented, and a match
the model cannot forecast is shown as "no forecast" rather than guessed at.

Per AGENTS.md this runs on a worker thread: the network work happens in a
daemon thread and the pop-out is filled through player.show_football(), which
is thread-safe. run() itself returns immediately.
"""
from __future__ import annotations

import re
import threading

PLUGIN = {
    "name": "match_forecast",
    "description": (
        "Football (soccer) match analysis and prediction for ANY league or "
        "country: Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, "
        "Champions League, Liga Indonesia, Saudi Pro League, MLS, international "
        "tournaments and more. Use this when the user asks who will win a match, "
        "for win/draw/loss percentages, both teams to score, over/under goals, "
        "double chance, exact score predictions, a list of upcoming fixtures, "
        "or a timetable of what is being played. Parameters: mode='predict' "
        "with home/away/league for one match; mode='open' for a floating window "
        "of the next ten matches WITH forecasts; mode='schedule' for a "
        "timetable with each match's forecast attached — one competition when "
        "`league` is given, every competition when it is empty, over `days` "
        "(default 7); mode='leagues' to list competitions. "
        "SEVERAL LEAGUES AT ONCE: put them all in `league` separated by commas "
        "('premier league, la liga') and EACH competition gets its own pop-out "
        "window, side by side, all filled at the same time. Asking for today's "
        "schedule always includes the analysis; never answer a schedule request "
        "with fixtures alone. 'EPL doang' means league='premier league'; "
        "'semua laga seminggu' means league empty. Do NOT use web_search for "
        "match predictions — this tool computes them from real season data."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode": {
                "type": "STRING",
                "description": "'predict' (one match with numbers), 'open' "
                               "(pop-out with the next 10 forecasts), "
                               "'schedule' (a timetable: fixtures only, one "
                               "league or all, over a date range) or "
                               "'leagues'.",
            },
            "home": {"type": "STRING",
                     "description": "Home team, as the user said it."},
            "away": {"type": "STRING",
                     "description": "Away team, as the user said it."},
            "league": {
                "type": "STRING",
                "description": "Competition name or slug, e.g. 'premier league', "
                               "'la liga', 'champions league', 'fa cup', 'liga "
                               "indonesia'. Leave empty to search the main "
                               "leagues — or, in 'schedule' mode, to list every "
                               "competition.",
            },
            "days": {
                "type": "INTEGER",
                "description": "schedule mode: how many days ahead to list, "
                               "0 = today only, max 30. Default 7.",
            },
        },
        "required": ["mode"],
    },
    "behavior": "NON_BLOCKING",
}


# Words that separate one competition from another when several are asked for
# in one breath. Commas are the main one; "dan"/"and" and a slash show up in
# speech-to-text often enough to be worth handling.
_LEAGUE_SPLIT = re.compile(r"\s*(?:,|;|\bdan\b|\band\b|\+)\s*", re.IGNORECASE)


def _split_leagues(raw: str) -> list[str]:
    """"premier league, la liga" -> ['premier league', 'la liga'].

    Deduplicated and order-preserving, so asking for the same competition twice
    does not open the same window twice and the first one asked for stays first
    on screen.
    """
    out: list[str] = []
    seen: set[str] = set()
    for part in _LEAGUE_SPLIT.split(raw or ""):
        name = part.strip()
        if not name:
            continue
        key = name.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(name)
    return out


def _say(player, text: str) -> None:
    if player is None:
        return
    try:
        player.write_log(f"JARVIS: {text.splitlines()[0]}")
    except Exception:
        pass


def _ensure_refresh(player, league: str = "", days: int = 7,
                    mode: str = "forecast", slot: str = "board") -> None:
    """Give the pop-out a way to reload itself without blocking the Qt thread.

    The reload has to remember what was asked for. It used to be a fixed
    `slate(10, 2 days, all leagues)`, so a window opened on the EPL quietly
    reset itself to the default ten matches the next time it refreshed — the
    user's filter survived only until the first timer tick.
    """
    if player is None or not hasattr(player, "on_football_refresh"):
        return
    try:
        from core import football

        def _fetch(which=None):
            # `which` is the slot of the window asking. A league window must
            # refresh itself, not the shared board.
            target = which or slot

            def _work():
                try:
                    if mode == "schedule":
                        rows = football.schedule(league=league, days_ahead=days,
                                                 forecast=True)
                        player.show_football(rows, "", mode="schedule",
                                             slot=target)
                    else:
                        items = football.slate(limit=10, league=league,
                                               days_ahead=days)
                        player.show_football(items, slot=target)
                except Exception as e:
                    player.show_football([], f"Could not refresh: {e}",
                                         mode=mode, slot=target)

            threading.Thread(target=_work, daemon=True).start()

        player.on_football_refresh(_fetch)
    except Exception:
        pass


# Diagnostik) — the notes core/football.py produces, said the way a person
# would say them instead of a model's internal label.
_READ = {
    "both teams likely to score": "dua-duanya kemungkinan besar nyetak",
    "open game, over 2.5 goals likely": "laga kebuka, over 2.5 gol",
    "tight game, under 2.5 goals likely": "laga ketat, under 2.5 gol",
    "very even — draw carries real weight": "sangat imbang, seri beneran masuk hitungan",
}


def _note_id(note: str) -> str:
    if note in _READ:
        return _READ[note]
    if note.endswith("unlikely to lose"):
        return note.replace(" unlikely to lose", " kemungkinan besar gak kalah")
    return note


def _ou_line(ou: dict, lang: str = "id") -> str:
    """One line that names each goal line instead of one floating number.

    "Over 2.5: 50%" answers a question nobody asked precisely, because an
    over/under has to say WHICH line. This prints the four that matter and
    marks the one closest to a coin flip, which is the one where the choice
    actually carries weight.
    """
    if not ou:
        return ""
    try:
        lines = {k: float(v.get("over", 0)) for k, v in ou.items()}
    except Exception:
        return ""
    if not lines:
        return ""
    near = min(lines, key=lambda k: abs(lines[k] - 50))
    parts = []
    for k in sorted(lines, key=lambda x: float(x)):
        over = lines[k] >= 50
        side = "over" if over else "under"
        val = lines[k] if over else 100 - lines[k]
        mark = "*" if k == near else ""
        parts.append(f"{side} {k} {val:.0f}%{mark}")
    tail = (f" (* = the line closest to even)"
            if lang == "en" else
            f" (* = garis paling deket 50-50)")
    return "Over/under: " + " · ".join(parts) + tail


def _squad_line(r: dict, lang: str = "id") -> str:
    """One spoken sentence about players: scorer, cards, and what is missing.

    Deliberately short. The card carries the detail; spoken aloud, three names
    and a caveat is already at the edge of what a listener keeps.
    """
    sq = r.get("squads") or {}
    parts = []
    for side in ("home", "away"):
        d = sq.get(side) or {}
        if not d.get("available"):
            continue
        team = d.get("team") or ""
        bits = []
        top = d.get("top_scorer")
        if top and top.get("goals"):
            bits.append(f"{top['name']} {top['goals']} gol")
        if d.get("reds"):
            bits.append(f"{d['reds'][0]['name']} kena kartu merah")
        elif d.get("one_from_ban"):
            bits.append(f"{d['one_from_ban'][0]['name']} satu kartu lagi "
                        f"kena sanksi")
        if bits:
            parts.append(f"{team}: " + ", ".join(bits))
    if not parts:
        return ""
    head = ("Squad news — " if lang == "en" else "Soal pemain — ")
    tail = (" Injury status is not in this feed, so that is cards and "
            "minutes, not fitness."
            if lang == "en" else
            " Status cedera gak ada di feed ini, jadi itu soal kartu dan "
            "menit main, bukan kebugaran.")
    return head + "; ".join(parts) + "." + tail


def _predict_reply(home: str, away: str, league: str, lang: str = "id") -> str:
    """Human summary of predict(). `lang` follows the user's last message."""
    from core import football
    r = football.predict(home, away, league)
    p = r["probabilities"]
    d = r["double_chance"]
    h, a = r["home"]["name"], r["away"]["name"]
    comp = r.get("league_name") or r["league"]
    top = ", ".join(f"{s['score']} ({s['prob']:.0f}%)" for s in r["top_scores"][:3])
    ou = r.get("over_under") or {}
    xg = r.get("expected_goals")

    if lang == "en":
        lines = [
            f"{h} vs {a}, {comp}.",
            f"{h} {p['home_win']:.0f}% · draw {p['draw']:.0f}% · {a} {p['away_win']:.0f}%.",
            f"Double chance: 1X {d['1X']:.0f}%, 12 {d['12']:.0f}%, X2 {d['X2']:.0f}% "
            f"(safest: {_best_dc(d, 'en')}).",
            f"BTTS {p['btts_yes']:.0f}%.",
            _ou_line(ou, "en") + (f" (model expects {xg:.1f} goals.)"
                                  if isinstance(xg, (int, float)) else ""),
            f"Likeliest scoreline: {top}.",
        ]
        sq_line = _squad_line(r, "en")
        if sq_line:
            lines.append(sq_line)
        if r["notes"]:
            lines.append("; ".join(r["notes"]) + ".")
        for x in (r.get("reasons") or [])[:2]:
            lines.append(f"{x.get('title', '')}: {x.get('detail', '')}")
        lines.append("That's the model's read off this season's numbers, "
                     "not betting advice.")
        return "\n".join(lines)

    # Indonesian, with the code-switching a real person would use.
    lines = [
        f"{h} vs {a}, {comp}.",
        f"{h} {p['home_win']:.0f}%, seri {p['draw']:.0f}%, {a} {p['away_win']:.0f}%.",
        f"Double chance: 1X {d['1X']:.0f}%, 12 {d['12']:.0f}%, X2 {d['X2']:.0f}% "
        f"(paling aman {_best_dc(d)}).",
        f"BTTS {p['btts_yes']:.0f}%.",
        _ou_line(ou, "id") + (f" — model pegang {xg:.1f} gol total."
                              if isinstance(xg, (int, float)) else ""),
        f"Skor paling mungkin: {top}.",
    ]
    # Squad line, spoken: the same facts the card shows, kept short because
    # this is read aloud. The injury caveat is said once, plainly, rather than
    # left for the listener to assume the opposite.
    sq_line = _squad_line(r, "id")
    if sq_line:
        lines.append(sq_line)
    if r["notes"]:
        lines.append("Bacaan gue: " + "; ".join(_note_id(n) for n in r["notes"]) + ".")
    top_reasons = [x for x in (r.get("reasons") or [])[:2] if x.get("detail")]
    if top_reasons:
        lines.append("Alasannya: " + " ".join(
            f"{x['title']} — {x['detail']}" for x in top_reasons))
    lines.append(f"Confidence {r['confidence']:.0f}% dari "
                 f"{r['sample']['home_played']} laga {h} dan "
                 f"{r['sample']['away_played']} laga {a} musim ini. "
                 f"Ini hitungan model, bukan saran taruhan.")
    return "\n".join(lines)


_DC_COVER = {
    "id": {
        "1X": "tuan rumah menang atau seri",
        "X2": "seri atau tim tamu menang",
        "12": "salah satu tim menang, seri nggak dihitung",
    },
    "en": {
        "1X": "home win or draw",
        "X2": "draw or away win",
        "12": "either side wins, draw excluded",
    },
}


def _best_dc(d: dict, lang: str = "id") -> str:
    """Which double chance is the safe pick, and what it actually covers.

    Quoting three percentages without saying which is the sensible one just
    moves the question along. This names it and spells out the two results.
    """
    best = max(d, key=lambda k: d[k])
    return f"{best} — {_DC_COVER.get(lang, _DC_COVER['id'])[best]}"


def _single_item(r: dict, when: str = "", state: str = "pre") -> dict:
    """predict() -> the shape FootballWindow draws, reasons included."""
    p = r["probabilities"]
    top = r["top_scores"][0] if r["top_scores"] else {"score": "", "prob": 0}
    ou = r.get("over_under") or {}
    xg = r.get("expected_goals")
    return {
        "league": r["league"],
        "league_name": r.get("league_name") or r["league"],
        "home": r["home"]["name"],
        "away": r["away"]["name"],
        "when": when,
        "state": state,
        "score": None,
        "expanded": True,
        "reasons": r.get("reasons") or [],
        # Carried through so the card can draw its own section; the same data
        # the spoken answer cites, never a second fetch that could disagree.
        "squads": r.get("squads") or {},
        "forecast": {
            "home_win": p["home_win"],
            "draw": p["draw"],
            "away_win": p["away_win"],
            "btts": p["btts_yes"],
            "over_2_5": p["over_2_5"],
            "over_under": ou,
            "expected_goals": xg,
            "dc_1x": r["double_chance"]["1X"],
            "dc_12": r["double_chance"]["12"],
            "dc_x2": r["double_chance"]["X2"],
            "top_score": top["score"],
            "top_score_prob": top["prob"],
            "confidence": r["confidence"],
        },
    }


def _user_lang() -> str:
    """The language the user has been speaking, from the app's own memory.

    main.py already saves category='identity', key='language' the first time it
    detects a language, so reading it beats guessing from a team name. Anything
    that looks Indonesian (or reads as Indonesian-flavoured) gets 'id'."""
    try:
        from memory.memory_manager import load_memory, _entry_value
        mem = load_memory()
        entry = (mem.get("identity") or {}).get("language")
        value = (_entry_value(entry) if entry else "") or ""
    except Exception:
        value = ""
    v = value.strip().lower()
    if not v:
        return "id"          # the person this was built for speaks Indonesian
    return "id" if any(k in v for k in ("indones", "melayu", "malay")) else "en"


def _text_schedule(name: str, rows: list, days: int) -> str:
    """A schedule as words, with the numbers, when there is no window.

    This is the phone/cloud path and the tests. It leads with the matches that
    actually have a forecast, because "3-0 to the home side" is the answer and
    the fixture list is only its address.
    """
    if not rows:
        return f"{name}: gak ada laga {_range_wording(days)}."
    # Lead with the ones that have numbers. A world-wide day is 242 matches
    # and the forecast budget is spent on the leagues people follow, so the
    # feed's own order can put twelve unforecast fixtures first and make it
    # look like nothing was analysed.
    ranked = sorted(rows, key=lambda r: (0 if r.get("forecast") else 1,
                                         str(r.get("when", ""))))
    lines = [f"{name} — {_range_wording(days)}, {len(rows)} laga:"]
    for r in ranked[:12]:
        fc = r.get("forecast") or {}
        when = str(r.get("when", ""))[11:16]
        head = f"{when} {r['home']} v {r['away']}"
        if fc:
            lines.append(
                f"{head} — {fc['home_win']:.0f}/{fc['draw']:.0f}/"
                f"{fc['away_win']:.0f}%, BTTS {fc['btts']:.0f}%, "
                f"top skor {fc.get('top_score') or '?'}")
        else:
            lines.append(head)
    if len(rows) > 12:
        lines.append(f"...dan {len(rows) - 12} laga lain di jendelanya.")
    return "\n".join(lines)


def _range_wording(days: int) -> str:
    """'7 hari' → 'seminggu', so the spoken line matches what was asked."""
    if days == 0:
        return "hari ini"
    if days == 1:
        return "besok"
    if 6 <= days <= 8:
        return "seminggu"
    if 13 <= days <= 15:
        return "dua minggu"
    return f"{days} hari"


def run(parameters: dict, player=None, session_memory=None) -> str:
    mode = str(parameters.get("mode") or "predict").strip().lower()
    home = str(parameters.get("home") or "").strip()
    away = str(parameters.get("away") or "").strip()
    league = str(parameters.get("league") or "").strip()

    try:
        from core import football
    except Exception as e:
        return f"Waduh, modul prediksi gagal dimuat: {e}"

    # ── list competitions ────────────────────────────────────────────────────
    if mode == "leagues":
        try:
            table = football.leagues()
        except Exception as e:
            return f"Gagal ambil daftar liga: {e}"
        by_country: dict[str, list[str]] = {}
        for lg in table:
            by_country.setdefault(lg["country"] or "Other", []).append(lg["name"])
        lines = [f"I cover {len(table)} football competitions."]
        for country in sorted(by_country):
            lines.append(f"{country}: " + ", ".join(by_country[country][:6]))
        text = "\n".join(lines[:26])
        _say(player, text)
        if player:
            try:
                player.show_content("FOOTBALL — COMPETITIONS", text[:4000])
            except Exception:
                pass
        return (f"I cover {len(table)} competitions across every confederation — "
                f"premier league, la liga, serie a, bundesliga, ligue 1, the "
                f"Champions League, Liga Indonesia and more. Ask me about any "
                f"match.")

    # ── timetable: one competition or all, a date range, no forecasts ────────
    if mode in ("schedule", "fixtures", "jadwal", "timetable", "calendar"):
        try:
            days = int(parameters.get("days") if parameters.get("days") is not None else 7)
        except (TypeError, ValueError):
            days = 7
        days = max(0, min(30, days))

        # "premier league, la liga" is a real request: two leagues, two windows,
        # both filled at once so they can be compared instead of read in turn.
        wanted = _split_leagues(league)

        # Resolve every name BEFORE opening anything. A typo in the second
        # league must not leave the first window half-loaded with an error
        # floating next to it.
        comps = []
        for name in wanted:
            try:
                comp = football.find_league(name)
            except Exception as e:
                return f"Gagal cek nama liganya: {e}"
            if comp is None:
                return (f"Liga atau turnamen '{name}' gak ada di daftar gue. "
                        f"Coba nama lain — misal 'premier league', 'la liga', "
                        f"'champions league', 'piala fa', 'liga indonesia'.")
            comps.append(comp)

        span = _range_wording(days)

        if player is None:
            # No window to draw into: answer in words, with the numbers.
            try:
                if comps:
                    parts = []
                    for comp in comps:
                        rows = football.schedule(league=comp["slug"],
                                                 days_ahead=days, forecast=True)
                        parts.append(_text_schedule(comp["name"], rows, days))
                    return "\n\n".join(parts) if parts else "Gak ada laga."
                rows = football.schedule(days_ahead=days, forecast=True)
            except Exception as e:
                return f"Gagal ambil jadwal: {e}"
            if not rows:
                return f"Gak ada laga {span} buat itu."
            return _text_schedule("Semua liga", rows, days)

        # Each competition gets its own board, keyed by slug in the window.
        if not comps:
            comps = [{"slug": "", "name": "Semua liga"}]

        for comp in comps:
            slug = comp["slug"]
            name = comp["name"]
            _ensure_refresh(player, league=slug, days=days, mode="schedule",
                            slot=f"league:{slug or 'all'}")

            def _work(slug=slug, name=name):
                try:
                    rows = football.schedule(league=slug, days_ahead=days,
                                             forecast=True)
                    note = f"{name} — {span}"
                    player.show_football(rows, note, mode="schedule",
                                         slot=f"league:{slug or 'all'}")
                except Exception as e:
                    try:
                        player.show_football(
                            [], f"Gagal ambil jadwal: {e}", mode="schedule",
                            slot=f"league:{slug or 'all'}")
                    except Exception:
                        pass

            threading.Thread(target=_work, daemon=True).start()

        if len(comps) == 1:
            return (f"Bentar, gue susun jadwal {comps[0]['name']} buat {span} — "
                    f"laga plus analisanya.")
        names = ", ".join(c["name"] for c in comps)
        return (f"Bentar, gue buka {len(comps)} jendela sekaligus — {names} — "
                f"{span}, masing-masing sama analisanya.")

    # ── pop-out window ───────────────────────────────────────────────────────
    if mode in ("open", "window", "show", "slate"):
        # "Buka prediksi EPL" is a real request: the window keeps the filter,
        # including across its own timed refresh.
        try:
            open_days = int(parameters.get("days") if parameters.get("days") is not None else 2)
        except (TypeError, ValueError):
            open_days = 2
        open_days = max(0, min(14, open_days))
        _ensure_refresh(player, league=league, days=open_days)
        if player is None:
            return ("Jendela prediksi cuma bisa dibuka di dalam aplikasi. "
                    "Sebutin dua tim aja, gue prediksiin di sini.")

        # A league named here used to be quietly ignored: the window always
        # opened on all competitions, which is the exact complaint the
        # schedule mode fixed. Resolve it before opening so a typo answers
        # instead of showing Liverpool v Arsenal when EPL was asked for.
        comp = None
        if league:
            try:
                comp = football.find_league(league)
            except Exception as e:
                return f"Gagal cek nama liganya: {e}"
            if comp is None:
                return (f"Liga atau turnamen '{league}' gak ada di daftar gue. "
                        f"Coba 'premier league', 'champions', 'piala fa', "
                        f"'liga indonesia'.")
        slug = comp["slug"] if comp else ""

        def _work():
            try:
                # "No matches in two days" is true and useless — the Champions
                # League plays Tue/Wed, so a Sunday ask lands on nothing. Look
                # further out instead of showing an empty window, and say which
                # window was actually used.
                items, used = [], open_days
                for span in (open_days, max(open_days, 7), max(open_days, 14)):
                    items = football.slate(limit=10, league=slug,
                                           days_ahead=span)
                    used = span
                    if items:
                        break
                player.show_football(items)
                if not items:
                    _say(player, f"Belum ada laga yang bisa diprediksi dalam "
                                 f"{used} hari ke depan.")
            except Exception as e:
                try:
                    player.show_football([], f"Could not load fixtures: {e}")
                except Exception:
                    pass

        threading.Thread(target=_work, daemon=True).start()
        where = comp["name"] if comp else "semua liga"
        span = _range_wording(open_days)
        return (f"Bentar, gue bukain jendela prediksinya — 10 laga terdekat "
                f"{where}, {span} ke depan, plus persentasenya.")

    # ── one match ────────────────────────────────────────────────────────────
    if not home or not away:
        return ("Sebutin dua timnya dulu — misal 'siapa yang menang Man City "
                "lawan Arsenal'.")

    box: dict = {}

    def _work():
        try:
            lang = _user_lang()
            box["text"] = _predict_reply(home, away, league, lang)
            # The analysis pops out by itself: percentages on screen, with the
            # reasoning under them. Speaking it alone leaves the numbers in the
            # air, and the pop-out is where the "why" has room to be read.
            try:
                from core import football
                r = football.predict(home, away, league)
                item = _single_item(r)
                if player is not None and hasattr(player, "show_football"):
                    # Its own window: asking about a second match must not
                    # replace the first one the user is still reading.
                    player.show_football([item], "", expanded=True,
                                         slot="analysis")
            except Exception:
                pass
        except Exception as e:
            box["text"] = f"Gagal analisa laga itu: {e}"

    t = threading.Thread(target=_work, daemon=True)
    t.start()
    t.join(12.0)          # the fetch is cached after the first call
    text = box.get("text") or (
        "Data liganya masih loading, coba tanya lagi bentar."
    )
    _say(player, text)
    if player and "could not" not in text and "still loading" not in text:
        try:
            player.show_content(f"{home} v {away}".upper(), text[:4000])
        except Exception:
            pass
    return text
