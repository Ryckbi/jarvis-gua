"""gui/slab_avatar.py — the slab: a glass pill with a face, and the window it floats in.

Replaces the holographic head (core/avatar.py) as MARK's face. Three looks, one
for each thing the assistant can be doing:

    SLEEP   the slab is nearly dead — a dim, cold glass with the faintest
            colour left in it. Eyes are shut arcs and one "z" drifts up and
            down. Shown while muted, quiet, sleeping or still starting.
    SPEAK   fully lit, with a glow outside the slab. The mouth opens and
            closes with the voice level.
    LISTEN  calmer: the eyes wander slowly, the mouth is a small oval, and a
            ripple leaves the slab's edge and fades. Also used while thinking.

Everything is software QPainter, same as the rest of the HUD — no OpenGL, no
GPU, no new dependency. Colours are read from the palette at paint time, so
the live re-theme recolours the slab for free.

Two pieces live here:

    SlabFace     the animation + painting. Knows nothing about windows; the
                 HUD canvas uses one, and so does the pop-out.
    SlabPopout   a frameless, transparent top-level window that holds a
                 SlabFace on the desktop, OUTSIDE the app window. Drag to
                 move, scroll to resize, right-click for the menu, optional
                 always-on-top.

The pop-out owns no audio plumbing. It polls the HUD canvas (state, speaking,
muted, the smoothed voice level) on its own timer, so there is still exactly
one audio source and the mouth cannot drift from the waveform.
"""
from __future__ import annotations

import math
import random

from PyQt6.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import (
    QColor, QCursor, QFont, QGuiApplication, QLinearGradient, QPainter, QPen,
)
from PyQt6.QtWidgets import QMenu, QWidget

from gui.theme import C, qcol

# States that count as "awake". Everything else (MUTED, QUIET, SLEEPING,
# INITIALISING, …) is the sleeping look.
_AWAKE = ("LISTENING", "THINKING", "PROCESSING", "SPEAKING")


def _k(dt: float, tau: float) -> float:
    """Frame-rate independent smoothing factor."""
    return 1.0 - math.exp(-max(0.0, dt) / max(1e-4, tau))


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def _alpha(col: QColor, a: float) -> QColor:
    c = QColor(col)
    c.setAlphaF(max(0.0, min(1.0, a)))
    return c


def _hsv(col: QColor, dh: float = 0.0, sk: float = 1.0, vk: float = 1.0) -> QColor:
    h, s, v, _ = col.getHsvF()
    if h < 0:
        h = 0.0
    return QColor.fromHsvF((h + dh) % 1.0, max(0.0, min(1.0, s * sk)),
                           max(0.0, min(1.0, v * vk)))


class SlabFace:
    """The slab's animation state and its painter."""

    ASPECT = 0.30          # slab height / slab width

    def __init__(self) -> None:
        self._t = 0.0
        self._awake = 0.0      # 0 sleeping … 1 awake
        self._speak = 0.0      # 0 not speaking … 1 speaking
        self._mouth = 0.0      # smoothed voice level, 0..1
        self._eye_x = 0.0      # eye drift, in slab-height units
        self._eye_y = 0.0
        self._look_x = 0.0
        self._look_y = 0.0
        self._look_at = 0.0    # when the eyes pick their next target
        self._hold_until = 0.0
        self._blink = 0.0      # 0 open … 1 shut
        self._blink_t = -1.0
        self._next_blink = 2.5
        self._level = 0.0

    # ── driving ─────────────────────────────────────────────────────────────
    def glance(self, dx: float, dy: float, hold: float = 1.1) -> None:
        """Look somewhere for a moment. dx / dy are -1..1."""
        self._look_x = max(-1.0, min(1.0, float(dx))) * 0.09
        self._look_y = max(-1.0, min(1.0, float(dy))) * 0.05
        self._hold_until = self._t + max(0.0, float(hold))

    def step(self, dt: float, amp: float, speaking: bool = False,
             muted: bool = False, state: str = "", **_ignored) -> None:
        dt = max(0.001, min(0.10, float(dt)))
        self._t += dt
        t = self._t
        amp = max(0.0, min(1.0, float(amp)))

        awake = (not muted) and str(state or "").upper() in _AWAKE
        speak = awake and bool(speaking)
        self._awake += ((1.0 if awake else 0.0) - self._awake) * _k(dt, 0.22)
        self._speak += ((1.0 if speak else 0.0) - self._speak) * _k(dt, 0.16)

        # Mouth: opens fast on a loud frame, closes a little slower, so a
        # consonant is a flicker and a vowel is a hold.
        want = amp if speak else 0.0
        tau = 0.045 if want > self._mouth else 0.09
        self._mouth += (want - self._mouth) * _k(dt, tau)
        if self._mouth < 0.003:
            self._mouth = 0.0
        self._level = self._level + (amp - self._level) * _k(dt, 0.10)

        # Eyes: while listening they wander (small, slow); while speaking they
        # settle on the person; a glance() overrides both for its hold time.
        if t < self._hold_until:
            pass
        elif speak or not awake:
            self._look_x = self._look_y = 0.0
        elif t >= self._look_at:
            self._look_x = random.uniform(-0.085, 0.085)
            self._look_y = random.uniform(-0.03, 0.03)
            self._look_at = t + random.uniform(1.4, 3.4)
        tau_eye = 0.55 if (awake and not speak) else 0.25
        self._eye_x += (self._look_x - self._eye_x) * _k(dt, tau_eye)
        self._eye_y += (self._look_y - self._eye_y) * _k(dt, tau_eye)

        # Blink: a quick triangle, only when awake.
        if self._blink_t >= 0.0:
            self._blink_t += dt
            ph = self._blink_t / 0.17
            if ph >= 1.0:
                self._blink = 0.0
                self._blink_t = -1.0
                self._next_blink = t + random.uniform(2.6, 5.5)
            else:
                self._blink = 1.0 - abs(2.0 * ph - 1.0)
        elif awake and t >= self._next_blink:
            self._blink_t = 0.0

    @property
    def is_active(self) -> bool:
        """True while something is visibly moving fast (speaking or fading)."""
        return self._speak > 0.02 or self._mouth > 0.01

    # ── painting ────────────────────────────────────────────────────────────
    def paint(self, p: QPainter, cx: float, cy: float, w: float) -> None:
        """Draw the slab centred on (cx, cy), `w` wide. The glow, the ripple
        and the "z" spill outside that box, so leave room around it."""
        h = w * self.ASPECT
        rect = QRectF(cx - w / 2.0, cy - h / 2.0, w, h)
        rad = h * 0.46
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        awake, speak = self._awake, self._speak
        t = self._t
        bright = qcol(C.PRI)

        # ── glow (speaking) ────────────────────────────────────────────────
        if speak > 0.01:
            lvl = 0.80 + 0.20 * self._level
            steps = 22
            for i in range(steps, 0, -1):
                e = h * 0.0135 * i
                a = speak * 0.17 * lvl * (1.0 - i / (steps + 1.0)) ** 2
                if a < 0.004:
                    continue
                pen = QPen(_alpha(bright, a))
                pen.setWidthF(h * 0.03)
                p.setPen(pen)
                p.setBrush(Qt.BrushStyle.NoBrush)
                r = rect.adjusted(-e, -e, e, e)
                p.drawRoundedRect(r, rad + e, rad + e)

        # ── ripple (listening) ─────────────────────────────────────────────
        ls = awake * (1.0 - speak)
        if ls > 0.01:
            for off in (0.0, 0.5):
                ph = ((t * 0.42) + off) % 1.0
                e = h * (0.03 + 0.26 * ph)
                a = ls * 0.34 * (1.0 - ph) ** 1.6
                if a < 0.004:
                    continue
                pen = QPen(_alpha(bright, a))
                pen.setWidthF(max(1.0, h * 0.018))
                p.setPen(pen)
                p.setBrush(Qt.BrushStyle.NoBrush)
                r = rect.adjusted(-e, -e, e, e)
                p.drawRoundedRect(r, rad + e, rad + e)

        # ── body ───────────────────────────────────────────────────────────
        # Sleeping glass, drawn always; the lit glass fades in over it.
        breathe = 0.5 + 0.5 * math.sin(t * 1.9)
        dead = QLinearGradient(rect.topLeft(), rect.bottomRight())
        dead.setColorAt(0.0, QColor(13, 22, 28))
        dead.setColorAt(1.0, QColor(20, 31, 38))
        p.setPen(QPen(_alpha(_hsv(bright, 0.0, 0.35, 0.55), 0.35 + 0.15 * breathe),
                      max(1.0, h * 0.014)))
        p.setBrush(dead)
        p.drawRoundedRect(rect, rad, rad)

        if awake > 0.01:
            p.save()
            p.setOpacity(awake)
            lit = QLinearGradient(rect.left(), 0, rect.right(), 0)
            lit.setColorAt(0.0, _hsv(bright, 0.035, 0.95, 0.46))
            lit.setColorAt(1.0, _hsv(bright, 0.0, 0.95, 0.82))
            edge = _alpha(_hsv(bright, 0.0, 0.7, 1.0), 0.55 if speak > 0.5 else 0.35)
            p.setPen(QPen(edge, max(1.0, h * 0.014)))
            p.setBrush(lit)
            p.drawRoundedRect(rect, rad, rad)
            # sheen along the top, so it reads as glass and not as paint
            sheen = QLinearGradient(0, rect.top(), 0, rect.bottom())
            sheen.setColorAt(0.0, QColor(255, 255, 255, 26))
            sheen.setColorAt(0.5, QColor(255, 255, 255, 5))
            sheen.setColorAt(1.0, QColor(255, 255, 255, 0))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(sheen)
            p.drawRoundedRect(rect.adjusted(h * 0.02, h * 0.02, -h * 0.02, -h * 0.02),
                              rad * 0.95, rad * 0.95)
            p.restore()

        # ── face ───────────────────────────────────────────────────────────
        face_cx = rect.center().x() + self._eye_x * h
        face_cy = rect.center().y() + self._eye_y * h

        if awake > 0.01:
            p.save()
            p.setOpacity(awake)
            self._paint_awake_face(p, rect, face_cx, face_cy, h, speak)
            p.restore()
        if awake < 0.99:
            p.save()
            p.setOpacity(1.0 - awake)
            self._paint_sleep_face(p, rect, h)
            p.restore()

    def _paint_awake_face(self, p: QPainter, rect: QRectF, fx: float, fy: float,
                          h: float, speak: float) -> None:
        white = QColor(244, 252, 255)
        # Eyes: tall ovals. Slightly smaller and further apart when listening.
        ew = h * _lerp(0.175, 0.19, speak)
        eh = h * _lerp(0.36, 0.42, speak) * (1.0 - 0.92 * self._blink)
        gap = h * _lerp(0.27, 0.25, speak)
        ey = fy - h * 0.085
        for sx in (-1.0, 1.0):
            ex = fx + sx * gap
            # soft halo, then the eye
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(_alpha(white, 0.07))
            p.drawEllipse(QPointF(ex, ey), ew * 0.78, max(1.0, eh * 0.58))
            p.setBrush(white)
            p.drawEllipse(QPointF(ex, ey), ew / 2.0, max(1.0, eh / 2.0))

        # Mouth: a small oval that opens with the voice.
        m = self._mouth
        mw = h * (_lerp(0.22, 0.28, speak) + 0.10 * m)
        mh = h * (0.085 + 0.22 * m)
        my = fy + h * 0.235 + mh * 0.05
        mx = fx + (self._eye_x * h * 0.15)
        p.setBrush(_alpha(white, 0.97))
        p.drawEllipse(QPointF(mx, my), mw / 2.0, mh / 2.0)

    def _paint_sleep_face(self, p: QPainter, rect: QRectF, h: float) -> None:
        col = QColor(168, 190, 199, 215)
        pen = QPen(col, max(1.4, h * 0.05))
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        cx, cy = rect.center().x(), rect.center().y()
        aw = h * 0.27
        for sx in (-1.0, 1.0):
            x0 = cx + sx * h * 0.245 - aw / 2.0
            # lower half of an ellipse: a closed eye, "‿"
            p.drawArc(QRectF(x0, cy - h * 0.20, aw, h * 0.34), 200 * 16, 140 * 16)

        # one "z", drifting up and down and breathing in and out
        ph = 0.5 + 0.5 * math.sin(self._t * 1.15)
        zx = rect.center().x() + rect.width() * 0.215
        zy = rect.top() - h * (0.20 + 0.34 * ph)
        f = QFont()
        f.setFamilies(["Bahnschrift", "Segoe UI", "Helvetica Neue", "Noto Sans",
                       "DejaVu Sans"])
        f.setPixelSize(max(8, int(h * (0.44 + 0.06 * ph))))
        f.setWeight(QFont.Weight.Bold)
        p.setFont(f)
        p.setPen(QColor(110, 128, 138, int(110 + 100 * ph)))
        p.drawText(QRectF(zx - h * 0.4, zy - h * 0.4, h * 0.8, h * 0.8),
                   Qt.AlignmentFlag.AlignCenter, "z")


# ═════════════════════════════════════════════════════════════════════════════
# The floating window
# ═════════════════════════════════════════════════════════════════════════════
class SlabPopout(QWidget):
    """The slab on the desktop, outside the app window.

    Frameless, transparent, no taskbar entry, never takes focus. It follows the
    HUD canvas it was given — state, voice level, mute — and costs one small
    translucent window's worth of painting.
    """

    docked = pyqtSignal()           # the user chose "back into the app"
    on_top_changed = pyqtSignal(bool)
    open_main = pyqtSignal()        # double-click: bring the app forward

    MIN_W, MAX_W, DEF_W = 90, 900, 240

    def __init__(self, hud, on_top: bool = True, geom: dict | None = None):
        super().__init__(None)
        self._hud = hud
        self._on_top = bool(on_top)
        self._face = SlabFace()
        self._drag = None
        self._moved = False
        self._last_t = 0.0

        self.setWindowFlags(self._flags())
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        # macOS hides Tool windows whenever the app is inactive — exactly when a
        # floating avatar is wanted.
        self.setAttribute(Qt.WidgetAttribute.WA_MacAlwaysShowToolWindow, True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setWindowTitle("MARK")
        self.setToolTip("Drag to move · scroll to resize · right-click for options")

        g = geom or {}
        w = int(g.get("w") or self.DEF_W)
        self._set_width(w)
        self._pos0 = (g.get("x"), g.get("y"))

        self._tmr = QTimer(self)
        self._tmr.timeout.connect(self._tick)

    # ── flags ───────────────────────────────────────────────────────────────
    def _flags(self):
        f = Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool
        if self._on_top:
            f |= Qt.WindowType.WindowStaysOnTopHint
        return f

    @property
    def on_top(self) -> bool:
        return self._on_top

    def set_on_top(self, on: bool) -> None:
        on = bool(on)
        if on == self._on_top:
            return
        self._on_top = on
        vis = self.isVisible()
        pos = self.pos()
        # Changing a window flag makes Qt re-create the native window, which
        # hides it. Put it back where it was.
        self.setWindowFlags(self._flags())
        if vis:
            self.show()
            self.move(pos)
            if on:
                self.raise_()
        self.on_top_changed.emit(on)

    # ── size / place ────────────────────────────────────────────────────────
    def _set_width(self, w: int) -> None:
        w = max(self.MIN_W, min(self.MAX_W, int(w)))
        # slab is 78% of the width; the rest is room for glow, ripple and "z"
        h = int(w * 0.62)
        self.resize(w, h)

    def _default_pos(self):
        scr = QGuiApplication.primaryScreen()
        geo = scr.availableGeometry() if scr else None
        if geo is None:
            return 40, 40
        return (geo.right() - self.width() - 24, geo.bottom() - self.height() - 24)

    def _on_some_screen(self, x: int, y: int) -> bool:
        probe = QRectF(x, y, self.width(), self.height())
        for s in QGuiApplication.screens():
            inter = QRectF(s.availableGeometry()).intersected(probe)
            if inter.width() >= 60 and inter.height() >= 40:
                return True
        return False

    def place(self) -> None:
        x, y = self._pos0
        if x is None or y is None or not self._on_some_screen(int(x), int(y)):
            x, y = self._default_pos()
        self.move(int(x), int(y))

    def _save(self) -> None:
        try:
            from memory.config_manager import save_avatar_window
            save_avatar_window(self.x(), self.y(), self.width())
        except Exception:
            pass

    # ── lifecycle ───────────────────────────────────────────────────────────
    def showEvent(self, e):
        super().showEvent(e)
        self._last_t = 0.0
        self._tmr.start(16)

    def hideEvent(self, e):
        super().hideEvent(e)
        self._tmr.stop()

    def _tick(self) -> None:
        import time
        now = time.perf_counter()
        dt = (now - self._last_t) if self._last_t else 0.016
        self._last_t = now
        h = self._hud
        try:
            amp = float(getattr(h, "_amp_disp", 0.0) or 0.0)
            self._face.step(dt, amp,
                            speaking=bool(getattr(h, "speaking", False)),
                            muted=bool(getattr(h, "muted", False)),
                            state=str(getattr(h, "state", "") or ""))
        except Exception:
            pass
        # 60 Hz while the mouth moves, 30 Hz otherwise: the idle slab only
        # breathes, and a game running beside it should not pay for that.
        want = 16 if self._face.is_active else 33
        if self._tmr.interval() != want:
            self._tmr.setInterval(want)
        self.update()

    def glance(self, dx: float, dy: float, hold: float = 1.1) -> None:
        self._face.glance(dx, dy, hold)

    # ── painting ────────────────────────────────────────────────────────────
    def paintEvent(self, _):
        p = QPainter(self)
        if not p.isActive():
            return
        W, H = self.width(), self.height()
        # Shift down a touch: the "z" needs more room above than the glow
        # needs below.
        self._face.paint(p, W / 2.0, H * 0.58, W * 0.78)

    # ── mouse ───────────────────────────────────────────────────────────────
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            self._moved = False
            self.setCursor(QCursor(Qt.CursorShape.ClosedHandCursor))
            e.accept()

    def mouseMoveEvent(self, e):
        if self._drag is not None and (e.buttons() & Qt.MouseButton.LeftButton):
            self.move(e.globalPosition().toPoint() - self._drag)
            self._moved = True
            e.accept()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and self._drag is not None:
            self._drag = None
            self.unsetCursor()
            if self._moved:
                self._save()

    def mouseDoubleClickEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.open_main.emit()

    def wheelEvent(self, e):
        step = e.angleDelta().y()
        if not step:
            return
        old_c = self.frameGeometry().center()
        self._set_width(int(self.width() * (1.07 ** (step / 120.0))))
        # keep it centred where it was instead of growing down-right
        g = self.frameGeometry()
        g.moveCenter(old_c)
        self.move(g.topLeft())
        self._save()
        e.accept()

    def contextMenuEvent(self, e):
        m = QMenu(self)
        m.setStyleSheet(
            f"QMenu{{background:{C.PANEL};color:{C.TEXT};border:1px solid {C.BORDER_B};"
            f"padding:4px;}}"
            f"QMenu::item{{padding:6px 22px 6px 14px;}}"
            f"QMenu::item:selected{{background:{C.PRI_GHO};color:{C.WHITE};}}"
            f"QMenu::separator{{height:1px;background:{C.BORDER};margin:4px 8px;}}")
        a_top = m.addAction("Always on top")
        a_top.setCheckable(True)
        a_top.setChecked(self._on_top)
        a_main = m.addAction("Open MARK window")
        m.addSeparator()
        a_big = m.addAction("Larger")
        a_small = m.addAction("Smaller")
        a_reset = m.addAction("Reset size and position")
        m.addSeparator()
        a_dock = m.addAction("Put back inside the app")
        act = m.exec(e.globalPos())
        if act is None:
            return
        if act is a_top:
            self.set_on_top(a_top.isChecked())
        elif act is a_main:
            self.open_main.emit()
        elif act is a_big:
            self._set_width(int(self.width() * 1.2)); self._save()
        elif act is a_small:
            self._set_width(int(self.width() / 1.2)); self._save()
        elif act is a_reset:
            self._set_width(self.DEF_W)
            self._pos0 = (None, None)
            self.place()
            self._save()
        elif act is a_dock:
            self.docked.emit()
