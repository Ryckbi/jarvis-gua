# Uploads from the user — archive

These are files the user sent directly, kept **verbatim** and separate from the
working tree. Nothing here is imported by the app; `uploads/` is not in
`update/SYNC.txt` and never goes into a release ZIP.

The point is reference: when a feature request arrives, compare against the
newest copy here instead of guessing which version is on the user's machine.

| file | original path | saved | lines |
|---|---|---|---|
| `computer_settings.py` | `actions/computer_settings.py` | 2026-11-23 | 1359 |
| `config_manager.py` | `memory/config_manager.py` | 2026-11-23 | 756 |
| `slab_avatar.py` | `gui/slab_avatar.py` | 2026-11-23 | 523 |
| `hud.py` | `gui/hud.py` | 2026-11-23 | 832 |
| `window.py` | `gui/window.py` | 2026-11-23 | 3635 |

Also promised/mentioned but **not received yet**:

- `monitor_brightness.py` — sent in an earlier message, never landed in the
  workspace, not present in `uploads/`.

## Divergence worth knowing about

`uploads/2026-11-23/config_manager.py` is **not** the same shape as
`memory/config_manager.py` in the working tree. The uploaded file calls the
avatar settings:

    get_avatar_popout() / save_avatar_popout()      key "avatar_popout"
    get_avatar_on_top() / save_avatar_on_top()      key "avatar_on_top"
    get_avatar_window() / save_avatar_window()      key "avatar_window" {x,y,w}

while the working tree uses:

    get_avatar_floating() / save_avatar_floating()  key "avatar_floating"
    get_always_on_top()  / save_always_on_top()     key "always_on_top"
    get_popout_geometry() / save_popout_geometry()  key "popout_geometry" [x,y,w,h]

The uploaded file also still has `HUD_STYLES = ("face", "core")` — no slab — and
no `AVATAR_TONES` / `get_avatar_tone`.

Interpretation: the uploaded `config_manager.py` is the user's **live** build,
and its `gui/slab_avatar.py`, `gui/hud.py` and `gui/window.py` presumably call
those names. The workspace copies are the ones written earlier in this session
and use the other names.

**RESOLVED (2026-11-23, user decision "ikut file kiriman lu"):** rather than
rename either side, `memory/config_manager.py` now exposes *both*:

    get_avatar_on_top()      -> alias of get_always_on_top()
    save_avatar_on_top()     -> alias of save_always_on_top()
    get_avatar_popout()      -> alias of get_avatar_floating()
    save_avatar_popout()     -> alias of save_avatar_floating()
    get_avatar_window()      -> {"x","y","w","h"} view of get_popout_geometry()
    save_avatar_window(x,y,w,h=0) -> writes popout_geometry, derives h if absent

Aliases call the original, so there is still exactly one key per setting on disk
and the two names cannot drift apart. `HUD_STYLES` stays the superset
`("slab", "face", "core")` because the user's file has only `("face","core")`,
and narrowing it would make a saved `"slab"` silently fall back to `"face"` —
their screenshot proves the slab is what they are looking at.

Still open: the user's `hud.py` and `window.py` as they exist on their PC have
not been re-uploaded, so the tree's copies of those two may differ from what is
actually running there.

## `slab_avatar.py`: two incompatible designs

The uploaded `slab_avatar.py` is **not** an evolution of `gui/slab_avatar.py` in
the tree — it is a different design with a different interface.

| | uploaded (user's build) | tree |
|---|---|---|
| face class | `SlabFace`, defined in this same file | `SlabAvatar` from `core/avatar_slab.py` |
| signature | `paint(p, cx, cy, w)` — width-driven | `paint(p, cx, cy, r, primary, accent, bg)` |
| window | `SlabPopout(hud, on_top=, geom=)`, a `QWidget` | `AvatarPopout()` taking no args |
| animation | **polls the HUD itself** on its own 16/33 ms timer via `_hud._amp_disp` | HUD **pushes** each tick through module-level `feed()` |
| module API | none — class only | `ensure()`, `popout()`, `sync()`, `feed()` |
| persistence | `save_avatar_window(x, y, w)` | `save_popout_geometry(x, y, w, h)` |
| signals | `docked`, `on_top_changed`, `open_main` | none; calls into the main window directly |
| colour | from `C.PRI` only, no `tone` setting | `tone` attr, cyan/red |

Because `hud._sync_float_avatar()` in the tree calls `gui.slab_avatar.sync()` and
`feed()`, dropping the uploaded file in unchanged breaks the HUD immediately.
Conversely the uploaded file needs a caller that does
`SlabPopout(self.hud, on_top=..., geom=get_avatar_window())` and connects the
three signals.

**Not merged.** The uploaded copy is kept verbatim as the reference for what the
user is actually running. Reconciling the two is a deliberate decision, not a
copy — the honest options are (a) adopt the uploaded design wholesale and
rewrite `_sync_float_avatar` + the drawer wiring to match, or (b) keep the tree's
push model and ignore the upload. Option (a) is closer to the user's machine.

One good sign: the uploaded file calls `save_avatar_window`, which now exists in
`memory/config_manager.py` as an alias, so it would import cleanly today. Its
`SlabFace` needs no `core/avatar_slab.py` at all.

## `hud.py` and `window.py`: the other half of that design

The two files that arrived with `slab_avatar.py` call it exactly as the uploaded
copy expects, which confirms the trio belongs together and that the tree's
copies are the odd ones out.

| | uploaded (user's build) | tree |
|---|---|---|
| avatar import | `from gui.slab_avatar import SlabFace` | `from core.avatar_slab import SlabAvatar` |
| avatar attribute | `self._avatar` (a `SlabFace`) | `self._slab` |
| avatar call | `self._avatar.step(dt, amp, speaking=, muted=, state=)` and `paint(p, cx, cy, slab_w)` | `SlabAvatar.paint(p, cx, cy, r, primary, accent, bg)` |
| floating state | `self.avatar_popped` + `self.popout` (the `SlabPopout`) | `_sync_float_avatar()` talking to module `sync()` / `feed()` |
| window wiring | `self._avatar_pop`, `_avatar_popout_wanted()`, `_sync_avatar_popout()`, `_toggle_avatar_popout`, `_dock_avatar`, `_toggle_avatar_on_top`, `_on_avatar_top_changed`, `_raise_main_window` | `_sync_float_avatar` caller only |
| drawer buttons | `_popout_btn`, `_ontop_btn`, `_refresh_avatar_btns()` | `_popout_btn` only |
| HUD toggle | `face` ↔ `core` | `slab` / `face` / `core` |

Both uploaded files are otherwise the same lineage as the tree's — same class
names, same layout code, same video/camera/quiz/football panels — so a diff is
mostly the avatar path plus the pop-out wiring.

Consequence for update 017: the merge has to pick one side. Adopting the
uploaded design means taking `SlabFace`/`SlabPopout` and `_sync_avatar_popout`
and dropping `core/avatar_slab.py` + `gui/slab_avatar.py`'s push model; keeping
the tree means rewriting the uploaded trio's avatar calls. Nothing is half-wired
yet — the tree still runs its own consistent (compiling, unverified) version.


