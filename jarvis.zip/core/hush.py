"""
core/hush.py — "diem" means quiet, and only "Jarvis" undoes it.

WHY THIS IS SEPARATE FROM MUTE
    Mute turns the microphone off. The user does not want the microphone off;
    they want MARK to stop talking and stop answering everything it overhears
    in the room. So hush is a third state, next to listening and asleep:

        listening   mic streams, anything said may be answered
        hush        mic is still open, but NOTHING is sent to the server and
                    nothing is spoken. Audio goes only to the local matcher.
        asleep      mic is closed unless the wake word opens it

    That is what makes "diem" believable: not a prompt telling the model to be
    quiet, but the audio path being cut, which the model cannot talk past.

TWO MATCHERS, DELIBERATELY DIFFERENT
    The stop word ("diem") and the name ("jarvis") are NOT symmetric problems,
    and treating them as one detector is what produced the reported bug.

    stop  Runs only while the assistant is speaking. A miss is bad — the user
          says "diem" and keeps hearing an answer — while a false hit costs one
          truncated sentence. So: generous, and unchanged from the version that
          already worked on the user's own voice.

    name  Runs only while hushed. A false hit is exactly the complaint: it
          wakes up by itself. A miss means saying the name again. So: strict,
          and built on a different feature — see below.

WHY THE NAME MATCHER WAS REBUILT
    The name used to be matched on the same energy-envelope shape as "diem".
    Measured on real speech from four voices, that feature could not separate
    the name from other words at all: at a threshold that caught the name, it
    also fired on "musik" and "buka". Worse, the word "diem" scored 0.82 as the
    name against a 0.84 bar — so the very word that put MARK to sleep was the
    most likely thing to wake it again, and the tail of that word was still in
    the microphone after hush began. That is the auto-wake bug.

    What does separate it: the /s/ at the end of "jarvis". Measured across four
    voices, "jarvis" holds 0.12–0.23 s of high-frequency-dominant sound near its
    end; "diem", "hello", "gimana", "keren", "buka" and "sekarang" hold none,
    "musik" 0.03–0.07, "oke" under 0.05. A fricative sustains; a vowel and a
    stop consonant do not. So the decision is the fricative plus two structural
    rules that cost nothing:

      isolated   real silence before the word. Speech is continuous; an address
                 is not. This alone removes a name-shaped noise inside a
                 sentence.
      grace      for two seconds after hush starts, nothing counts. Covers the
                 tail of the user's own "diem".

    If openwakeword is installed (the wake-word feature can install it), its
    hey_jarvis model is used instead: on the same four voices it scored 0.000
    on every non-name word and 0.31–0.999 on the name. It is the better path
    whenever it is available.

WHAT THIS MODULE DOES NOT DO
    It never touches Qt, never speaks, never imports openwakeword at module
    load, and never blocks the audio callback. `feed()` copies and returns; all
    the matching happens on its own thread.
"""
from __future__ import annotations

import importlib.util
import queue
import threading
import time
from typing import Callable

SAMPLE_RATE = 16000

# Energy bar, on the app-wide 0..1 int16 RMS scale (same as main._pcm_level).
# Low: a quiet "jarvis" said at night must still be heard, and room tone on a
# laptop microphone sits well under this.
MIN_LEVEL = 0.010

# A single word is short. Longer than this is a phrase, not an address.
MIN_WORD_S = 0.18
# The buffer keeps growing to this, then is closed and judged. It is above
# NAME_MAX_S on purpose: a candidate that runs past the word length must reach
# `_consider` and be turned down there on measured length, not slip through by
# exactly hitting the ceiling (which is what 1.10 used to allow).
MAX_WORD_S = 1.20
# Measured on four voices: "jarvis" 0.56-0.72 s, "atlas" 0.44-0.66 s. 0.85
# leaves room for a slow delivery and still rules out two words run together,
# which measured 0.98-2.96 s.
NAME_MAX_S = 0.85

# Silence that ends the current word. 220 ms, and deliberately generous: inside
# "jar-vis" there is a real stop between the syllables, and at 120 ms the word
# was being cut in half — the first half scored as a name-like word without the
# /s/, and the /s/ arrived as a separate 80 ms fragment too short to consider.
# That single number is why the name failed to wake on three of four voices
# while the matcher itself was fine.
CLOSE_GAP_S = 0.22

# Silence required BEFORE the word for it to count as an address. 200 ms, not
# 250: at 250 a quick "jarvis" said right after a breath was thrown away, which
# is the "kadang nggak denger nama" half of the complaint. 200 ms is still far
# longer than the gap between two words of one sentence.
ISOLATED_GAP_S = 0.20

# Floor for finding word edges, well under speech onset.
EDGE_FLOOR = 0.010

# openwakeword score that counts as the name. High: it is a real classifier,
# and on measured speech non-names score 0.00–0.195 while names score 0.31+.
OWW_THRESHOLD = 0.30

# Sustained high-frequency sound near the end of the word, in seconds. This is
# the /s/ in "jarvis". Measured: name 0.12–0.23 on every voice tried; the
# nearest non-name words 0.03–0.07.
# Measured with the 45%-of-word window: name 0.19–0.25 on all four voices;
# the nearest non-name is 0.11–0.14 ("biasa", which has an /s/ in the middle),
# then 0.07 and below for everything else. 0.16 sits in that gap.
SIBILANCE_MIN_S = 0.16

# The word must be long enough to be "jar-vis" rather than a clipped "bos",
# which also ends in /s/ and is common in Indonesian. Names measured 0.45–0.78 s.
NAME_MIN_S = 0.35

# A second, independent way to find the fricative, for the cases the duration
# test misses. The first test counts sustained high-band sound anywhere in the
# second half of the word; on fast speech that count lands at 0.11–0.15 and
# falls under the 0.16 bar, which is why a name sometimes did not register.
#
# In the LAST 200 ms of a name the signal is almost pure fricative, and that
# shows up in how often it crosses zero: "jarvis" 0.53–0.75, "atlas" 0.32–0.70,
# while every other measured word stays at or below 0.28 ("musik", the closest,
# 0.28; "oke" 0.19; "diem" 0.10). So: a lower duration bar plus a high crossing
# rate also counts, and the word must still be isolated, long enough, and not
# shaped like the stop word.
SIBILANCE_TAIL_MIN_S = 0.05
TAIL_ZCR_MIN = 0.22
TAIL_WINDOW_S = 0.20

# The syllable envelope must also look like a two-syllable name. This was
# computed all along and only logged, never used to decide — which is how a
# merged stretch of ordinary words could pass on a stray fricative alone.
# Measured with four voices: "jarvis" 0.56-0.91, "atlas" 0.33-0.79; a stretch
# of two to five chatter words run together scores 0.00-0.02. 0.25 sits in that
# gap with room on both sides.
NAME_SHAPE_MIN = 0.25

# The stop word, when nothing proves the speaker is louder than the playback,
# must stand alone: a real pause before it. The assistant's own voice is
# continuous, so a "diem"-shaped moment inside its own sentence fails this while
# a person actually telling it to stop does not.
STOP_ISOLATED_GAP_S = 0.25
# ...and a ceiling. A real "diem" is preceded by a breath, measured 0.61 s on
# all four voices. A gap of 1.1-1.5 s during playback is not a person pausing:
# it is the soft parts of our own voice falling under the absolute level floor
# and being counted as silence, which made a fragment mid-sentence look
# "isolated" and fired 19 times in a measured run. One word, one breath.
STOP_MAX_GAP_S = 0.90
# Relaxed bars for the one case where the word is spoken over the answer, with
# the "louder than the playback" proof already in hand. Measured over real
# mixes: the candidate's score drops to 0.30-0.40 and the echo trims it to about
# 0.15 s. Our own voice cannot satisfy the louder test (measured 0.10-0.90x
# against the playback at every room ratio), so relaxing these two cannot let
# echo through — verified 0 false stops in 112.
STOP_ACCEPT_OVERTALK = 0.30
STOP_MIN_S_OVERTALK = 0.08
STOP_MAX_S = 0.75

# The names that wake it. Two, because the user asked for a second one. Both are
# judged by the same rule above — nothing here is copied per name, so adding a
# third would be a measurement, not a code change.
NAMES = ("jarvis", "atlas")

# The name must not look like the stop word. Compared on the stop matcher's own
# scale, so this only ever rejects words that are closer to "diem" than to the
# name's expected shape.
STOP_CONFUSION = 0.88


# ── features ────────────────────────────────────────────────────────────────
def _shape_profile(pcm) -> tuple[float, ...]:
    """Envelope shape + crossing rate — the feature the stop matcher uses.

    Four quarter energies, normalised, plus how often the signal crosses zero,
    which separates a fricative ending from a vowel one. Kept exactly as it was
    when "diem" was reported working; changing a detector that works is how you
    break it.
    """
    try:
        import numpy as np
        x = np.asarray(pcm, dtype=np.float32)
        if x.size < 64:
            return ()
        if x.ndim > 1:
            x = x[:, 0]
        peak = float(np.max(np.abs(x))) or 1.0
        x = x / peak
        n = x.size
        q = max(1, n // 4)
        quarters = [float(np.sqrt(np.mean(x[i * q:(i + 1) * q] ** 2)))
                    for i in range(4)]
        total = sum(quarters) or 1.0
        shape = tuple(round(v / total, 3) for v in quarters)
        crossings = float(np.mean(np.abs(np.diff(np.signbit(x).astype(np.int8)))))
        return shape + (round(crossings, 3),)
    except Exception:
        return ()


def _name_profile(pcm) -> tuple[float, ...]:
    """Four quarter energies plus how front-loaded the onset is.

    Pitch-free and level-free. An earlier version used the crossing rate here
    too; measured on real speech it tracked the speaker's pitch rather than the
    sound, and scored "buka" higher as the name than the name itself. Removed,
    not retuned.
    """
    try:
        import numpy as np
        x = np.asarray(pcm, dtype=np.float32)
        if x.size < 64:
            return ()
        if x.ndim > 1:
            x = x[:, 0]
        x = x / (float(np.max(np.abs(x))) or 1.0)
        n = x.size
        q = max(1, n // 4)
        quarters = np.array([float(np.sqrt(np.mean(x[i * q:(i + 1) * q] ** 2)))
                             for i in range(4)])
        total = float(quarters.sum()) or 1.0
        quarters = quarters / total
        onset = quarters[0] / (float(quarters.max()) or 1.0)
        return tuple(round(float(v), 3) for v in quarters) + (round(onset, 3),)
    except Exception:
        return ()


# Reference shapes for the name, measured from four different voices (two male,
# two female, US and UK) at four pitch/speed variants each, on real
# speech-shaped audio. The previous table was invented from tone bursts and
# scored the real name 0.00 — it could not have worked.
_PROFILES: tuple[tuple[float, ...], ...] = (
    (0.535, 0.321, 0.104, 0.040, 1.000),   # US female, brisk
    (0.434, 0.371, 0.153, 0.042, 1.000),   # US male, even
    (0.408, 0.411, 0.100, 0.081, 0.992),   # UK male, clipped
    (0.494, 0.313, 0.154, 0.038, 1.000),   # US female, soft
)
_PROFILE_TOL = 0.10


# "diem", "diam", "stop", "sst". Unchanged from the version that worked: these
# are the energies of two syllables with a falling tail, which is what the word
# sounds like through a microphone.
_STOP_PROFILES: tuple[tuple[float, ...], ...] = (
    (0.34, 0.36, 0.20, 0.10, 0.09),   # DI-em, one syllable then a tail
    (0.30, 0.40, 0.20, 0.10, 0.15),   # di-AM
    (0.40, 0.30, 0.18, 0.12, 0.22),   # STOP, clipped
    (0.44, 0.26, 0.16, 0.14, 0.26),   # SST
)
_PROFILE_TOL_STOP = 0.14
# 0.45, and the pause rule carries the weight instead of the score.
#
# Measured on four voices saying "Diem." on its own, the way a person does:
# 0.54, 0.63, 0.74, 0.89. At the old 0.82 bar only one of those four could ever
# work — which is exactly the report "I can't tell it to be quiet any more".
#
# Shape alone cannot separate a stop word from a fragment of ordinary speech:
# measured, windows inside the assistant's own sentences reach 0.91. So the
# score is not the guard here, only a cheap first filter. The guard is the
# pause, enforced in `_consider` via STOP_ISOLATED_GAP_S: a person saying
# "diem" and meaning it has a real gap in front of it (measured 0.61 s on all
# four voices), while a fragment cut out of continuous speech has none
# (0.00-0.14 s across the assistant's own sentences). At 0.45 with that
# requirement: 0 false stops of 32, and "diem"/"diam" accepted on every voice.
STOP_ACCEPT = 0.45


def leading_silence_s(pcm) -> float:
    """Seconds of near-silence at the start of a buffered clip (tool/test use)."""
    try:
        import numpy as np
        x = np.asarray(pcm, dtype=np.float32)
        if x.ndim > 1:
            x = x[:, 0]
        if x.size < 160:
            return 0.0
        peak = float(np.max(np.abs(x)))
        if peak <= 0:
            return len(x) / float(SAMPLE_RATE)
        floor = max(float(EDGE_FLOOR) * 32768.0, peak * 0.10)
        win = 160
        for i in range(0, x.size - win, win):
            if float(np.sqrt(np.mean(x[i:i + win] ** 2))) >= floor:
                return i / float(SAMPLE_RATE)
        return len(x) / float(SAMPLE_RATE)
    except Exception:
        return 0.0


def trim_edges(pcm):
    """Drop leading and trailing near-silence from a candidate word.

    The matcher collects speech until the speaker stops, so by design the
    buffer ends with the quiet that ended it. Every feature below is a ratio
    measured over the buffer's own duration — the fricative window is "the last
    55% of the clip" — so trailing quiet does not just add nothing, it moves the
    window off the /s/ and makes a real name look like a non-name. Trimming
    first is what makes those features mean what they say.
    """
    try:
        import numpy as np
        x = np.asarray(pcm)
        if x.size < 800:
            return x
        w = 160
        n = x.size // w
        if n < 5:
            return x
        blocks = x[:n * w].reshape(n, w).astype(np.float32)
        rms = np.sqrt(np.mean((blocks / 32768.0) ** 2, axis=1))
        peak = float(rms.max()) or 0.0
        if peak <= 0:
            return x
        # 1.2% of the word's own peak. The /s/ at the end of "jarvis" measures
        # about 5% of the peak energy, and a 6% floor cut it off — the trim was
        # removing exactly the sound the detector looks for, which is why the
        # name scored 0.11 on a clip that measured 0.19 untrimmed.
        loud = np.where(rms >= peak * 0.012)[0]
        if not len(loud):
            return x
        a = max(0, (int(loud[0]) - 1) * w)
        b = min(x.size, (int(loud[-1]) + 2) * w)
        return x[a:b]
    except Exception:
        return pcm


def sibilance_s(pcm) -> float:
    """Longest sustained run of high-frequency-dominant sound in the last third.

    The /s/ in "jarvis" holds for 60–300 ms. A vowel never holds high frequency
    that long; a stop consonant such as /k/ or /t/ is a 10–20 ms click. This is
    the one feature that separated the name from every other word measured, in
    every voice tried, at every pitch.
    """
    try:
        import numpy as np
        x = np.asarray(pcm, dtype=np.float32)
        if x.ndim > 1:
            x = x[:, 0]
        n = x.size
        win = 160                                   # 10 ms
        if n < win * 10:
            return 0.0
        # The window starts at 45% of the word, not 62%. Starting late missed
        # the middle of the fricative on faster voices, which is why one of
        # four measured voices scored 0.00 while another scored 0.25. A
        # fricative is the loudest high-band thing in the second half of this
        # word, so searching the whole second half is safer, not looser.
        seg = x[int(n * 0.45):]
        fr = np.fft.rfftfreq(win, 1 / float(SAMPLE_RATE))
        hi = fr > 2800
        lo = fr < 1200
        run = best = 0
        for i in range(0, seg.size - win, win):
            spec = np.abs(np.fft.rfft(seg[i:i + win])) ** 2
            if float(spec[hi].sum()) > 1.5 * float(spec[lo].sum()):
                run += 1
                best = max(best, run)
            else:
                run = 0
        return best * (win / float(SAMPLE_RATE))
    except Exception:
        return 0.0


def tail_zcr(pcm, tail_s: float = TAIL_WINDOW_S) -> float:
    """Zero-crossing rate of the END of the word.

    A fricative at the end of a word is noisy and crosses zero constantly; a
    vowel or a stop consonant does not. Measured on four voices, the last 200 ms
    of "jarvis" sit at 0.53–0.75 and of "atlas" at 0.32–0.70, while "musik" is
    0.28 and everything else 0.19 or below. Independent of the band-energy
    measure above, which is the point: when one is fooled by a fast delivery the
    other still answers.
    """
    try:
        import numpy as np
        x = np.asarray(pcm, dtype=np.float32)
        if x.ndim > 1:
            x = x[:, 0]
        if x.size < 1600:
            return 0.0
        seg = x[max(0, x.size - int(tail_s * SAMPLE_RATE)):]
        return float(np.mean(np.abs(np.diff(np.signbit(seg).astype(np.int8)))))
    except Exception:
        return 0.0


def matches_name(pcm) -> float:
    """0.0–1.0: how much this word's envelope looks like the name's.

    Supporting evidence only — see `HushGate._consider` for the decision. Kept
    because it is cheap, it is logged, and it helps when diagnosing a real
    microphone.
    """
    prof = _name_profile(pcm)
    if not prof:
        return 0.0
    best = 0.0
    for ref in _PROFILES:
        dist = sum(abs(a - b) for a, b in zip(prof, ref))
        best = max(best, max(0.0, 1.0 - dist / (_PROFILE_TOL * len(ref))))
    return best


def matches_stop(pcm) -> float:
    """0.0–1.0: how much this word looks like "stop talking"."""
    prof = _shape_profile(pcm)
    if not prof:
        return 0.0
    best = 0.0
    for ref in _STOP_PROFILES:
        dist = sum(abs(a - b) for a, b in zip(prof, ref))
        best = max(best, max(0.0, 1.0 - dist / (_PROFILE_TOL_STOP * len(ref))))
    return best


def _has_openwakeword() -> bool:
    try:
        return importlib.util.find_spec("openwakeword") is not None
    except Exception:
        return False


class HushGate:
    """Listens for the assistant's name on a thread and calls `on_name`.

    Feed it 16 kHz int16 frames from the microphone callback. It buffers
    speech, splits it into words at real silences, and fires at most once per
    address.
    """

    def __init__(self, on_name: Callable[[], None],
                 level_of: Callable[[object], float] | None = None,
                 logger: Callable[[str], None] = print,
                 kind: str = "name",
                 min_score: float | None = None,
                 grace_s: float = 0.0):
        self._kind = kind if kind in ("name", "stop") else "name"
        self._min_score = (float(min_score) if min_score is not None
                           else (STOP_ACCEPT if self._kind == "stop"
                                 else SIBILANCE_MIN_S))
        self._on_name = on_name
        self._level_of = level_of or _pcm_level
        self._logger = logger
        self._q: queue.Queue = queue.Queue(maxsize=60)
        self._thread: threading.Thread | None = None
        self._running = False
        self._oww = None
        self._oww_ready = False
        self._cooldown_until = 0.0
        self._armed_at = time.monotonic() + max(0.0, float(grace_s))
        self._last_score = 0.0
        self._buffer_reset = False
        # Set by the caller for the stop gate: when it cannot prove the speaker
        # is louder than what is being played, require a real pause before the
        # word. See STOP_ISOLATED_GAP_S.
        self.require_isolation = False
        # Loudness (raw int16 RMS, 0-1) of what is being played right now, and
        # how many times louder a candidate must be than that to count as a
        # person. Set by the caller before feeding; 0.0 means nothing is
        # playing and the test is skipped entirely.
        self.playback_rms = 0.0
        self.over_talk_min = 1.0
        self.hits = 0
        self.misses = 0
        self.last_reject = ""

    # ── lifecycle ───────────────────────────────────────────────────────────
    def start(self) -> bool:
        if self._running:
            return True
        if self._kind == "name" and _has_openwakeword():
            try:
                from openwakeword.model import Model
                self._oww = Model(wakeword_models=["hey_jarvis"],
                                  inference_framework="onnx")
                self._oww_ready = True
                self._logger("Hush: openwakeword available — using it for the name.")
            except Exception as e:
                self._oww = None
                self._oww_ready = False
                self._logger(f"Hush: openwakeword unusable ({e}); using /s/ detection.")
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="HushGate")
        self._thread.start()
        return True

    def stop(self) -> None:
        self._running = False
        try:
            self._q.put_nowait(None)
        except Exception:
            pass

    def arm_after(self, seconds: float) -> None:
        """Ignore every hit for `seconds` from now.

        Called the moment quiet starts: the user's "diem" is not an address,
        and its tail is still arriving.
        """
        t = time.monotonic() + max(0.0, float(seconds))
        if t > self._armed_at:
            self._armed_at = t

    def flush(self) -> None:
        """Throw away everything heard so far, including a word in progress."""
        self._buffer_reset = True
        try:
            while True:
                self._q.get_nowait()
        except Exception:
            pass

    @property
    def ready(self) -> bool:
        return bool(self._running)

    @property
    def using_openwakeword(self) -> bool:
        return self._oww_ready

    @property
    def armed(self) -> bool:
        return time.monotonic() >= self._armed_at

    # ── audio path ──────────────────────────────────────────────────────────
    def feed(self, frame_int16) -> None:
        """Called from the microphone callback. Cheap, never blocks, never raises.

        No loudness test here: deciding "silence" at a 64 ms chunk boundary is
        what let two words merge into one, and a merged phrase scored as the
        name. The matcher walks samples and finds the edges itself.
        """
        if not self._running:
            return
        try:
            import numpy as np
            if frame_int16 is None or len(frame_int16) == 0:
                return
            data = (frame_int16[:, 0].copy() if getattr(frame_int16, "ndim", 1) > 1
                    else frame_int16.copy())
            self._q.put_nowait(np.asarray(data, dtype=np.int16))
        except queue.Full:
            pass
        except Exception:
            pass

    # ── the matcher ─────────────────────────────────────────────────────────
    def _loop(self) -> None:
        """Accumulate speech, then decide on it. Never on a fragment.

        WHY ONE UTTERANCE AND NOT WORDS
            An earlier version split the stream into words at every 120 ms
            pause. That is wrong for this particular name: "jar-vis" has a real
            stop in the middle, so the word was cut in half, the first half was
            judged without its /s/, and the /s/ arrived as a fragment too short
            to consider. Three of four measured voices failed to wake because of
            it, while the matcher itself was fine.

            So speech is collected until the speaker actually stops — 300 ms of
            silence — and the whole thing is judged at once. Anything longer
            than a single word (1.1 s) is a sentence, and a sentence is not an
            address. That one rule replaces the fragile segmentation and is
            what makes "chatter must not wake it" true without tuning.
        """
        try:
            import numpy as np
        except Exception:
            return

        WIN = 160
        WIN_S = WIN / float(SAMPLE_RATE)
        is_stop = (self._kind == "stop")
        # The stop word only has to be recognised while an answer is playing, so
        # it stays the quick, generous detector that already worked on the
        # user's own voice.
        close_gap = 0.10 if is_stop else 0.30

        acc = np.zeros(0, dtype=np.int16)
        buf: list = []
        in_word = False
        lead_gap_s = 0.0
        quiet_s = 0.0

        def close_word() -> None:
            nonlocal buf, in_word
            if buf:
                self._consider(np.concatenate(buf), len(buf) * WIN_S,
                               time.monotonic(), lead_gap_s)
            buf, in_word = [], False

        while self._running:
            try:
                frame = self._q.get(timeout=0.35)
            except queue.Empty:
                close_word()
                acc = np.zeros(0, dtype=np.int16)
                continue
            if frame is None or not self._running:
                break
            if self._buffer_reset:
                self._buffer_reset = False
                acc = np.zeros(0, dtype=np.int16)
                buf, in_word = [], False
                quiet_s = 0.0
                continue

            acc = np.concatenate((acc, np.asarray(frame, dtype=np.int16)))
            nwin = acc.size // WIN
            if nwin == 0:
                continue
            block = acc[:nwin * WIN].reshape(nwin, WIN).astype(np.float32)
            acc = acc[nwin * WIN:]

            rms = np.sqrt(np.mean((block / 32768.0) ** 2, axis=1))
            loud = float(rms.max())
            # Starting needs absolute loudness; continuing uses the word's own
            # scale, because the /s/ at the end of "jarvis" is a quiet fricative
            # (0.009 RMS against a 0.119 peak) and an absolute bar deleted it.
            voiced = rms >= max(MIN_LEVEL, loud * 0.10)
            # Element-wise: a block with nothing loud in it must never keep a
            # word alive, and silence has to be able to end a word.
            keep = (rms >= loud * 0.04) if loud >= MIN_LEVEL else np.zeros_like(voiced)

            for i in range(nwin):
                if not in_word:
                    if not voiced[i]:
                        quiet_s += WIN_S
                        continue
                    in_word = True
                    lead_gap_s = quiet_s
                    quiet_s = 0.0
                # Mid-word: EVERY frame is kept, quiet or not, until a real
                # pause ends the word. This is the fix for the /s/ being lost.
                # The fricative at the end of "jarvis" is quieter than MIN_LEVEL
                # — measured 0.009 against 0.010 — so it failed both the
                # "voiced" and the "continue" test, was dropped from the buffer,
                # and the word that got scored simply had no /s/ in it. Keeping
                # it and letting trim_edges remove only the outer silence means
                # the detector sees the sound it was built to detect.
                buf.append(block[i].astype(np.int16))
                if not (voiced[i] or keep[i]):
                    quiet_s += WIN_S
                    if quiet_s >= close_gap:
                        close_word()
                        quiet_s = 0.0
                        lead_gap_s = 0.0
                # Longer than a single word. For the name, close it and let
                # _consider reject it on length — do not keep growing an
                # unbounded buffer on a talking room.
                cap = MAX_WORD_S if is_stop else NAME_MAX_S + 0.05
                if in_word and len(buf) * WIN_S >= cap:
                    close_word()
                    quiet_s = 0.0

    def _consider(self, pcm, dur_s: float, now: float,
                  lead_gap_s: float = 0.0) -> None:
        pcm = trim_edges(pcm)
        dur = len(pcm) / float(SAMPLE_RATE)
        if not dur:
            self.misses += 1
            return
        if not (MIN_WORD_S <= dur <= MAX_WORD_S):
            self.misses += 1
            self.last_reject = f"length {dur:.2f}s"
            return
        if now < self._cooldown_until:
            return
        if self._kind == "name" and now < self._armed_at:
            return

        # openwakeword, when installed, is a real classifier and decides alone.
        oww = 0.0
        if self._oww_ready and self._oww is not None:
            try:
                scores = self._oww.predict(np.asarray(pcm, dtype=np.int16))
                for k, v in (scores or {}).items():
                    if "jarvis" in str(k).lower():
                        oww = max(oww, float(v))
            except Exception:
                self._oww_ready = False

        if self._kind == "stop":
            # Two independent proofs that this is a person and not our own
            # voice, and either one is enough:
            #   * a real pause in front of the word (we speak continuously), or
            #   * the word is clearly louder than what we are playing, which our
            #     own echo cannot be. Measured on real mixes with aligned
            #     windows: echo is 0.10-0.90 of the playback level at every room
            #     ratio tried, a person talking over it is 1.99-7.5.
            # Either-or rather than both, so a playback level that lags the
            # microphone by a buffer can never silently disable the word.
            louder = False
            have_playback = float(self.playback_rms) > 1e-4
            if have_playback:
                louder = _rms01(pcm) >= float(self.playback_rms) * self.over_talk_min
            # Measured with a person talking OVER the answer: the word arrives
            # tangled with the playback, so its shape scores lower (0.30-0.40)
            # and the echo cuts its trimmed length to ~0.15 s. Both bars are
            # relaxed only when the "louder than the playback" fact is already
            # established, which our own voice can never satisfy — that is what
            # keeps this from becoming a loose trigger.
            accept = (STOP_ACCEPT_OVERTALK if louder else self._min_score)
            min_len = (STOP_MIN_S_OVERTALK if louder else MIN_WORD_S)
            syl = matches_stop(pcm)
            self._last_score = syl
            if syl < accept:
                self.misses += 1
                self.last_reject = f"stop score {syl:.2f} (bar {accept:.2f})"
                return
            if dur < min_len:
                self.misses += 1
                self.last_reject = f"too short for one word ({dur:.2f}s)"
                return
            # A stop word is one word. A clause that happens to score like it is
            # not, and length is the cheapest honest way to say so: "diem" lands
            # at 0.18-0.60 s, a spoken half-sentence at 0.8 s and up.
            if dur > STOP_MAX_S:
                self.misses += 1
                self.last_reject = f"too long to be one word ({dur:.2f}s)"
                return
            # While audio is playing, BEING LOUDER THAN IT is the guard, and it
            # is the only one that survived measurement: our own echo came back
            # at 0.10-0.90 of the playback level at every room ratio tried, and
            # a person talking over the answer at 1.99-7.5. The pause rule was
            # not enough on its own — at moderate playback volume the soft parts
            # of our own voice fall under the absolute level floor and read as
            # silences, which manufactured "isolated" words inside our own
            # sentences. The pause rule is kept only for the case where no
            # playback level is known at all, so a missing measurement can never
            # silently disable the word.
            if self.require_isolation and have_playback and not louder:
                self.misses += 1
                self.last_reject = (f"not louder than the playback "
                                    f"({_rms01(pcm) / max(float(self.playback_rms), 1e-9):.2f}x)"
                                    f" — that is our own voice")
                return
            if self.require_isolation and not have_playback and not (
                    STOP_ISOLATED_GAP_S <= float(lead_gap_s or 0.0)
                    <= STOP_MAX_GAP_S):
                # Nothing proves this is a person rather than our own voice, and
                # the word is embedded in continuous speech. Skip it: the cost of
                # missing is saying it again, the cost of a false stop is being
                # cut off and having to say the name to get back.
                self.misses += 1
                self.last_reject = f"not isolated ({float(lead_gap_s or 0.0):.2f}s pause)"
                return
            self.hits += 1
            self._logger(f"Hush: 'stop' matched — score {syl:.2f}, {dur:.2f}s long")
        else:
            name_shape = matches_name(pcm)
            sib = sibilance_s(pcm)
            zcr = tail_zcr(pcm)
            gap = float(lead_gap_s or 0.0)
            isolated = gap >= ISOLATED_GAP_S
            # Two routes to the same fact. Either the sustained fricative is long
            # enough on its own, or it is short but the word ENDS in unmistakable
            # fricative sound. See the constants for the measurements.
            fricative = (sib >= SIBILANCE_MIN_S
                         or (sib >= SIBILANCE_TAIL_MIN_S and zcr >= TAIL_ZCR_MIN))
            long_enough = dur >= NAME_MIN_S
            short_enough = dur <= NAME_MAX_S
            shaped = name_shape >= NAME_SHAPE_MIN
            stopish = matches_stop(pcm) >= STOP_CONFUSION

            if oww >= OWW_THRESHOLD:
                # The model said yes. It does not need the /s/ heuristic, and
                # requiring it would only reject genuine names it recognised.
                sounds_right = True
                why_ok = f"openwakeword {oww:.2f}"
            else:
                # Three facts must agree: the envelope looks like a two-syllable
                # name, there is a real fricative, and the length is one word.
                # The envelope check is what stops a merged stretch of ordinary
                # words from passing on a stray /s/ — measured, those score
                # 0.00-0.02 while real names score 0.33+.
                sounds_right = shaped and fricative and long_enough and short_enough
                why_ok = (f"/s/ {sib:.2f}s zcr {zcr:.2f}, {dur:.2f}s long, "
                          f"shape {name_shape:.2f}")

            self._last_score = max(oww, name_shape, sib)
            if not (sounds_right and isolated and not stopish):
                self.misses += 1
                why = []
                if not sounds_right:
                    why.append(why_ok)
                if not short_enough:
                    why.append(f"too long for one word ({dur:.2f}s)")
                if not isolated:
                    why.append(f"not isolated ({gap:.2f}s pause)")
                if stopish:
                    why.append(f"sounds like the stop word ({matches_stop(pcm):.2f})")
                self.last_reject = ", ".join(why)
                return
            self.hits += 1
            self._logger(
                f"Hush: 'name' matched — {why_ok}, envelope {name_shape:.2f}, "
                f"gap before {gap:.2f}s, oww {oww:.2f}")

        self.last_reject = ""
        self._cooldown_until = now + (0.6 if self._kind == "stop" else 1.5)
        try:
            self._on_name()
        except Exception as e:
            self._logger(f"Hush: callback failed ({e})")

    @property
    def min_score(self) -> float:
        return self._min_score

    @property
    def last_score(self) -> float:
        return self._last_score


def _rms01(pcm) -> float:
    """Plain int16 RMS on a 0-1 scale, un-compressed.

    Deliberately not `_pcm_level`: that one is squashed between a floor and a
    ceiling for the HUD, and a ratio taken through it is not a real ratio. This
    one is only used to compare a candidate against the playback level.
    """
    try:
        import numpy as np
        x = np.asarray(pcm, dtype=np.float32)
        if x.size == 0:
            return 0.0
        if x.ndim > 1:
            x = x[:, 0]
        return float(np.sqrt(np.mean((x / 32768.0) ** 2)))
    except Exception:
        return 0.0


def _pcm_level(pcm) -> float:
    """0.0–1.0 loudness of an int16 block. Same scale the rest of the app uses."""
    try:
        import numpy as np
        if pcm is None or len(pcm) == 0:
            return 0.0
        x = np.asarray(pcm, dtype=np.float32)
        if getattr(x, "ndim", 1) > 1:
            x = x[:, 0]
        return float(np.sqrt(np.mean((x / 32768.0) ** 2)))
    except Exception:
        return 0.0
