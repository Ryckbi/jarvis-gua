"""core/avatar_slab.py — the flat "slab" face that replaces the 3D head.

Why this file exists
--------------------
The 3D head in `core/avatar.py` is still there, byte for byte untouched. This
module is a second renderer with the same tiny interface, so the HUD can draw
either one without knowing which it has:

    av = SlabAvatar()
    av.step(dt, amp, speaking=..., state=...)      # once per tick
    av.paint(painter, cx, cy, r, primary, accent, bg)   # once per frame
    av.SPAN                                        # vertical size, in units of r

Keeping the old renderer whole is the backup: switch back to it from the HUD's
right-click menu and the previous look is exactly what it was — no archived
copy to fall out of date, no second import path to rot.

Design notes
------------
* **One rounded rectangle, two eyes, one mouth, one letter.** That is the whole
  shape. A slab reads as a face because of the *timing*, not the detail: eyes
  that blink at an irregular interval, a mouth that closes between words, and a
  body that dims when nothing is happening.
* **Pure QPainter.** No OpenGL, no shader, no new dependency, no numpy — the
  head's mesh maths would be wasted here and `.avatar.py` already pays for it.
  A frame is one rounded rect, two gradients and three ellipses: far cheaper
  than 468 shaded triangles.
* **Lip-sync is the same signal the head used.** `main.py` already computes a
  real RMS level and a per-20 ms viseme schedule. The slab consumes those, so
  the mouth keeps matching the words without a second audio path.
* **Two tones, both from MARK's own palette.** Cyan is the HUD colour; red is
  the alarm colour. Violet from the reference video is deliberately not here:
  it would read as a different app sitting inside this HUD.
"""

from __future__ import annotations

import math
import random

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import (
    QBrush, QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen,
    QRadialGradient,
)

# Mouth timing, in seconds, matching the head's constants so the two looks
# articulate identically. A fixed per-frame fraction would change speed with the
# paint rate, and the HUD runs at 20, 30 and 60 fps depending on load.
_TAU_OPEN = 0.022
_TAU_SHUT = 0.012
_TAU_REST = 0.055
_TAU_SHAPE = 0.018

# The microphone path has one coarse RMS and no idea what speech is; it needs a
# floor. JARVIS's own voice arrives as a schedule whose silences are real, so it
# must not have one — a floor there would swallow the gaps between words.
_MIC_FLOOR = 0.14
_CLOSE_FRAC = 0.10

# Slab proportions. The face is a wide rounded rectangle, about 3.2 : 1 — the
# same proportion as the reference, wide enough that the eyes sit well inside
# the ends rather than crowding them.
_RATIO = 0.30
_SPAN = 0.78          # how much of `r` the slab's height occupies

# Tones. Each is (left of gradient, right of gradient, glow, rim, idle, face).
# Alpha is applied at draw time so one table serves every state.
_TONES = {
    "cyan": {
        "left": (2, 44, 74),
        "right": (0, 212, 255),
        "glow": (0, 190, 240),
        "rim": (150, 235, 255),
        "idle": (70, 140, 175),
        "face": (235, 252, 255),
    },
    "red": {
        "left": (122, 18, 22),
        "right": (196, 42, 38),
        "glow": (235, 60, 52),
        "rim": (255, 170, 160),
        "idle": (140, 70, 70),
        "face": (255, 246, 244),
    },
}

_ASLEEP = ("SLEEPING", "STANDBY", "OFFLINE")


def _rate(dt: float, tau: float) -> float:
    """Frame-rate independent lerp factor for an exponential approach."""
    return 1.0 - math.exp(-dt / max(1e-4, tau))


def _rgba(t: tuple, a: float) -> QColor:
    """Opaque-or-not QColor from an (r, g, b) tuple and a 0..1 alpha."""
    c = QColor(int(t[0]), int(t[1]), int(t[2]))
    c.setAlpha(int(max(0.0, min(1.0, a)) * 255))
    return c


def _mix(a: tuple, b: tuple, k: float) -> QColor:
    k = max(0.0, min(1.0, k))
    return QColor(int(a[0] + (b[0] - a[0]) * k),
                  int(a[1] + (b[1] - a[1]) * k),
                  int(a[2] + (b[2] - a[2]) * k))


def _slab_path(rect: QRectF, radius: float) -> QPainterPath:
    """A rounded rectangle whose corner radius can exceed half the height —
    the reference face is a capsule with flat sides, not a stadium."""
    path = QPainterPath()
    path.addRoundedRect(rect, radius, radius)
    return path


class SlabAvatar:
    """The flat slab face. Same interface as `HoloAvatar`, much less work."""

    # Read by the HUD to size the centrepiece: the slab is 0.78 of `r` tall.
    SPAN = _SPAN

    def __init__(self) -> None:
        self.tone = "cyan"
        self.shaded = True          # kept so callers can treat both alike
        self._asleep = False        # set by step(); paint() reads it
        self._state = ""

        self._t = 0.0
        self._sway = 0.0
        self._mouth = 0.0
        self._v_open = 1.0
        self._v_peak = 0.18
        self._glow = 0.0

        self._blink = 0.0
        self._blink_at = 2.6
        self._look = 0.0            # horizontal eye drift, in slab widths
        self._look_tgt = 0.0
        self._look_at = 0.0

        # A slow breath so a sleeping slab is not a still image. Integrated
        # rather than derived from absolute time, for the same reason the head
        # integrates its sway: a rate change must not jump the phase.
        self._breath = 0.0

    # ── animation ───────────────────────────────────────────────────────────

    def _mouth_step(self, dt: float, amp: float, live: bool,
                    v_open, v_level) -> None:
        if v_open is None:
            shape = 1.0
        else:
            self._v_open += (v_open - self._v_open) * _rate(dt, _TAU_SHAPE)
            shape = self._v_open

        if v_level is None:
            gated = max(0.0, (amp - _MIC_FLOOR) / (1.0 - _MIC_FLOOR))
            drive = (gated ** 0.6) * (shape ** 0.75)
        else:
            # Normalise against this voice's own loud level, not a constant:
            # then the mouth reads the same whether the volume is low or the
            # model happens to be speaking softly.
            self._v_peak = max(float(v_level), self._v_peak - dt * 0.55)
            ref = max(0.18, self._v_peak)
            q = (float(v_level) - _CLOSE_FRAC * ref) / (ref * (1.0 - _CLOSE_FRAC))
            drive = max(0.0, min(1.0, q)) ** 0.85 * (shape ** 0.75)

        target = min(1.0, drive) if live else 0.0
        if target > self._mouth:
            tau = _TAU_OPEN
        elif live:
            tau = _TAU_SHUT
        else:
            tau = _TAU_REST
        self._mouth += (target - self._mouth) * _rate(dt, tau)
        if self._mouth < 0.002:
            self._mouth = 0.0

    def step(self, dt: float, amp: float, speaking: bool = False,
             muted: bool = False, state: str = "",
             v_open: float | None = None, v_wide: float = 0.0,
             v_level: float | None = None,
             v_seq: list | None = None, v_hop: float = 0.02) -> None:
        """Advance the animation. Signature matches `HoloAvatar.step`, so the
        HUD can call either without a branch."""
        dt = max(0.001, min(0.10, float(dt)))
        self._t += dt
        amp = max(0.0, min(1.0, float(amp)))
        live = bool(speaking) and not bool(muted)

        st = (state or "").upper()
        # Sleeping is a look, not just a speed: muted, told to be quiet, or the
        # session asleep. Stored because paint() draws a different slab for it,
        # and the caller should not have to restate it at draw time.
        self._asleep = bool(muted) or st in _ASLEEP or st == "QUIET"
        self._state = st
        asleep = self._asleep

        # Mouth, stepped once per viseme frame when there is a schedule — a
        # 40 ms closure made of two 20 ms frames falls between samples at
        # 20 fps, and that is information no smoothing can recover.
        if v_seq is not None:
            for lv, op, _wd in v_seq:
                self._mouth_step(v_hop, amp, live, op, lv)
        else:
            self._mouth_step(dt, amp, live, v_open, v_level)

        self._glow += ((0.0 if muted else amp) - self._glow) * (
            0.35 if (0.0 if muted else amp) > self._glow else 0.10)

        # Breath and the listening drift. Slower asleep, quicker while talking.
        speed = 0.5 if asleep else (1.25 if live else 1.0)
        self._breath += dt * speed
        self._sway += dt * speed

        if st == "LISTENING":
            if self._t >= self._look_at:
                self._look_tgt = random.uniform(-1.0, 1.0)
                self._look_at = self._t + 1.4 + 1.8 * random.random()
        else:
            self._look_tgt = 0.0
        self._look += (self._look_tgt - self._look) * _rate(dt, 0.20)

        # Blink. Irregular on purpose: a metronome reads as a machine, and not
        # in the good way. Suppressed while asleep — the eyes are already shut.
        if self._blink > 0.0:
            self._blink = max(0.0, self._blink - dt * 8.5)
        elif self._t >= self._blink_at:
            if asleep:
                self._blink_at = self._t + 6.0
            else:
                self._blink = 1.0
                self._blink_at = self._t + 2.8 + 3.6 * random.random()

    def glance(self, dx: float, dy: float, hold: float = 1.1) -> None:
        """Look somewhere for a moment. Kept for interface parity — the slab
        only has horizontal travel, so `dy` is ignored."""
        self._look_tgt = max(-1.0, min(1.0, float(dx)))
        self._look_at = self._t + max(0.1, float(hold))

    # ── drawing ─────────────────────────────────────────────────────────────

    def paint(self, p: QPainter, cx: float, cy: float, r: float,
              primary: QColor, accent: QColor, bg: QColor | None = None) -> None:
        """Draw the slab centred on (cx, cy).

        `r` is the reference half-height the caller sized for; the slab is 0.78
        of it tall and 3.33 times that wide, so it fills the same band the head
        did. `primary` and `accent` are accepted for interface parity; the tone
        table below is what actually colours it, because the look is defined by
        two approved palettes rather than by the live theme.
        """
        if r <= 0.5:
            return

        tone = _TONES.get(self.tone, _TONES["cyan"])
        W = 3.33 * r * _SPAN
        H = _SPAN * r
        rect = QRectF(cx - W / 2.0, cy - H / 2.0, W, H)
        radius = H * 0.46

        p.save()
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        # Three looks, decided here rather than by the caller: asleep (or muted,
        # or told to be quiet), talking, and the calm in-between. The difference
        # between them is timing and mouth shape, so it has to live with the
        # animation state, not with whoever is drawing it.
        sleeping = bool(getattr(self, "_asleep", False))
        talking = self._mouth > 0.02
        if sleeping:
            self._paint_idle(p, rect, radius, tone, W, H)
        else:
            self._paint_lit(p, rect, radius, tone, W, H, talking)
            self._paint_face(p, rect, tone, W, H, talking=talking)

        p.restore()

    # -- shared pieces -------------------------------------------------------

    def _halo(self, p: QPainter, rect: QRectF, tone: dict, strength: float,
              spread: float) -> None:
        rad = rect.width() * spread
        g = QRadialGradient(rect.center(), rad)
        g.setColorAt(0.0, _rgba(tone["glow"], 0.16 * strength))
        g.setColorAt(0.55, _rgba(tone["glow"], 0.07 * strength))
        g.setColorAt(1.0, _rgba(tone["glow"], 0.0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g))
        p.drawEllipse(rect.center(), rad, rad * 0.62)

    def _paint_idle(self, p: QPainter, rect: QRectF, radius: float,
                    tone: dict, W: float, H: float) -> None:
        breath = 0.5 + 0.5 * math.sin(self._breath * 1.1)
        self._halo(p, rect, tone, 0.18 + 0.10 * breath, 0.62)

        # The slab, almost unlit: a dark glass shape with a faint edge, so it
        # reads as switched off rather than as a black hole in the HUD.
        g = QLinearGradient(0, rect.top(), 0, rect.bottom())
        g.setColorAt(0.0, _rgba(tone["idle"], 0.17))
        g.setColorAt(1.0, _rgba(tone["idle"], 0.05))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g))
        p.drawPath(_slab_path(rect, radius))

        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(_rgba(tone["idle"], 0.30 + 0.12 * breath), 1.0))
        p.drawPath(_slab_path(rect, radius))

        # Closed eyes: two downward arcs, drawn with a round cap so they read
        # as lids rather than as pauses in a line.
        gap = W * 0.075
        ey = rect.center().y() - H * 0.02
        p.setPen(QPen(_rgba(tone["face"], 0.55), max(2.0, H * 0.055),
                      Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        eye_r = H * 0.17
        for s in (-1, 1):
            p.drawArc(QRectF(rect.center().x() + s * gap - eye_r,
                             ey - eye_r, eye_r * 2, eye_r * 2),
                      int(200 * 16), int(140 * 16))

        # The z, drifting up and fading. One letter is enough; three would look
        # like a comic book.
        phase = (self._t * 0.42) % 1.0
        zx = rect.center().x() + W * 0.17
        zy = rect.top() - H * 0.05 - phase * H * 0.70
        f = QFont("Consolas")
        f.setBold(True)
        f.setPixelSize(max(8, int(H * (0.40 + phase * 0.18))))
        p.setFont(f)
        p.setPen(QPen(_rgba(tone["face"], 0.55 * (1.0 - phase))))
        p.drawText(QPointF(zx, zy), "z")

    def _paint_lit(self, p: QPainter, rect: QRectF, radius: float, tone: dict,
                   W: float, H: float, live: bool) -> None:
        strength = 0.85 + 0.15 * min(1.0, self._glow)
        self._halo(p, rect, tone, strength, 0.90)

        path = _slab_path(rect, radius)

        # Body: a left-to-right gradient, dark at the tail and saturated where
        # the light is. A flat fill reads as a sticker; the gradient is what
        # makes it read as glass with something behind it.
        g = QLinearGradient(rect.left(), 0, rect.right(), 0)
        g.setColorAt(0.0, _mix(tone["left"], tone["right"], 0.0))
        g.setColorAt(0.45, _mix(tone["left"], tone["right"], 0.45))
        g.setColorAt(1.0, _mix(tone["left"], tone["right"], 1.0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g))
        p.drawPath(path)

        # Glass sheen: bright along the top lip, falling to a soft dark base.
        sheen = QLinearGradient(0, rect.top(), 0, rect.bottom())
        sheen.setColorAt(0.0, _rgba(tone["rim"], 0.20))
        sheen.setColorAt(0.35, _rgba(tone["rim"], 0.03))
        sheen.setColorAt(0.75, QColor(0, 0, 0, 26))
        sheen.setColorAt(1.0, QColor(0, 0, 0, 52))
        p.setBrush(QBrush(sheen))
        p.drawPath(path)

        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(_rgba(tone["rim"], 0.26), 1.0))
        p.drawPath(path)

        # While listening, one quiet ring travels out of the edge: proof it is
        # still running without adding anything that demands attention.
        if not live:
            k = (self._t * 0.5) % 1.0
            grow = QRectF(rect)
            grow.adjust(-k * W * 0.07, -k * H * 0.22, k * W * 0.07, k * H * 0.22)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(_rgba(tone["rim"], 0.30 * (1.0 - k)), 1.4))
            p.drawPath(_slab_path(grow, radius + k * H * 0.12))

    def _paint_face(self, p: QPainter, rect: QRectF, tone: dict,
                    W: float, H: float, talking: bool) -> None:
        gap = W * 0.075
        eye_w = H * 0.095
        eye_h = H * 0.21
        cxx = rect.center().x()
        cy = rect.center().y()

        blink = 1.0
        if self._blink > 0.0:
            blink = max(0.06, abs(1.0 - 2.0 * self._blink))
        look = self._look * W * 0.018

        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(_rgba(tone["face"], 0.97)))
        for s in (-1, 1):
            p.drawEllipse(QPointF(cxx + s * gap + look, cy - H * 0.08),
                          eye_w, max(0.6, eye_h * blink))

        if talking:
            amp = self._mouth
            my = cy + H * 0.24
            mrx = H * (0.13 + 0.03 * amp)
            mry = H * (0.035 + 0.115 * amp)
        else:
            my = cy + H * 0.26
            mrx = H * 0.105
            mry = H * (0.042 + 0.010 * (0.5 + 0.5 * math.sin(self._t * 1.7)))
        p.setBrush(QBrush(_rgba(tone["face"], 0.97)))
        p.drawEllipse(QPointF(cxx + look * 0.6, my), mrx, mry)
