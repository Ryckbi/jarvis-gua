"""
Football match analysis and forecasting.

Data source: ESPN's public soccer API (no key, no quota) — 220 competitions
across every confederation. Nothing about a match is invented here: if a
number is missing from the feed it is reported as missing, not guessed.

The forecast itself is a standard goals model, not a lookup of anyone's odds:

    1. every completed match in a league this season is collected once;
    2. each club gets an attack and a defence strength, separately at home and
       away, as a ratio against the league average (shrunk toward 1.0 when the
       club has played only a few games);
    3. expected goals for the fixture are league average x attack x defence,
       nudged slightly by recent form (damped so a short streak cannot
       overpower a season);
    4. a Poisson grid over 0..8 goals for each side gives every market —
       win/draw/win, both teams to score, over/under, double chance and the
       most likely scorelines. A Dixon-Coles correction keeps 0-0/1-0/1-1
       honest, which plain Poisson overrates;
    5. that grid is then averaged over a range of plausible scoring rates
       (see _predictive_grid), because the rates were estimated from a partial
       season rather than known. The effect is that percentages are pulled
       toward the middle by an amount that depends on how much evidence each
       club actually has, and the home-win number carries a stated range.

The practical consequence: a 62% is a 62% with a 55-69 band, not a
falsely exact 62.0%, and a club five games into the season does not get the
same confidence as one that has played thirty.

All of it is cached in-process: a league's season is fetched once per
`_TTL`, so asking about five fixtures does not hit the network five times.
"""
from __future__ import annotations

import json
import math
import re
import threading
import time
import unicodedata
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher
from typing import Optional

import requests

SITE = "https://site.api.espn.com/apis/site/v2/sports/soccer"
CORE = "https://sports.core.api.espn.com/v2/sports/soccer"
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; MarkLVII/1.0)"}

_TTL          = 600          # league season cache, seconds
_TTL_LIVE     = 45           # fixtures/scoreboard cache, seconds
_TTL_FIXTURES = 300
_MAX_GOALS    = 8
_SHRINK       = 6.0          # pseudo-matches pulling a club toward average
_RHO          = -0.055       # Dixon-Coles low-score correlation

# Uncertainty mixture (see _predictive_grid). Five points on a lognormal whose
# mean is exactly 1 and whose variance is 1/(1.2*matches + 4): a club with 38
# games played gets a tight band, a club with 6 gets a wide one. Weights sum
# to 1 and the nodes are symmetric, so the mixture never shifts the mean.
_MIX_W = (0.05, 0.25, 0.40, 0.25, 0.05)
_MIX_Z = (-1.6, -0.6, 0.0, 0.6, 1.6)

_cache: dict[str, tuple[float, object]] = {}
# Parsed results live separately and longer. The raw JSON above is only kept as
# a short-lived guard against two calls racing to the same endpoint in the same
# seconds; keeping it longer held ~4.7 MB of scores, logos and link trees for
# ten numbers a card actually draws.
_data_cache: dict[str, tuple[float, object]] = {}
_lock = threading.Lock()


# ── small utilities ──────────────────────────────────────────────────────────

def _now() -> float:
    return time.time()


def _cache_get(key: str, ttl: float):
    with _lock:
        hit = _cache.get(key)
    if hit and _now() - hit[0] < ttl:
        return hit[1]
    return None


def _cache_put(key: str, value) -> None:
    with _lock:
        _cache[key] = (_now(), value)
        if len(_cache) > 40:                      # raw responses: a few days
            for k in sorted(_cache, key=lambda k: _cache[k][0])[:-20]:
                _cache.pop(k, None)


def _data_take(key: str, ttl: float):
    """Read a computed result (the small, long-lived cache)."""
    with _lock:
        hit = _data_cache.get(key)
    if hit and _now() - hit[0] < ttl:
        return hit[1]
    return None


def _data_put(key: str, value) -> None:
    with _lock:
        _data_cache[key] = (_now(), value)
        if len(_data_cache) > 60:
            for k in sorted(_data_cache, key=lambda k: _data_cache[k][0])[:-30]:
                _data_cache.pop(k, None)


def _get(url: str, ttl: float = _TTL_FIXTURES, params: Optional[dict] = None,
         store: bool = True):
    """Fetch JSON. `store=False` for endpoints whose payload is large and whose
    useful part the caller already caches in compact form (a day of worldwide
    fixtures is a ~2 MB link tree for ten numbers)."""
    key = url + ("?" + json.dumps(params, sort_keys=True) if params else "")
    cached = _cache_get(key, ttl)
    if cached is not None:
        return cached
    resp = requests.get(url, headers=HEADERS, params=params, timeout=18)
    resp.raise_for_status()
    data = resp.json()
    if store:
        _cache_put(key, data)
    return data


def _fold(text: str) -> str:
    """Compare names across feeds: accents, punctuation and club noise gone.

    "city" and "united" are deliberately NOT stripped — doing that once made
    "Man City" match Manchester United.
    """
    t = unicodedata.normalize("NFKD", str(text or ""))
    t = "".join(c for c in t if not unicodedata.combining(c)).lower()
    t = re.sub(r"\b(fc|cf|sc|ac|afc|club|the)\b", " ", t)
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


# What people say, mapped to what the feed calls the club. Applied before any
# comparison, so nicknames never have to be guessed by string similarity.
_TEAM_ALIASES = {
    "man city": "manchester city", "mancity": "manchester city",
    "man utd": "manchester united", "man united": "manchester united",
    "manchester utd": "manchester united",
    "spurs": "tottenham", "tottenham hotspur": "tottenham",
    "wolves": "wolverhampton", "brighton": "brighton hove albion",
    "newcastle": "newcastle united", "west ham": "west ham united",
    "nottingham": "nottingham forest", "leicester": "leicester city",
    "leeds": "leeds united", "inter": "internazionale", "inter milan": "internazionale",
    "ac milan": "milan", "milan": "milan", "juve": "juventus",
    "napoli": "napoli", "roma": "roma", "lazio": "lazio",
    "atletico": "atletico madrid", "atletico madrid": "atletico madrid",
    "real": "real madrid", "barca": "barcelona", "bayern": "bayern munchen",
    "bayern munich": "bayern munchen", "dortmund": "borussia dortmund",
    "bvb": "borussia dortmund", "leverkussen": "bayer leverkusen",
    "psg": "paris saint germain", "paris": "paris saint germain",
    "marseille": "olympique marseille", "lyon": "olympique lyonnais",
    "ajax": "ajax", "psv": "psv eindhoven", "feyenoord": "feyenoord",
    "porto": "fc porto", "benfica": "benfica", "sporting": "sporting cp",
    "galatasaray": "galatasaray", "fenerbahce": "fenerbahce",
    "persib": "persib bandung", "persija": "persija jakarta",
    "persebaya": "persebaya surabaya", "arema": "arema",
    "al hilal": "al hilal", "al nassr": "al nassr", "al ittihad": "al ittihad",
    "rsl": "real salt lake", "la galaxy": "la galaxy", "lafc": "los angeles fc",
}


def _tokens(text: str) -> list[str]:
    return [t for t in _fold(text).split() if t]


def _token_hit(a: str, b: str) -> float:
    """How well one word answers another; prefixes count from three letters."""
    if a == b:
        return 1.0
    if len(a) >= 3 and len(b) >= 3:
        if b.startswith(a) or a.startswith(b):
            return 0.82
        return SequenceMatcher(None, a, b).ratio() * 0.7
    return SequenceMatcher(None, a, b).ratio() * 0.7


def _num(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


# ── leagues ──────────────────────────────────────────────────────────────────

# Competitions ESPN serves but does not list in its own dropdown. Resolving an
# alias to one of these used to fail outright, because find_league() looked the
# slug up in the dropdown and returned None when it was missing — so a league
# that worked perfectly well reported itself as non-existent.
_OFF_TABLE_LEAGUES = {
    "idn.1": ("Liga Indonesia", "Indonesia"),
}

_ALIASES = {
    "epl": "eng.1", "premier league": "eng.1", "liga inggris": "eng.1",
    "liga spanyol": "esp.1", "laliga": "esp.1", "la liga": "esp.1",
    "liga italia": "ita.1", "serie a": "ita.1",
    "liga jerman": "ger.1", "bundesliga": "ger.1",
    "liga prancis": "fra.1", "ligue 1": "fra.1",
    "champions": "uefa.champions", "liga champions": "uefa.champions",
    "champions league": "uefa.champions", "ucl": "uefa.champions",
    "uefa champions league": "uefa.champions",
    "liga champion": "uefa.champions", "champion league": "uefa.champions",
    # The African and Asian editions are real competitions people also ask
    # about, so they get their own unambiguous names instead of competing for
    # the generic one.
    "caf champions": "caf.champions", "caf champions league": "caf.champions",
    "afc champions": "afc.champions", "afc champions league": "afc.champions",
    "liga champions asia": "afc.champions",
    "europa league": "uefa.europa", "liga eropa": "uefa.europa",
    "europa": "uefa.europa", "uel": "uefa.europa",
    "conference league": "uefa.europa.conf",
    "liga konferensi": "uefa.europa.conf", "conference": "uefa.europa.conf",
    "liga indonesia": "idn.1", "liga 1": "idn.1",
    "world cup": "fifa.world", "piala dunia": "fifa.world",
    "indonesia": "idn.1", "liga indonesia 1": "idn.1", "bri liga 1": "idn.1",
    "shopee liga 1": "idn.1",
    "mls": "usa.1", "liga arab saudi": "ksa.1", "saudi": "ksa.1",
    "eredivisie": "ned.1", "liga belanda": "ned.1",
    "liga portugal": "por.1", "primeira liga": "por.1",
    "super lig": "tur.1", "liga turki": "tur.1",
    # Cups and tournaments. find_league() fuzzy-matches names too, but these
    # are the ones asked for by a short Indonesian or English name that does
    # not resemble ESPN's ("carabao" vs "English Carabao Cup" is close, but
    # "piala fa" is not).
    "fa cup": "eng.fa", "piala fa": "eng.fa", "piala inggris": "eng.fa",
    "carabao": "eng.league_cup", "carabao cup": "eng.league_cup",
    "league cup": "eng.league_cup", "piala liga": "eng.league_cup",
    "copa del rey": "esp.copa_del_rey", "piala raja": "esp.copa_del_rey",
    "coppa italia": "ita.coppa_italia",
    "dfb pokal": "ger.dfb_pokal", "piala jerman": "ger.dfb_pokal",
    "coupe de france": "fra.coupe_de_france",
    "euro": "uefa.euro", "piala eropa": "uefa.euro",
    "euro 2028": "uefa.euro",
    "nations league": "uefa.nations", "uefa nations": "uefa.nations",
    "copa america": "conmebol.america", "copa américa": "conmebol.america",
    "club world cup": "fifa.cwc", "piala dunia antar klub": "fifa.cwc",
    "pildun": "fifa.world", "world cup 2026": "fifa.world",
    "kualifikasi piala dunia": "fifa.worldq.uefa",
    "asian cup": "afc.asian.cup", "piala asia": "afc.asian.cup",
    "piala aff": "aff.championship", "aff cup": "aff.championship",
    "aff": "aff.championship", "piala aff 2026": "aff.championship",
}


# ESPN's dropdown does not carry a country, and asking the core API about all
# 220 competitions would be 220 requests. The slug prefix is the country code,
# so this table covers the leagues people actually ask about and the rest fall
# back to their region prefix.
_COUNTRY_BY_PREFIX = {
    "eng": "England", "esp": "Spain", "ita": "Italy", "ger": "Germany",
    "fra": "France", "ned": "Netherlands", "por": "Portugal", "tur": "Turkey",
    "bel": "Belgium", "sco": "Scotland", "gre": "Greece", "rus": "Russia",
    "ukr": "Ukraine", "aut": "Austria", "sui": "Switzerland", "den": "Denmark",
    "swe": "Sweden", "nor": "Norway", "pol": "Poland", "rou": "Romania",
    "cze": "Czechia", "cro": "Croatia", "srb": "Serbia", "bul": "Bulgaria",
    "hun": "Hungary", "idn": "Indonesia", "tha": "Thailand", "vie": "Vietnam",
    "mas": "Malaysia", "sgp": "Singapore", "jpn": "Japan", "kor": "South Korea",
    "chn": "China", "aus": "Australia", "ind": "India", "irn": "Iran",
    "ksa": "Saudi Arabia", "uae": "United Arab Emirates", "qat": "Qatar",
    "egy": "Egypt", "mar": "Morocco", "tun": "Tunisia", "alg": "Algeria",
    "rsa": "South Africa", "nga": "Nigeria", "gha": "Ghana", "ken": "Kenya",
    "usa": "United States", "mex": "Mexico", "can": "Canada", "bra": "Brazil",
    "arg": "Argentina", "uru": "Uruguay", "col": "Colombia", "chi": "Chile",
    "per": "Peru", "ecu": "Ecuador", "par": "Paraguay", "ven": "Venezuela",
    "bol": "Bolivia", "crc": "Costa Rica", "hon": "Honduras", "slv": "El Salvador",
    "gua": "Guatemala", "pan": "Panama", "jam": "Jamaica",
    "uefa": "Europe", "fifa": "World", "concacaf": "North America",
    "conmebol": "South America", "caf": "Africa", "afc": "Asia",
    "ofc": "Oceania",
}


def leagues() -> list[dict]:
    """Every soccer competition ESPN carries, with its country or region."""
    out = _data_take("leagues", 6 * 3600)
    if out is not None:
        return out
    data = _get(
        "https://site.web.api.espn.com/apis/site/v2/leagues/dropdown",
        ttl=24 * 3600, params={"lang": "en", "region": "us", "limit": 500,
                               "sport": "soccer"}, store=False,
    )
    out = []
    for lg in data.get("leagues", []):
        slug = lg.get("slug") or ""
        if not slug:
            continue
        country = (lg.get("area") or {}).get("name") or ""
        if not country:
            prefix = slug.split(".")[0]
            country = _COUNTRY_BY_PREFIX.get(prefix, prefix.capitalize())
        out.append({
            "slug": slug,
            "name": lg.get("name") or slug,
            "country": country,
        })
    out.sort(key=lambda x: (x["country"], x["name"]))
    if out:
        _data_put("leagues", out)
    return out


def find_league(query: str) -> Optional[dict]:
    """Resolve 'premier league', 'Liga Inggris' or 'eng.1' to one competition."""
    q = (query or "").strip().lower()
    if not q:
        return None
    table = leagues()
    if q in {l["slug"] for l in table}:
        return next(l for l in table if l["slug"] == q)
    if q in _ALIASES:
        slug = _ALIASES[q]
        found = next((l for l in table if l["slug"] == slug), None)
        if found is not None:
            return found
        extra = _OFF_TABLE_LEAGUES.get(slug)
        if extra is not None:
            return {"slug": slug, "name": extra[0], "country": extra[1]}
        # An alias is a hand-written assertion that this competition exists; a
        # missing dropdown row is not evidence against it.
        return {"slug": slug, "name": slug, "country": ""}
    folded = _fold(q)
    best, score = None, 0.0
    for lg in table:
        for candidate in (lg["name"], lg["slug"], lg["country"] + " " + lg["name"]):
            r = SequenceMatcher(None, folded, _fold(candidate)).ratio()
            if folded and folded in _fold(candidate):
                r = max(r, 0.92)
            if r > score:
                best, score = lg, r
    return best if score >= 0.62 else None


# ── teams ────────────────────────────────────────────────────────────────────

def teams(slug: str) -> list[dict]:
    cached = _data_take(f"teams:{slug}", 12 * 3600)
    if cached is not None:
        return cached
    data = _get(f"{SITE}/{slug}/teams", ttl=24 * 3600, store=False)
    groups = (data.get("sports") or [{}])[0].get("leagues") or []
    raw = []
    for g in groups:
        raw.extend(g.get("teams") or [])
    out = []
    for row in raw:
        t = row.get("team") or {}
        if t.get("id"):
            out.append({
                "id": str(t["id"]),
                "name": t.get("displayName") or t.get("name") or "",
                "short": t.get("abbreviation") or "",
                "logo": ((t.get("logos") or [{}])[0] or {}).get("href", ""),
            })
    if out:
        _data_put(f"teams:{slug}", out)
    return out


def find_team(slug: str, query: str) -> Optional[dict]:
    """Resolve a club name against one competition, nicknames included.

    Scoring is token-based and both directions matter: every word the user
    typed must land on a word in the club's name, and extra words in the
    club's name ("FC", "Hove Albion") are free. That is what keeps
    "Man City" away from Manchester United while still matching
    "Brighton" to Brighton & Hove Albion.
    """
    q = _fold(query)
    if not q:
        return None
    q = _TEAM_ALIASES.get(q, q)
    q_tokens = q.split()
    table = teams(slug)
    best, score = None, 0.0
    for t in table:
        names = [t["name"], t.get("short", "")]
        for name in names:
            if not name:
                continue
            cand = _fold(name)
            cand = _TEAM_ALIASES.get(cand, cand)
            c_tokens = cand.split()
            if not c_tokens:
                continue
            if q == cand:
                return t
            covered = 0.0
            for qt in q_tokens:
                hit = max((_token_hit(qt, ct) for ct in c_tokens), default=0.0)
                covered += hit
            coverage = covered / len(q_tokens)
            # Penalise typing fewer words than the club's own name only when
            # the unmatched part is meaningful — "brighton" for "brighton hove
            # albion" is fine, "man" for a two-word club is not.
            extra = max(len(c_tokens) - len(q_tokens), 0)
            precision = 1.0 - 0.09 * extra
            total = coverage * (precision if len(q_tokens) > 1 else min(1.0, precision + 0.16))
            if total > score:
                best, score = t, total
    return best if score >= 0.84 else None


# ── season results ───────────────────────────────────────────────────────────

def _team_matches(slug: str, team_id: str) -> list[dict]:
    """This season's fixtures for one club, from ESPN's team schedule."""
    data = _get(f"{SITE}/{slug}/teams/{team_id}/schedule", ttl=900)
    out = []
    for ev in data.get("events") or []:
        comp = (ev.get("competitions") or [{}])[0]
        status = (comp.get("status") or ev.get("status") or {})
        state = ((status.get("type") or {}).get("state")) or ""
        sides = {}
        for c in comp.get("competitors") or []:
            score = c.get("score")
            if isinstance(score, dict):
                score = score.get("value", score.get("displayValue"))
            sides[c.get("homeAway")] = {
                "id": str((c.get("team") or {}).get("id") or ""),
                "name": (c.get("team") or {}).get("displayName") or "",
                "score": None if score is None else int(_num(score)),
            }
        if "home" not in sides or "away" not in sides:
            continue
        out.append({
            "id": str(ev.get("id") or comp.get("id") or ""),
            "date": ev.get("date") or comp.get("date") or "",
            "state": state,
            "home": sides["home"],
            "away": sides["away"],
            "neutral": bool(comp.get("neutralSite")),
        })
    out.sort(key=lambda m: m["date"])
    return out


def _league_matches(slug: str) -> list[dict]:
    """All completed matches in the competition, each counted once."""
    cached = _data_take(f"season:{slug}", _TTL)
    if cached is not None:
        return cached
    seen: dict[str, dict] = {}
    for t in teams(slug):
        try:
            for m in _team_matches(slug, t["id"]):
                if m["state"] == "post" and m["home"]["score"] is not None \
                        and m["away"]["score"] is not None and m["id"]:
                    seen.setdefault(m["id"], m)
        except Exception:
            continue
    matches = sorted(seen.values(), key=lambda m: m["date"])
    if matches:
        _data_put(f"season:{slug}", matches)
    return matches


# ── the model ────────────────────────────────────────────────────────────────

def _shrink(ratio: float, weight: float) -> float:
    """Pull a small-sample ratio back toward the league average of 1.0."""
    return (ratio * weight + 1.0 * _SHRINK) / (weight + _SHRINK)


def _strengths(matches: list[dict]) -> dict:
    """League averages plus per-club home/away attack and defence ratios."""
    home_goals = [m["home"]["score"] for m in matches]
    away_goals = [m["away"]["score"] for m in matches]
    n = len(matches) or 1
    avg_home = max(sum(home_goals) / n, 0.4)
    avg_away = max(sum(away_goals) / n, 0.3)

    sides: dict[str, dict] = {}
    for m in matches:
        for venue, opp in (("home", "away"), ("away", "home")):
            tid = m[venue]["id"]
            if not tid:
                continue
            s = sides.setdefault(tid, {"home": [], "away": [], "pts": [], "dates": []})
            s[venue].append((m[venue]["score"], m[opp]["score"]))
            gf, ga = m[venue]["score"], m[opp]["score"]
            s["pts"].append(3 if gf > ga else 1 if gf == ga else 0)
            s["dates"].append(m["date"])

    table = {}
    for tid, s in sides.items():
        hw = len(s["home"])
        aw = len(s["away"])
        hgf = sum(a for a, _ in s["home"]) / hw if hw else 0
        hga = sum(b for _, b in s["home"]) / hw if hw else 0
        agf = sum(a for a, _ in s["away"]) / aw if aw else 0
        aga = sum(b for _, b in s["away"]) / aw if aw else 0
        recent = s["pts"][-5:]
        table[tid] = {
            "played": hw + aw,
            "attack_home": _shrink(hgf / avg_home, hw) if hw else 1.0,
            "attack_away": _shrink(agf / avg_away, aw) if aw else 1.0,
            "defence_home": _shrink(hga / avg_away, hw) if hw else 1.0,
            "defence_away": _shrink(aga / avg_home, aw) if aw else 1.0,
            "form": (sum(recent) / (3 * len(recent))) if recent else 0.5,
            "gf_avg": ((hgf * hw + agf * aw) / (hw + aw)) if (hw + aw) else 0.0,
            "ga_avg": ((hga * hw + aga * aw) / (hw + aw)) if (hw + aw) else 0.0,
            "wins": sum(1 for p in s["pts"] if p == 3),
            "draws": sum(1 for p in s["pts"] if p == 1),
            "losses": sum(1 for p in s["pts"] if p == 0),
        }
    return {
        "matches": len(matches),
        "avg_home": avg_home,
        "avg_away": avg_away,
        "table": table,
    }


def _poisson(k: int, lam: float) -> float:
    return math.exp(-lam) * lam ** k / math.factorial(k)


def _tau(a: int, b: int, lam: float, mu: float, rho: float = _RHO) -> float:
    """Dixon-Coles correction for the four lowest scorelines."""
    if a == 0 and b == 0:
        return 1 - lam * mu * rho
    if a == 1 and b == 0:
        return 1 + mu * rho
    if a == 0 and b == 1:
        return 1 + lam * rho
    if a == 1 and b == 1:
        return 1 - rho
    return 1.0


def _grid(lam: float, mu: float, max_goals: int = _MAX_GOALS) -> list[list[float]]:
    rows = []
    for a in range(max_goals + 1):
        row = []
        for b in range(max_goals + 1):
            row.append(max(_poisson(a, lam) * _poisson(b, mu) * _tau(a, b, lam, mu), 0.0))
        rows.append(row)
    total = sum(sum(r) for r in rows) or 1.0
    return [[v / total for v in row] for row in rows]


def _sigma_for(played: int) -> float:
    """How unsure the model is about one side's scoring rate, in log space.

    A club with 38 matches behind it has a rate the season really supports; a
    club with six has a rate that is mostly noise. Four pseudo-games keep the
    band finite for a club that has barely played.
    """
    n = max(1.0, float(played or 0))
    return math.sqrt(1.0 / (1.2 * n + 4.0))


def _poisson_vec(lam: float, max_goals: int = _MAX_GOALS) -> list[float]:
    """Poisson probabilities for 0..max_goals, computed once per rate.

    Hoisted out of the scenario loop: the mixture needs 25 grids but only ten
    distinct rates, and recomputing exp() and factorial() per cell made the
    accuracy work cost real milliseconds on a twenty-match schedule.
    """
    e = math.exp(-lam)
    out = [e]
    term = e
    for k in range(1, max_goals + 1):
        term = term * lam / k
        out.append(term)
    return out


def _predictive_grid(lam: float, mu: float, played_home: int,
                     played_away: int) -> tuple[list[list[float]], dict]:
    """Poisson grid averaged over how uncertain each scoring rate is.

    WHY THIS EXISTS
        A single (lam, mu) pair produces a grid that behaves as if the two
        scoring rates were known exactly. They are not: they are estimated
        from a partial season, so the honest distribution is a Poisson whose
        own rate is uncertain. Mixing the grid over a range of plausible rates
        does two things the single-point grid cannot:

          - extreme outcomes get pulled back toward the middle. "92% home win"
            becomes something like 85%, because a bad week for the favourite
            is a real possibility, not an impossibility. That is the direction
            the old numbers were wrong in, and it is the direction that hurts
            (the confident pick losing);
          - the amount of pullback is per club. A side with 34 matches is
            treated as nearly settled, a side three games into a new manager as
            barely known. A flat fudge factor could not do that.

    The mixture is over five symmetric lognormal nodes with weights summing to
    one, so it shifts no probability's mean — it only widens the spread. The
    second return value is the spread of the home-win probability across those
    nodes: a range to quote instead of pretending one decimal is the truth.
    """
    sh, sa = _sigma_for(played_home), _sigma_for(played_away)
    size = _MAX_GOALS + 1

    # The node weights are symmetric, but exp() is not: averaging exp(s*z) over
    # them lands slightly above 1, which would quietly add a couple of percent
    # to expected goals. Dividing by that factor keeps the mixture's mean rate
    # exactly lam and mu, so the only thing it changes is the spread — which is
    # the point. Without this the "more accurate" model would also predict more
    # goals than the old one, and nobody would be able to tell which change did
    # what.
    norm_h = sum(w * math.exp(sh * z) for w, z in zip(_MIX_W, _MIX_Z))
    norm_a = sum(w * math.exp(sa * z) for w, z in zip(_MIX_W, _MIX_Z))
    lams = [min(max(lam * math.exp(sh * z) / norm_h, 0.05), 6.0) for z in _MIX_Z]
    mus = [min(max(mu * math.exp(sa * z) / norm_a, 0.05), 6.0) for z in _MIX_Z]
    pv_lam = [_poisson_vec(v) for v in lams]
    pv_mu = [_poisson_vec(v) for v in mus]

    acc = [[0.0] * size for _ in range(size)]
    home_wins: list[tuple[float, float]] = []
    for i in range(len(_MIX_Z)):
        pl = pv_lam[i]
        for j in range(len(_MIX_Z)):
            pm = pv_mu[j]
            w = _MIX_W[i] * _MIX_W[j]
            g = [[pl[a] * pm[b] * _tau(a, b, lams[i], mus[j])
                  for b in range(size)] for a in range(size)]
            norm = sum(sum(r) for r in g) or 1.0
            g = [[v / norm for v in r] for r in g]
            for a in range(size):
                row, grow = acc[a], g[a]
                for b in range(size):
                    row[b] += w * grow[b]
            # Home win from this scenario alone: everything below the diagonal,
            # which is the same quantity _market() reads off the mixed grid.
            home_wins.append((sum(g[a][b] for a in range(size)
                                  for b in range(a)), w))

    total = sum(sum(r) for r in acc) or 1.0
    grid = [[v / total for v in r] for r in acc]

    # Weighted 10th/90th percentile of the home-win probability across the
    # scenarios: the range the honest answer sits in. Walked by cumulative
    # weight, so each percentile names the first scenario whose running weight
    # reaches it.
    home_wins.sort()
    total_w = sum(w for _, w in home_wins) or 1.0
    lo = home_wins[0][0]
    hi = home_wins[-1][0]
    got_lo = got_hi = False
    cum = 0.0
    for p, w in home_wins:
        cum += w / total_w
        if not got_lo and cum >= 0.10:
            lo, got_lo = p, True
        if not got_hi and cum >= 0.90:
            hi, got_hi = p, True
            break
    return grid, {"home_win_low": min(lo, hi), "home_win_high": max(lo, hi),
                  "sigma_home": sh, "sigma_away": sa}


def _market(grid: list[list[float]]) -> dict:
    p_home = p_draw = p_away = 0.0
    btts = 0.0
    # Every goal line people actually bet, accumulated once while the grid is
    # already being walked. The old code kept only 1.5/2.5/3.5 and exposed only
    # 2.5, so the analysis had one number where the question is "over/under
    # WHAT?" — an over line is meaningless without saying which.
    lines = {1.5: 0.0, 2.5: 0.0, 3.5: 0.0, 4.5: 0.0}
    scores = []
    for a, row in enumerate(grid):
        for b, p in enumerate(row):
            if a > b:
                p_home += p
            elif a == b:
                p_draw += p
            else:
                p_away += p
            if a >= 1 and b >= 1:
                btts += p
            tot = a + b
            for line in lines:
                if tot > line:
                    lines[line] += p
            scores.append((p, a, b))
    scores.sort(reverse=True)
    # Expected goals from the grid itself, not from lam+mu: the distribution is
    # what the probabilities come from, so the total has to be read off the same
    # thing or the two disagree at the edges.
    exp_goals = sum(p * (a + b) for a, row in enumerate(grid)
                    for b, p in enumerate(row))
    return {
        "home_win": p_home,
        "draw": p_draw,
        "away_win": p_away,
        "btts_yes": btts,
        "btts_no": 1 - btts,
        "over_1_5": lines[1.5],
        "over_2_5": lines[2.5],
        "over_3_5": lines[3.5],
        "over_4_5": lines[4.5],
        "under_2_5": 1 - lines[2.5],
        "under_3_5": 1 - lines[3.5],
        "expected_goals": exp_goals,
        "over_lines": {str(k): {"over": v, "under": 1 - v}
                       for k, v in lines.items()},
        "dc_1x": p_home + p_draw,
        "dc_12": p_home + p_away,
        "dc_x2": p_draw + p_away,
        "scores": [{"score": f"{a}-{b}", "prob": p} for p, a, b in scores[:6]],
    }


def _reasons(home_team, away_team, th, ta, st, lam, mu, m) -> list[dict]:
    """WHY the percentages came out the way they did, in plainer words.

    Every line is derived from the same numbers the forecast was built from,
    so this is an explanation rather than a second opinion. Each item is
    {"title": short claim, "detail": the evidence behind it}, which is what the
    pop-out and the spoken reply both draw from.

    Nothing here is invented: if a club's numbers are ordinary, that is what it
    says, and the sample size is always mentioned when it is small.
    """
    reasons = []
    h, a = home_team["name"], away_team["name"]

    def per_game(x: float) -> str:
        return f"{x:.2f}"

    # 1. Who creates more, in expected goals.
    gap = lam - mu
    if abs(gap) < 0.2:
        reasons.append({
            "title": "Dua tim hampir seimbang",
            "detail": f"Model ngasih {h} {per_game(lam)} gol dan {a} {per_game(mu)} "
                      f"gol. Selisihnya cuma {abs(gap):.2f}, jadi persentase "
                      f"ketiganya nyebar rata.",
        })
    else:
        better, worse = (h, a) if gap > 0 else (a, h)
        reasons.append({
            "title": f"{better} lebih produktif",
            "detail": f"{h} {per_game(lam)} gol vs {a} {per_game(mu)} gol. "
                      f"Selisih {abs(gap):.2f} gol ini yang motong peluang "
                      f"{worse}.",
        })

    # 2. Attack and defence, as ratios against a league-average side.
    def strength_row(name, row, is_home):
        atk = row["attack"]
        dfn = row["defence"]
        label = []
        label.append("serangan di atas rata-rata" if atk > 1.08
                     else "serangan di bawah rata-rata" if atk < 0.92
                     else "serangan biasa")
        label.append("pertahanan rapat" if dfn < 0.92
                     else "pertahanan bocor" if dfn > 1.08
                     else "pertahanan biasa")
        venue = "di kandang" if is_home else "di tandang"
        return (f"{name} {venue}: {label[0]} ({atk:.2f}x rata-rata liga), "
                f"{label[1]} ({dfn:.2f}x).")

    reasons.append({
        "title": "Kekuatan serang & bertahan",
        "detail": strength_row(h, th, True) + " " + strength_row(a, ta, False),
    })

    # 3. Home advantage, stated as a number rather than a cliché.
    edge = lam / (lam + mu) if (lam + mu) else 0.5
    reasons.append({
        "title": "Faktor kandang",
        "detail": f"Tim kandang rata-rata nyetak lebih banyak di liga ini, dan "
                  f"{h} main di rumah. Hitungan model: {edge * 100:.0f}% dari "
                  f"total gol yang diharapkan jatuh ke sisi {h}.",
    })

    # 4. Sample size — the honest caveat.
    played = min(th["played"], ta["played"])
    if played < 6:
        reasons.append({
            "title": "Datanya masih tipis",
            "detail": f"{h} baru {th['played']} laga, {a} baru {ta['played']} "
                      f"laga musim ini. Makin sedikit laga, makin gede "
                      f"kemungkinan angkanya meleset.",
        })
    else:
        reasons.append({
            "title": "Ukuran sampel",
            "detail": f"Dasarnya {th['played']} laga {h} dan {ta['played']} laga "
                      f"{a} musim ini — cukup buat baca pola, belum tentu buat "
                      f"laga tunggal.",
        })

    # 5. The market that is most decided, if there is one.
    if m["btts_yes"] >= 0.58:
        reasons.append({
            "title": "Dua-duanya punya peluang nyetak",
            "detail": f"{h} rata-rata {th['gf_avg']:.2f} gol/laga, {a} "
                      f"{ta['gf_avg']:.2f}. Dua-duanya bukan tim yang "
                      f"kedodoran di depan gawang.",
        })
    elif m["btts_no"] >= 0.58:
        reasons.append({
            "title": "Satu sisi kemungkinan buntu",
            "detail": f"Salah satu tim punya pertahanan yang jauh lebih rapi "
                      f"dibanding serangan lawannya, jadi peluang satu tim "
                      f"gagal nyetak lebih besar.",
        })
    # 6. Double chance — the market most people actually ask about, and the
    #    one whose numbers are least obvious: "1X 74%" is two results, not one.
    dc = {"1X": m["dc_1x"], "X2": m["dc_x2"], "12": m["dc_12"]}
    best = max(dc, key=lambda k: dc[k])
    covers = {
        "1X": f"{h} menang atau seri",
        "X2": f"seri atau {a} menang",
        "12": f"{h} atau {a} menang, seri tidak dihitung",
    }
    # 6b. Over/under, with the line named and the arithmetic shown. "Over 2.5:
    #     57%" on its own is a number floating free; what makes it usable is
    #     which total the two attacks actually point at.
    xg = m["expected_goals"]
    lines = {"1.5": m["over_1_5"], "2.5": m["over_2_5"],
             "3.5": m["over_3_5"], "4.5": m["over_4_5"]}
    # The line closest to a coin flip is the interesting one, and the one a
    # bettor is actually choosing between. Report that, then the extremes.
    near = min(lines, key=lambda k: abs(lines[k] - 0.5))
    over_side = lines[near] >= 0.5
    reasons.append({
        "title": f"Garis paling ketat: {near} — "
                 f"{'over' if over_side else 'under'} "
                 f"({(lines[near] if over_side else 1 - lines[near]) * 100:.0f}%)",
        "detail": f"Model memperkirakan {xg:.1f} gol total. Dari situ: over 1.5 "
                  f"{lines['1.5'] * 100:.0f}%, over 2.5 "
                  f"{lines['2.5'] * 100:.0f}%, over 3.5 "
                  f"{lines['3.5'] * 100:.0f}%, over 4.5 "
                  f"{lines['4.5'] * 100:.0f}%. Garis {near} yang paling dekat "
                  f"ke 50-50, jadi di situ pilihannya beneran penting.",
    })
    # And the reason for the total itself: both attacks, and whether either
    # defence is the kind that turns a normal game into a goalfest.
    reasons.append({
        "title": f"Kenapa totalnya sekitar {xg:.1f} gol",
        "detail": f"{h} rata-rata {th['gf_avg']:.2f} gol/laga dan kemasukan "
                  f"{th['ga_avg']:.2f}; {a} {ta['gf_avg']:.2f} dan kemasukan "
                  f"{ta['ga_avg']:.2f}. Angka itu digabung, lalu disesuaikan "
                  f"sama kekuatan lawan di tabel — bukan sekadar dijumlah.",
    })

    reasons.append({
        "title": f"Double chance paling aman: {best} ({dc[best] * 100:.0f}%)",
        "detail": f"{best} artinya {covers[best]}. Diambil dari peluang "
                  f"1 {m['home_win'] * 100:.0f}% · X {m['draw'] * 100:.0f}% · "
                  f"2 {m['away_win'] * 100:.0f}% — jumlah dua hasil yang "
                  f"dicakup. Pilihannya {best} karena itu yang paling besar; "
                  f"yang paling kecil {min(dc, key=dc.get)} "
                  f"({min(dc.values()) * 100:.0f}%) justru dua hasil yang "
                  f"paling nggak didukung model.",
    })
    return reasons


# ── squads: who is available, and who is one card from trouble ───────────────

def _player_stat(player: dict, name: str, default: float = 0.0) -> float:
    """Read one season stat off a roster entry. 0.0 when it is not there.

    ESPN nests stats three levels down (statistics -> splits -> categories ->
    stats). A player who has not played yet has no `statistics` key at all, so
    every lookup has to tolerate absence rather than assume a shape.
    """
    try:
        cats = player["statistics"]["splits"]["categories"]
    except (KeyError, TypeError):
        return default
    for cat in cats or []:
        for st in cat.get("stats") or []:
            if st.get("name") == name:
                try:
                    return float(st.get("value"))
                except (TypeError, ValueError):
                    return default
    return default


def squad(slug: str, team_id: str) -> dict:
    """Discipline and usage for one club, from the same public feed.

    WHAT THIS IS NOT
        It is not an injury report. ESPN's soccer feed returns an empty
        `injuries` list for every club checked, and its team-level injuries
        endpoint answers with `count: 0` for the whole league — so a build that
        printed "3 players injured" would be inventing them. The caller is told
        `injuries_available: False` and can say so plainly instead.

    WHAT IT IS
        Real, present data from the club roster: appearances, minutes, goals,
        assists, and the card record. That is what makes a squad note useful
        rather than decorative — a first-choice striker on four yellows is one
        booking from a ban, and a side whose minutes are concentrated in eleven
        players is more exposed than a rotation side when one of them is out.
    """
    try:
        data = _get(f"{SITE}/{slug}/teams/{team_id}/roster", ttl=900)
    except Exception:
        return {"available": False, "injuries_available": False, "players": []}

    rows = []
    for p in data.get("athletes") or []:
        if not isinstance(p, dict):
            continue
        name = p.get("displayName") or p.get("fullName") or ""
        if not name:
            continue
        rows.append({
            "name": name,
            "pos": ((p.get("position") or {}).get("abbreviation") or "").strip(),
            "status": ((p.get("status") or {}).get("name") or "").strip(),
            "apps": int(_player_stat(p, "appearances")),
            "minutes": int(_player_stat(p, "minutes")),
            "goals": int(_player_stat(p, "totalGoals")),
            "assists": int(_player_stat(p, "goalAssists")),
            "yellow": int(_player_stat(p, "yellowCards")),
            "red": int(_player_stat(p, "redCards")),
        })

    if not rows:
        return {"available": False, "injuries_available": False, "players": []}

    played = [r for r in rows if r["apps"] > 0]
    # Minutes, not appearances: a substitute's five cameos are not a workload.
    by_usage = sorted(played, key=lambda r: (r["minutes"], r["apps"]), reverse=True)
    by_goals = sorted(played, key=lambda r: (r["goals"], r["assists"]), reverse=True)

    return {
        "available": True,
        # Stated explicitly so the interface can be honest instead of silent.
        "injuries_available": False,
        "squad_size": len(rows),
        "used": len(played),
        "players": by_usage[:5],
        "top_scorer": ({k: by_goals[0][k] for k in ("name", "goals", "assists")}
                       if by_goals and by_goals[0]["goals"] > 0 else None),
        "booked": [{"name": r["name"], "yellow": r["yellow"], "red": r["red"]}
                   for r in sorted(played, key=lambda r: (r["yellow"], r["red"]),
                                   reverse=True) if r["yellow"] or r["red"]][:4],
        "reds": [{"name": r["name"], "red": r["red"]}
                 for r in sorted(played, key=lambda r: r["red"], reverse=True)
                 if r["red"] > 0][:3],
        # One booking from an accumulation ban in most domestic leagues; the
        # note says "most", because the exact number changes by competition.
        "one_from_ban": [{"name": r["name"], "yellow": r["yellow"]}
                         for r in played if r["yellow"] in (4, 9)][:3],
    }


def _squad_reasons(home_name: str, away_name: str, hs: dict, as_: dict) -> list[dict]:
    """Plain-language squad notes, one per club, from the numbers above.

    Only claims what the feed supports. Where the feed has nothing — injuries —
    it says so once, rather than quietly leaving a hole the reader would fill
    with an assumption.
    """
    out = []
    for name, sq in ((home_name, hs), (away_name, as_)):
        if not sq.get("available"):
            continue
        bits = []
        top = sq.get("top_scorer")
        if top and top["goals"]:
            bits.append(f"{top['name']} {top['goals']} gol"
                        + (f" + {top['assists']} assist" if top["assists"] else ""))
        if sq.get("reds"):
            r = sq["reds"][0]
            bits.append(f"{r['name']} sudah {r['red']} kartu merah musim ini")
        if sq.get("one_from_ban"):
            b = sq["one_from_ban"][0]
            bits.append(f"{b['name']} {b['yellow']} kartu kuning — satu lagi "
                        f"kena sanksi akumulasi")
        elif sq.get("booked"):
            b = sq["booked"][0]
            bits.append(f"{b['name']} paling sering kena kartu ({b['yellow']})")
        if not bits:
            bits.append(f"{sq.get('used', 0)} pemain sudah main, tanpa catatan "
                        f"kartu yang menonjol")
        out.append({
            # Tagged so the card can put these in their own section instead of
            # repeating them under KENAPA GITU — same fact, one place.
            "kind": "squad",
            "title": f"Skuad {name}",
            "detail": "; ".join(bits) + ". Data cedera tidak tersedia dari "
                      "sumber ini, jadi yang di atas adalah disiplin dan "
                      "pemakaian pemain, bukan status kebugaran.",
        })
    return out


def _pct(x: float) -> float:
    return round(x * 100, 1)


def _standings(slug: str) -> dict:
    """Season table for one competition: goals for/against and games played.

    One request per league instead of one per club, which is what makes a
    ten-match slate finish in about a second instead of seventeen.
    """
    cached = _data_take(f"table:{slug}", _TTL)
    if cached is not None:
        return cached
    data = _get(f"https://site.api.espn.com/apis/v2/sports/soccer/{slug}/standings",
                ttl=_TTL, store=False)
    out = {}
    for child in data.get("children") or []:
        for e in ((child.get("standings") or {}).get("entries") or []):
            team = e.get("team") or {}
            stats = {s.get("name"): s.get("value") for s in e.get("stats") or []}
            tid = str(team.get("id") or "")
            played = _num(stats.get("gamesPlayed"))
            gf = _num(stats.get("pointsFor"))
            ga = _num(stats.get("pointsAgainst"))
            if not tid or played <= 0:
                continue
            out[tid] = {
                "name": team.get("displayName") or "",
                "played": played,
                "gf": gf,
                "ga": ga,
                "gf_avg": gf / played,
                "ga_avg": ga / played,
                "wins": _num(stats.get("wins")),
                "draws": _num(stats.get("ties")),
                "losses": _num(stats.get("losses")),
            }
    _data_put(f"table:{slug}", out)
    return out


def _strengths_from_table(table: dict) -> dict:
    """League averages and per-club attack/defence ratios from a season table."""
    rows = list(table.values())
    n = len(rows) or 1
    avg_gf = max(sum(r["gf_avg"] for r in rows) / n, 0.4)
    avg_ga = max(sum(r["ga_avg"] for r in rows) / n, 0.4)
    out = {}
    for tid, r in table.items():
        out[tid] = {
            "played": int(r["played"]),
            "attack": _shrink(r["gf_avg"] / avg_gf, r["played"]),
            "defence": _shrink(r["ga_avg"] / avg_ga, r["played"]),
            "form": (r["wins"] * 3 + r["draws"]) / (3 * r["played"]) if r["played"] else 0.5,
            "gf_avg": r["gf_avg"],
            "ga_avg": r["ga_avg"],
            "wins": int(r["wins"]),
            "draws": int(r["draws"]),
            "losses": int(r["losses"]),
        }
    return {"matches": int(sum(r["played"] for r in rows) / 2), "avg_gf": avg_gf,
            "avg_ga": avg_ga, "table": out}


def predict(home: str, away: str, league: str = "", neutral: bool = False) -> dict:
    """Forecast one fixture. Raises ValueError with a readable reason."""
    slug, home_team, away_team = _resolve_pair(home, away, league)
    table = _standings(slug)
    if len(table) < 6:
        raise ValueError(
            f"Klasemen {league_name(slug)} belum ada — musimnya masih terlalu "
            f"awal buat prediksi."
        )
    st = _strengths_from_table(table)
    th = st["table"].get(home_team["id"])
    ta = st["table"].get(away_team["id"])
    if not th or not ta:
        raise ValueError("Salah satu klub belum punya laga di kompetisi ini.")

    # League-average goals per side, with the usual home edge, applied to the
    # two clubs' attack and defence ratios. The ratios are season totals rather
    # than home/away splits because that is what the standings endpoint gives;
    # the 1.13/0.87 split is the long-run home edge across the leagues the feed
    # covers, so it is a starting point the clubs' own numbers then move.
    avg = (st["avg_gf"] + st["avg_ga"]) / 2
    lam = avg * 1.13 * th["attack"] * ta["defence"]
    mu = avg * 0.87 * ta["attack"] * th["defence"]

    # Form is a nudge, not a rewrite. It used to be ±15% on top of ratios that
    # already include the whole season, which counted a hot streak twice; ±10%
    # and damped by games played keeps a 4-match run from overpowering 30
    # matches of evidence.
    fh = (th["form"] - 0.5) * 2 * min(1.0, th["played"] / 10.0)
    fa = (ta["form"] - 0.5) * 2 * min(1.0, ta["played"] / 10.0)
    lam *= 1 + 0.10 * fh
    mu *= 1 + 0.10 * fa
    if neutral:
        mid = (lam + mu) / 2
        lam = mu = mid

    lam, mu = min(max(lam, 0.15), 5.0), min(max(mu, 0.15), 5.0)
    grid, spread = _predictive_grid(lam, mu, th["played"], ta["played"])
    m = _market(grid)

    # Honesty about confidence: sample size, how far the clubs sit from average,
    # and how wide the win probability's own range came out. A forecast whose
    # range is 40 points wide is not a confident one, whatever the point
    # estimate says. Never a made-up "92% sure".
    sample = min(st["matches"], 150) / 150
    closeness = 1 - min(abs(m["home_win"] - m["away_win"]), 0.5) / 0.5
    band = spread["home_win_high"] - spread["home_win_low"]
    tightness = max(0.0, 1 - band / 0.35)
    confidence = 20 + 30 * sample + 20 * (1 - closeness) + 30 * tightness

    tags = []
    if m["btts_yes"] >= 0.58:
        tags.append("both teams likely to score")
    if m["over_2_5"] >= 0.6:
        tags.append("open game, over 2.5 goals likely")
    elif m["under_2_5"] >= 0.6:
        tags.append("tight game, under 2.5 goals likely")
    if m["dc_1x"] >= 0.78:
        tags.append(f"{home_team['name']} unlikely to lose")
    if m["dc_x2"] >= 0.78:
        tags.append(f"{away_team['name']} unlikely to lose")
    if abs(m["home_win"] - m["away_win"]) < 0.08:
        tags.append("very even — draw carries real weight")

    reasons = _reasons(home_team, away_team, th, ta, st, lam, mu, m)

    # Squad notes: last, because they qualify the forecast rather than build it.
    # The goals model cannot see who is suspended, so pretending otherwise
    # would overstate its precision; the note says what the record shows and
    # explicitly what the feed does not provide.
    home_squad = squad(slug, home_team["id"])
    away_squad = squad(slug, away_team["id"])
    reasons += _squad_reasons(home_team["name"], away_team["name"],
                              home_squad, away_squad)

    return {
        "league": slug,
        "league_name": league_name(slug),
        "home": {"id": home_team["id"], "name": home_team["name"],
                 "logo": home_team["logo"]},
        "away": {"id": away_team["id"], "name": away_team["name"],
                 "logo": away_team["logo"]},
        "expected_goals": {"home": round(lam, 2), "away": round(mu, 2)},
        # `expected_goals` is a count, not a percentage, so it is deliberately
        # left out of this map: running it through _pct() turned 2.9 goals per
        # match into "290%".
        "probabilities": {k: _pct(v) for k, v in m.items()
                          if isinstance(v, (int, float))
                          and k != "expected_goals"},
        "expected_goals": round(m["expected_goals"], 2),
        # All four goal lines, each with both sides. `probabilities` keeps the
        # plain numbers; this keeps the structure, because "over 2.5" alone does
        # not say what the other lines look like and an over/under answer needs
        # the line it is about.
        "over_under": {k: {"over": _pct(v["over"]), "under": _pct(v["under"])}
                       for k, v in m["over_lines"].items()},
        "top_scores": [{"score": s["score"], "prob": _pct(s["prob"])}
                       for s in m["scores"]],
        "double_chance": {"1X": _pct(m["dc_1x"]), "12": _pct(m["dc_12"]),
                          "X2": _pct(m["dc_x2"])},
        # The honest band around the headline number. A 61% home win quoted from
        # a six-game sample is not the same claim as 61% from thirty-four, and
        # without this the two look identical on the card.
        "range": {"home_win_low": _pct(spread["home_win_low"]),
                  "home_win_high": _pct(spread["home_win_high"])},
        "confidence": round(confidence, 0),
        "sample": {"matches": st["matches"],
                   "home_played": th["played"], "away_played": ta["played"]},
        "form": {
            "home": {"wins": th["wins"], "draws": th["draws"],
                     "losses": th["losses"], "gf": round(th["gf_avg"], 2),
                     "ga": round(th["ga_avg"], 2)},
            "away": {"wins": ta["wins"], "draws": ta["draws"],
                     "losses": ta["losses"], "gf": round(ta["gf_avg"], 2),
                     "ga": round(ta["ga_avg"], 2)},
        },
        "notes": tags,
        "reasons": reasons,
        # The squads travel with the forecast so the pop-out can draw its own
        # section without refetching, and so the spoken answer can cite the same
        # names the card shows.
        "squads": {
            "home": {"team": home_team["name"], **home_squad},
            "away": {"team": away_team["name"], **away_squad},
            "injuries_available": False,
        },
        "generated": datetime.now().isoformat(timespec="seconds"),
    }


def _resolve_pair(home: str, away: str, league: str):
    if league:
        lg = find_league(league)
        if not lg:
            raise ValueError(f"Liganya gak ketemu: '{league}'.")
        h, a = find_team(lg["slug"], home), find_team(lg["slug"], away)
        if h and a:
            return lg["slug"], h, a
        raise ValueError(
            f"'{home}' dan '{away}' gak ketemu dua-duanya di {lg['name']}."
        )

    # No league named: try the big ones first — that is where a real question
    # almost always lands, and it keeps the common case to a few requests.
    for slug in ("eng.1", "esp.1", "ita.1", "ger.1", "fra.1", "uefa.champions",
                 "ned.1", "por.1", "tur.1", "usa.1", "ksa.1"):
        try:
            h, a = find_team(slug, home), find_team(slug, away)
        except Exception:
            continue
        if h and a:
            return slug, h, a

    # Anything else: only leagues whose name resembles what they typed, so a
    # typo does not become 220 requests and a ten-second silence.
    probe = _fold(f"{home} {away}")
    candidates = []
    for lg in leagues():
        r = SequenceMatcher(None, probe, _fold(lg["name"])).ratio()
        if r >= 0.45 or any(tok in _fold(lg["name"]) for tok in probe.split()):
            candidates.append(lg["slug"])
    for slug in candidates[:14]:
        try:
            h, a = find_team(slug, home), find_team(slug, away)
        except Exception:
            continue
        if h and a:
            return slug, h, a
    raise ValueError(
        f"'{home}' dan '{away}' gak gue temuin di satu liga. "
        f"Coba sebutin liganya juga."
    )


# ── fixtures ─────────────────────────────────────────────────────────────────

def _scoreboard_day(slug: str, day: datetime) -> list[dict]:
    """One competition, one calendar day. The scoreboard endpoint accepts a
    single `dates=YYYYMMDD`; a range is a 400, which is why this takes a day."""
    key = f"lgday:{slug}:{day.strftime('%Y%m%d')}"
    cached = _data_take(key, _TTL_LIVE)
    if cached is not None:
        return cached
    data = _get(f"{SITE}/{slug}/scoreboard", ttl=_TTL_LIVE,
                params={"dates": day.strftime("%Y%m%d")}, store=False)
    rows: list[dict] = []
    for ev in data.get("events") or []:
        comp = (ev.get("competitions") or [{}])[0]
        state = (((comp.get("status") or {}).get("type") or {}).get("state")) or ""
        if state not in ("pre", "in"):
            continue
        try:
            when = datetime.fromisoformat(
                (ev.get("date") or "").replace("Z", "+00:00"))
        except ValueError:
            continue
        sides = {}
        for c in comp.get("competitors") or []:
            sides[c.get("homeAway")] = (c.get("team") or {}).get("displayName", "")
        if not sides.get("home") or not sides.get("away"):
            continue
        rows.append({
            "league": slug,
            "id": str(ev.get("id") or ""),
            "when": when.isoformat(timespec="minutes"),
            "home": sides["home"],
            "away": sides["away"],
            "state": state,
            "score": _live_score(comp),
        })
    if rows:
        _data_put(key, rows)
    return rows


def _norm_days(days_ahead) -> int:
    try:
        n = int(days_ahead)
    except (TypeError, ValueError):
        n = 3
    return max(0, min(30, n))


def fixtures(league: str = "", days_ahead: int = 7) -> list[dict]:
    """Upcoming matches in one competition, or across every league if blank.

    A named competition is fetched day by day. It used to ask for *today's*
    scoreboard only and then filter by `days_ahead`, so "EPL this week" always
    came back with today's fixtures and nothing else — the range was a filter
    over a set that already contained one day. One request per day is the
    price of a range that is actually a range.
    """
    days = _norm_days(days_ahead)
    start = datetime.now(timezone.utc)
    if league:
        lg = find_league(league)
        if not lg:
            raise ValueError(f"Liganya gak ketemu: '{league}'.")
        out, seen = [], set()
        for offset in range(0, days + 1):
            for row in _scoreboard_day(lg["slug"], start + timedelta(days=offset)):
                if row["id"] in seen:
                    continue
                seen.add(row["id"])
                out.append(row)
        out.sort(key=lambda f: f["when"])
        return out

    return _all_fixtures(days)


_NAME_CACHE: dict[str, str] = {}


def league_name(slug: str) -> str:
    """Human name for a slug ('eng.1' -> 'English Premier League')."""
    if not slug:
        return ""
    if slug in _NAME_CACHE:
        return _NAME_CACHE[slug]
    name = slug
    try:
        for lg in leagues():
            _NAME_CACHE[lg["slug"]] = lg["name"]
        name = _NAME_CACHE.get(slug, slug)
    except Exception:
        pass
    if name == slug and slug in _OFF_TABLE_LEAGUES:
        name = _OFF_TABLE_LEAGUES[slug][0]
        _NAME_CACHE[slug] = name
    # ESPN's own fallback: "eng.1" reads better as "ENG 1" than as a slug.
    if name == slug:
        head, _, tail = slug.partition(".")
        name = f"{head.upper()} {tail.replace('_', ' ').title()}".strip()
    return name


def _forecast_block(p: dict) -> dict:
    """predict() -> the `forecast` dict a card draws. Never re-derived anywhere."""
    return {
        "home_win": p["probabilities"]["home_win"],
        "draw": p["probabilities"]["draw"],
        "away_win": p["probabilities"]["away_win"],
        "btts": p["probabilities"]["btts_yes"],
        "over_2_5": p["probabilities"]["over_2_5"],
        "expected_goals": p["expected_goals"],
        "over_under": p["over_under"],
        # Double chance: the chance of NOT losing a two-outcome bet. The same
        # three numbers the spoken reply quotes, carried here so the pop-out
        # card does not have to re-derive them.
        "dc_1x": p["double_chance"]["1X"],
        "dc_12": p["double_chance"]["12"],
        "dc_x2": p["double_chance"]["X2"],
        "top_score": p["top_scores"][0]["score"] if p["top_scores"] else "",
        "top_score_prob": p["top_scores"][0]["prob"] if p["top_scores"] else 0,
        # The band around home_win, so a card can say "61% (55-69)" and the
        # reader can see how much the sample actually supports. Carried here
        # rather than recomputed, same as every other number on the card.
        "home_win_low": (p.get("range") or {}).get("home_win_low"),
        "home_win_high": (p.get("range") or {}).get("home_win_high"),
        "confidence": p["confidence"],
    }


def forecast_item(f: dict, with_forecast: bool = True) -> dict:
    """One fixture -> the dict FootballWindow draws.

    `with_forecast=False` is the "what is on" card: it carries no numbers, and
    the card is complete without them. A match the model cannot forecast keeps
    its slot with `forecast: None` rather than being silently dropped.
    """
    item = {
        "league": f["league"],
        "league_name": league_name(f["league"]) if f.get("league") else "Other",
        "home": f["home"],
        "away": f["away"],
        "when": f["when"],
        "state": f.get("state"),
        "score": f.get("score"),
        "forecast": None,
    }
    if with_forecast:
        try:
            item["forecast"] = _forecast_block(
                predict(f["home"], f["away"], f["league"]))
        except Exception:
            item["forecast"] = None
    return item


def slate(limit: int = 10, league: str = "", days_ahead: int = 3) -> list[dict]:
    """The next fixtures, each with a full forecast, newest first.

    This is what the pop-out window draws: at most `limit` matches (10 by
    default), each with the win/draw/win split, both-teams-to-score, the
    likeliest scoreline and the model's confidence. Matches the model cannot
    forecast (no completed season yet) are still listed, marked `forecast:
    null`, rather than dropped — a fixture that exists is never hidden.
    """
    limit = max(1, min(int(limit or 10), 10))
    if league:
        rows = fixtures(league=league, days_ahead=days_ahead)
    else:
        rows = _all_fixtures(days_ahead)

    # Prefer the competitions people follow, then continental, then the rest,
    # so ten slots show the matches someone actually means rather than the
    # first ten youth fixtures the feed happens to return.
    priority = {
        "eng.1": 0, "esp.1": 0, "ita.1": 0, "ger.1": 0, "fra.1": 0,
        "uefa.champions": 1, "uefa.europa": 1, "uefa.europa.conf": 1,
        "idn.1": 1, "ned.1": 2, "por.1": 2, "tur.1": 2, "usa.1": 2,
        "ksa.1": 2, "mex.1": 2, "bra.1": 2, "arg.1": 2, "eng.2": 3,
    }

    def rank(f: dict) -> int:
        slug = f["league"]
        if any(k in slug for k in (".w.", "u19", "u21", "u17", "qual",
                                   "reserve", "youth")):
            return 9
        return priority.get(slug, 5)

    rows.sort(key=lambda f: (rank(f), f["when"]))
    return [forecast_item(f) for f in rows[:limit]]


def slug_by_espn_id() -> dict:
    """ESPN numeric league id (700) → slug (eng.1), for naming fixtures."""
    cached = _data_take("id_map", 12 * 3600)
    if cached is not None:
        return cached
    data = _get(
        "https://site.web.api.espn.com/apis/site/v2/leagues/dropdown",
        ttl=24 * 3600, params={"lang": "en", "region": "us", "limit": 500,
                               "sport": "soccer"}, store=False,
    )
    out = {str(lg.get("id")): lg.get("slug") for lg in data.get("leagues", [])
           if lg.get("id") and lg.get("slug")}
    if out:
        _data_put("id_map", out)
    return out


# Competitions that are real football but noise in a timetable of "everything
# on this week": youth and reserve sides, US college, women's leagues (they
# are excellent and they double the list; ask for one by name to see it),
# friendlies, and qualifiers for tournaments years away. Filtering these is
# what makes "all matches" mean the matches someone would recognise.
_NOISE = (".u17", ".u18", ".u19", ".u20", ".u21", ".u23", "ncaa", ".w.",
          "youth", "reserve", "friendly", ".qual", "academy", "women")


def _is_noise(slug: str) -> bool:
    low = (slug or "").lower()
    return any(k in low for k in _NOISE)


def schedule(league: str = "", days_ahead: int = 7,
             limit: int = 1500, forecast: bool = False,
             forecast_limit: int = 20) -> list[dict]:
    """Fixtures for one competition or all of them, optionally with forecasts.

    `forecast=False` is the pure "what is on" answer and costs no model work: a
    forecast is a league table plus a Poisson grid per match, and a ten-day,
    all-competitions list is hundreds of them. That is the right shape for
    "apa aja yang main minggu ini".

    `forecast=True` is what a SCHEDULE FOR TODAY should be: the fixtures the
    user asked for, each with the numbers. It is capped by `forecast_limit`
    because a world-wide day is 250 matches and nobody reads the 250th: the
    rest keep their slot as plain fixtures rather than being hidden or guessed
    at. One competition is normally under twenty, so the cap rarely bites.
    """
    days = _norm_days(days_ahead)
    rows = fixtures(league=league, days_ahead=days) if league else _all_fixtures(days)

    # One competition asked for by name is shown exactly as asked, even if it
    # is a youth league — the filter is for "everything", where the point is
    # the recognisable competitions, not a complete census of world football.
    if not league:
        rows = [f for f in rows if not _is_noise(f.get("league", ""))]

    # Blank competitions are dropped rather than shown as "? v ?". A feed entry
    # with no league slug still has a real fixture in it, so it keeps its slot
    # but says so instead of pretending to be named.
    rows = rows[:max(1, int(limit or 1500))]
    if not forecast:
        return [forecast_item(f, with_forecast=False) for f in rows]

    # Forecast the ones someone would actually look at. A named competition is
    # already narrow, so it gets everything; "all competitions" is ranked the
    # same way slate() ranks, so the cap spends its budget on the leagues people
    # follow instead of on the first youth fixture the feed returned.
    budget = max(1, int(forecast_limit or 20))
    if league:
        chosen = set(range(len(rows)))
    else:
        priority = {
            "eng.1": 0, "esp.1": 0, "ita.1": 0, "ger.1": 0, "fra.1": 0,
            "uefa.champions": 1, "uefa.europa": 1, "uefa.europa.conf": 1,
            "idn.1": 1, "ned.1": 2, "por.1": 2, "tur.1": 2, "usa.1": 2,
            "ksa.1": 2, "mex.1": 2, "bra.1": 2, "arg.1": 2, "eng.2": 3,
        }
        order = sorted(range(len(rows)),
                       key=lambda i: (priority.get(rows[i].get("league", ""), 5),
                                      rows[i]["when"]))
        chosen = set(order[:budget])

    return [forecast_item(f, with_forecast=(i in chosen))
            for i, f in enumerate(rows)]


def _all_fixtures(days_ahead: int) -> list[dict]:
    """Every upcoming soccer match across the world, in a handful of calls.

    One request per day against ESPN's all-competitions scoreboard returns
    the whole planet (226 matches on a normal Saturday), which is far cheaper
    than one request per league and means nothing popular gets left out.
    """
    start = datetime.now(timezone.utc)
    id_map = slug_by_espn_id()
    out, seen = [], set()
    for offset in range(0, max(1, days_ahead) + 1):
        day = start + timedelta(days=offset)
        day_key = f"day:{day.strftime('%Y%m%d')}"
        day_rows = _data_take(day_key, _TTL_LIVE)
        if day_rows is not None:
            for row in day_rows:
                if row["id"] not in seen:
                    seen.add(row["id"])
                    out.append(row)
            continue
        day_rows = []
        try:
            data = _get(f"{SITE}/all/scoreboard", ttl=_TTL_LIVE,
                        params={"dates": day.strftime("%Y%m%d"), "limit": 1000},
                        store=False)
        except Exception:
            continue
        for ev in data.get("events") or []:
            comp = (ev.get("competitions") or [{}])[0]
            status = (comp.get("status") or ev.get("status") or {})
            state = ((status.get("type") or {}).get("state")) or ""
            if state not in ("pre", "in"):
                continue
            eid = str(ev.get("id") or "")
            if not eid or eid in seen:
                continue
            parts = str(ev.get("uid") or "").split("~")
            raw_id = next((p[2:] for p in parts if p.startswith("l:")), "")
            slug = id_map.get(raw_id, raw_id)
            try:
                when = datetime.fromisoformat(
                    (ev.get("date") or "").replace("Z", "+00:00"))
            except ValueError:
                continue
            sides = {}
            for c in comp.get("competitors") or []:
                sides[c.get("homeAway")] = (c.get("team") or {}).get("displayName", "")
            if not sides.get("home") or not sides.get("away"):
                continue
            row = {
                "league": slug,
                "id": eid,
                "when": when.isoformat(timespec="minutes"),
                "home": sides["home"],
                "away": sides["away"],
                "state": state,
                "score": _live_score(comp),
            }
            seen.add(eid)
            out.append(row)
            day_rows.append(row)
        if day_rows:
            _data_put(day_key, day_rows)
    out.sort(key=lambda f: f["when"])
    return out


def _live_score(comp: dict) -> Optional[str]:
    vals = {}
    for c in comp.get("competitors") or []:
        score = c.get("score")
        if isinstance(score, dict):
            score = score.get("displayValue", score.get("value"))
        if score is not None:
            vals[c.get("homeAway")] = score
    if "home" in vals and "away" in vals:
        return f"{vals['home']}-{vals['away']}"
    return None


# ── round-trip: analyse a named fixture or a whole league slate ──────────────

def analyse(home: str, away: str, league: str = "") -> str:
    """Spoken-friendly summary built from predict(). Never raises."""
    try:
        r = predict(home, away, league)
    except Exception as e:
        return f"Gagal analisa laga itu: {e}"
    p = r["probabilities"]
    rng = r.get("range") or {}
    band = ""
    if rng.get("home_win_low") is not None:
        band = (f"  (rentang {rng['home_win_low']}–{rng['home_win_high']}%)")
    lines = [
        f"{r['home']['name']} vs {r['away']['name']} ({r['league']})",
        f"Win {r['home']['name']} {p['home_win']}%{band}  ·  Draw {p['draw']}%  ·  "
        f"Win {r['away']['name']} {p['away_win']}%",
        f"Both teams score {p['btts_yes']}%  ·  Over 2.5 goals {p['over_2_5']}%  ·  "
        f"Under 2.5 {p['under_2_5']}%",
        f"Double chance — 1X {r['double_chance']['1X']}%, "
        f"12 {r['double_chance']['12']}%, X2 {r['double_chance']['X2']}%",
        f"Likeliest scores: " + ", ".join(
            f"{s['score']} ({s['prob']}%)" for s in r["top_scores"][:3]),
        f"Model confidence {int(r['confidence'])}% from "
        f"{r['sample']['matches']} completed matches.",
    ]
    if r["notes"]:
        lines.append("Read: " + "; ".join(r["notes"]) + ".")
    return "\n".join(lines)
