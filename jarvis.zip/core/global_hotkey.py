"""
core/global_hotkey.py — a hotkey that works no matter which app is in front.

WHY THIS EXISTS
    F9 (DIEM) was a Qt QShortcut. A QShortcut only fires while the MARK window
    itself has keyboard focus. The moment the user is in the browser, a game, or
    anything else — which is exactly when they want to shut the assistant up —
    F9 did nothing. It also did nothing while MARK sat as the small slab.

HOW
    Windows : RegisterHotKey on a private thread with its own message loop.
              No dependency, no keyboard hook, no admin rights, and the OS only
              wakes us for that one key (a hook would see every keystroke).
    Others  : pynput's GlobalHotKeys when it is installed; otherwise it says
              "not global" and the caller keeps its window-only shortcut.

    start() returns True only when the key is really registered system-wide,
    so the caller always knows whether it can rely on it.

THREAD NOTE
    `callback` runs on the hotkey thread. Do not touch Qt widgets from it —
    emit a signal.
"""
from __future__ import annotations

import platform
import sys
import threading
import time

_OS = platform.system()

# Windows virtual-key codes for function keys: F1 = 0x70 ... F24 = 0x87.
_VK_F = {f"F{n}": 0x6F + n for n in range(1, 25)}

_MOD_NOREPEAT = 0x4000     # holding the key must not fire a stream of toggles
_WM_HOTKEY    = 0x0312
_WM_QUIT      = 0x0012


class GlobalHotkey:
    """One system-wide key (default F9) that calls `callback()` when pressed."""

    def __init__(self, callback, key: str = "F9", logger=None):
        self._callback = callback
        self._key = key.upper()
        self._log = logger or (lambda m: None)
        self._thread: threading.Thread | None = None
        self._thread_id = 0
        self._pynput = None
        self.active = False

    # ── public ────────────────────────────────────────────────────────────
    def start(self) -> bool:
        if self.active:
            return True
        try:
            if _OS == "Windows":
                return self._start_windows()
            return self._start_pynput()
        except Exception as e:                                   # noqa: BLE001
            self._log(f"global hotkey unavailable: {e}")
            self.active = False
            return False

    def stop(self) -> None:
        self.active = False
        if _OS == "Windows" and self._thread_id:
            try:
                import ctypes
                ctypes.windll.user32.PostThreadMessageW(self._thread_id, _WM_QUIT, 0, 0)
            except Exception:
                pass
            self._thread_id = 0
        if self._pynput is not None:
            try:
                self._pynput.stop()
            except Exception:
                pass
            self._pynput = None

    # ── Windows ───────────────────────────────────────────────────────────
    def _start_windows(self) -> bool:
        vk = _VK_F.get(self._key)
        if vk is None:
            raise ValueError(f"unsupported key {self._key!r}")

        ready = threading.Event()
        result = {"ok": False, "err": ""}

        def loop():
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            self._thread_id = kernel32.GetCurrentThreadId()
            hk_id = 0x4D39          # arbitrary, private to this thread
            if not user32.RegisterHotKey(None, hk_id, _MOD_NOREPEAT, vk):
                result["err"] = (f"{self._key} is already taken by another "
                                 f"program (error {kernel32.GetLastError()})")
                ready.set()
                return
            result["ok"] = True
            ready.set()
            msg = wintypes.MSG()
            try:
                while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                    if msg.message == _WM_HOTKEY and msg.wParam == hk_id:
                        try:
                            self._callback()
                        except Exception as e:                   # noqa: BLE001
                            self._log(f"hotkey callback failed: {e}")
            finally:
                user32.UnregisterHotKey(None, hk_id)

        self._thread = threading.Thread(target=loop, daemon=True, name="global-hotkey")
        self._thread.start()
        ready.wait(3.0)
        self.active = bool(result["ok"])
        if not self.active:
            self._log(result["err"] or "could not register the hotkey")
        return self.active

    # ── Linux / macOS ─────────────────────────────────────────────────────
    def _start_pynput(self) -> bool:
        from pynput import keyboard            # optional dependency
        self._pynput = keyboard.GlobalHotKeys(
            {f"<{self._key.lower()}>": self._callback})
        self._pynput.daemon = True
        self._pynput.start()
        time.sleep(0.2)
        self.active = bool(self._pynput.is_alive())
        return self.active
