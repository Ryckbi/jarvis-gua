"""
actions/cpu_temp.py — "berapa suhu CPU gue?" answered in one step.

`system_status` already reports cpu_temp_c, but it answers a dozen questions at
once (RAM, GPU, uptime, processes), and the temperature it carries comes from
the HUD's 2-second poll — up to six seconds stale because the HUD refreshes the
expensive probes every third cycle. Asked to show the temperature, that delay is
the whole answer to the user: they asked for now.

So this tool does the narrow thing: one fresh probe, one number, plus the fan
speed when the platform exposes it (Windows usually does not).

HONESTY RULE, straight from AGENTS.md and from the mission this was built for:
never invent a sensor reading. Most Windows machines do not expose CPU
temperature to user-space software without a vendor driver, and this says so
plainly instead of showing a plausible number. A fan speed that cannot be read
is reported as unavailable, not as 0 RPM.
"""
from __future__ import annotations

import threading

from core import outcome

_RECENT = {"temp": -1.0, "at": 0.0}
_LOCK = threading.Lock()


def _fresh_temp() -> tuple[float, str, bool]:
    """One real probe: (temp_c, source, confident). -1.0 when nothing answered.

    core/sensors is the single probe for the whole app, so asking it here is
    the same read the HUD paints — and it can succeed on a machine where the
    old one-zone WMI attempt had already given up for the session.
    """
    try:
        from core import sensors
        return sensors.cpu_temp()
    except Exception:
        return -1.0, "", False


def _fan_speed() -> float:
    """Fan RPM when the platform exposes it. -1.0 when it does not."""
    try:
        from core import sensors
        speeds = sensors.fan_rpms()
        return float(max(speeds)) if speeds else -1.0
    except Exception:
        return -1.0


def _verdict(temp: float) -> str:
    """A read on the number, in the plainest terms that are true."""
    if temp < 0:
        return "unavailable"
    if temp >= 90:
        return "critical"
    if temp >= 80:
        return "hot"
    if temp >= 65:
        return "warm"
    return "normal"


def run(parameters: dict | None = None, player=None, response=None,
        session_memory=None) -> str:
    params = parameters or {}
    want_fan = str(params.get("detail") or "").lower() in ("fan", "fans", "all", "full")

    temp, source, confident = _fresh_temp()
    fan = _fan_speed() if want_fan else -1.0

    if temp < 0:
        # Named causes, because "unavailable" gives the user nothing to do.
        msg = ("Suhu CPU-nya belum kebaca. Kemungkinan besar karena Windows "
               "atau macOS gak ngekspos sensor suhu ke aplikasi biasa tanpa "
               "bantuan. Kalau mau dipaksa kebaca, install LibreHardwareMonitor "
               "dan biarin jalan di background — nanti gue baca dari situ. "
               "Gue gak mau ngarang angka.")
        if player:
            try:
                player.write_log(f"JARVIS: {msg}")
            except Exception:
                pass
        return outcome.failed("cpu_temp", msg)

    used = round(temp, 1)
    verdict = _verdict(temp)

    if player:
        try:
            player.write_log(f"SYS: CPU {used}°C ({verdict})")
        except Exception:
            pass

    return outcome.done(
        "cpu_temp",
        temp_c=used,
        verdict=verdict,
        source=source,
        approximate=None if confident else True,
        fan_rpm=round(fan) if fan > 0 else None,
    )


TOOL = {
    "name": "cpu_temp",
    "description": (
        "Reads the CPU temperature RIGHT NOW and returns it in one step. Use "
        "this — not system_status — when the user asks the temperature, heat, "
        "or whether the processor is running hot (in any language: 'suhu CPU', "
        "'berapa derajat', 'is my CPU hot', 'cek suhu'). It probes live rather "
        "than reading the HUD's last painted value, and adds fan speed when "
        "the platform exposes it. If the sensor cannot be read it says so; it "
        "never guesses a number."
    ),
    "brief": "Current CPU temperature (°C), probed live.",
    "handler": run,
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "detail": {
                "type": "STRING",
                "description": "'temp' (default) for the temperature alone, "
                               "'fan' to include fan RPM when available.",
            },
        },
        "required": [],
    },
}
