"""
gui/football_window.py — the match-forecast pop-out.

A separate top-level window (not an overlay), because the point of it is to
sit beside the game: borderless, draggable, always on top, and small enough to
leave a corner of the screen. It shows the next ten fixtures across every
competition ESPN covers, each with the model's win/draw/win split, both teams
to score, over 2.5 and the likeliest scoreline.

Two rules from AGENTS.md are load-bearing here:

  * widgets are created and touched on the Qt main thread only. The data comes
    from a background thread, so `MainWindow` owns a signal and the worker just
    emits; see gui/window.py.
  * no new dependency. Everything below is PyQt6 and standard library — the
    cards are painted widgets rather than a web view, which keeps the window
    light enough to leave open while something else is being played.

The window refreshes itself on a timer, but only while it is visible, so a
closed pop-out costs nothing.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from PyQt6.QtCore import QPoint, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QMouseEvent
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QScrollArea, QSizePolicy,
    QVBoxLayout, QWidget,
)

from gui.style import hud_font
from gui.theme import C

_MAX_ROWS = 10                # forecast mode: ten cards, each with a model
_MAX_SCHEDULE = 1500          # schedule mode: "every match in ten days"
_REFRESH_MS = 90_000          # fixtures change slowly; 90s is plenty


class _ProbBar(QWidget):
    """One horizontal 100% bar: home / draw / away, coloured, labelled."""

    def __init__(self, home: float, draw: float, away: float, parent=None):
        super().__init__(parent)
        self._v = (home, draw, away)
        self.setFixedHeight(6)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def paintEvent(self, _e):
        from PyQt6.QtGui import QColor, QPainter
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        hw, dr, aw = self._v
        x = 0.0
        for frac, col in ((hw, C.PRI), (dr, C.BORDER_B), (aw, C.GREEN)):
            seg = w * max(frac, 0.0) / 100.0
            if seg > 0:
                p.fillRect(int(x), 0, max(int(seg), 1), h, QColor(col))
            x += seg
        p.end()


class _MatchCard(QFrame):
    """One fixture: league + kick-off, teams, the three-way split, markets."""

    def __init__(self, item: dict, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.setStyleSheet(
            f"#card {{ background: {C.PANEL}; border: 1px solid {C.BORDER}; "
            f"border-top: 1px solid {C.BORDER_A}; }}"
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(11, 8, 11, 9)
        lay.setSpacing(5)

        # ── header: league · time ────────────────────────────────────────────
        top = QHBoxLayout()
        top.setSpacing(6)
        lg = QLabel(str(item.get("league_name") or item.get("league") or ""))
        lg.setFont(hud_font(7, QFont.Weight.Bold))
        lg.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent; "
                         f"letter-spacing: 1px;")
        top.addWidget(lg)
        top.addStretch(1)
        when = QLabel(_pretty_when(item.get("when", "")))
        when.setFont(hud_font(7))
        when.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent;")
        top.addWidget(when)
        if item.get("state") == "in":
            live = QLabel(f"● LIVE {item.get('score') or ''}".strip())
            live.setFont(hud_font(7, QFont.Weight.Bold))
            live.setStyleSheet(f"color: {C.ACC}; background: transparent;")
            top.addWidget(live)
        lay.addLayout(top)

        # ── teams ────────────────────────────────────────────────────────────
        row = QHBoxLayout()
        row.setSpacing(4)
        h_lbl = QLabel(item.get("home", ""))
        h_lbl.setFont(hud_font(10, QFont.Weight.Bold))
        h_lbl.setStyleSheet(f"color: {C.TEXT}; background: transparent;")
        h_lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        row.addWidget(h_lbl, 1)
        vs = QLabel("v")
        vs.setFont(hud_font(7))
        vs.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent;")
        row.addWidget(vs, 0, Qt.AlignmentFlag.AlignCenter)
        a_lbl = QLabel(item.get("away", ""))
        a_lbl.setFont(hud_font(10, QFont.Weight.Bold))
        a_lbl.setStyleSheet(f"color: {C.TEXT}; background: transparent;")
        a_lbl.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        row.addWidget(a_lbl, 1)
        lay.addLayout(row)

        fc = item.get("forecast")
        if not fc:
            # A schedule is a list of what is on, not a set of predictions: a
            # card without numbers is complete, so it says nothing about them.
            # A forecast window that lost one match still has to explain why.
            if not item.get("plain"):
                na = QLabel("No forecast — not enough of this season has been played")
                na.setFont(hud_font(7))
                na.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent;")
                na.setWordWrap(True)
                lay.addWidget(na)
            return

        # ── three-way split ──────────────────────────────────────────────────
        split = QHBoxLayout()
        split.setSpacing(4)
        for label, val, col in (
            ("1", fc["home_win"], C.PRI),
            ("X", fc["draw"], C.TEXT_MED),
            ("2", fc["away_win"], C.GREEN),
        ):
            lab = QLabel(f"{label} {val:.0f}%")
            lab.setFont(hud_font(9, QFont.Weight.Bold))
            lab.setStyleSheet(f"color: {col}; background: transparent;")
            split.addWidget(lab, 1)
            if label == "1":
                split.setStretch(0, 2)
        lay.addLayout(split)
        lay.addWidget(_ProbBar(fc["home_win"], fc["draw"], fc["away_win"]))

        # ── double chance ────────────────────────────────────────────────────
        # The pick that does not need a single result: 1X, X2 or 12. Shown as
        # three numbers with the safest one lifted, because the whole point of
        # a double chance is picking the two outcomes that cover the match.
        dc = {"1X": fc.get("dc_1x"), "X2": fc.get("dc_x2"), "12": fc.get("dc_12")}
        if all(isinstance(v, (int, float)) for v in dc.values()):
            best = max(dc, key=lambda k: dc[k])
            row_dc = QHBoxLayout()
            row_dc.setSpacing(4)
            tag = QLabel("DOUBLE CHANCE")
            tag.setFont(hud_font(6, QFont.Weight.Bold))
            tag.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent; "
                              f"letter-spacing: 1px;")
            row_dc.addWidget(tag)
            row_dc.addStretch(1)
            for k in ("1X", "X2", "12"):
                chip = QLabel(f"{k} {dc[k]:.0f}%")
                hot = (k == best)
                chip.setFont(hud_font(8, QFont.Weight.Bold))
                chip.setStyleSheet(
                    f"color: {C.ACC if hot else C.TEXT_MED}; "
                    f"background: transparent;")
                chip.setToolTip(_dc_meaning(k, item.get("home", ""), item.get("away", "")))
                row_dc.addWidget(chip)
            lay.addLayout(row_dc)

        # ── over / under ─────────────────────────────────────────────────────
        # Every goal line, over and under, with the one closest to a coin flip
        # lifted. A single "O2.5 50%" is not an answer: the line is half the
        # question, and the shape across lines is what says whether the game is
        # expected to be tight or open.
        ou = fc.get("over_under") or {}
        if ou:
            tag_ou = QLabel("OVER / UNDER")
            tag_ou.setFont(hud_font(6, QFont.Weight.Bold))
            tag_ou.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent; "
                                 f"letter-spacing: 1px;")
            lay.addWidget(tag_ou)
            try:
                lines = {k: float(v.get("over", 0)) for k, v in ou.items()}
            except Exception:
                lines = {}
            if lines:
                near = min(lines, key=lambda k: abs(lines[k] - 50))
                row_ou = QHBoxLayout()
                row_ou.setSpacing(4)
                for k in sorted(lines, key=lambda x: float(x)):
                    over = lines[k] >= 50
                    val = lines[k] if over else 100 - lines[k]
                    lab = QLabel(f"{'O' if over else 'U'}{k} {val:.0f}%")
                    hot = (k == near)
                    lab.setFont(hud_font(8, QFont.Weight.Bold if hot else QFont.Weight.Normal))
                    lab.setStyleSheet(
                        f"color: {C.ACC if hot else C.TEXT_MED}; "
                        f"background: transparent;")
                    lab.setToolTip(
                        f"Over {k}: {lines[k]:.0f}%  ·  Under {k}: "
                        f"{100 - lines[k]:.0f}%"
                        + ("  — paling deket 50-50" if hot else ""))
                    row_ou.addWidget(lab, 1)
                lay.addLayout(row_ou)

        xg = fc.get("expected_goals")
        # ── markets ──────────────────────────────────────────────────────────
        m = QLabel(
            f"BTTS {fc['btts']:.0f}%   ·   "
            + (f"xG {xg:.1f}   ·   " if isinstance(xg, (int, float)) else "")
            + f"Score {fc['top_score']} ({fc['top_score_prob']:.0f}%)   ·   "
            f"conf {fc['confidence']:.0f}%"
        )
        m.setFont(hud_font(7))
        m.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent;")
        m.setWordWrap(True)
        lay.addWidget(m)

        # ── squad ────────────────────────────────────────────────────────────
        # Who is on the pitch, who is close to a ban, and — stated, not hidden —
        # that this feed does not carry injuries. A blank where a reader expects
        # an injury list reads as "nobody is injured", which would be a claim
        # the data cannot support.
        squads = item.get("squads") or {}
        if squads.get("home") or squads.get("away"):
            tag_sq = QLabel("PEMAIN & KARTU")
            tag_sq.setFont(hud_font(6, QFont.Weight.Bold))
            tag_sq.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent; "
                                 f"letter-spacing: 1px; padding-top: 2px;")
            lay.addWidget(tag_sq)
            for side in ("home", "away"):
                sq = squads.get(side) or {}
                if not sq.get("available"):
                    continue
                bits = []
                top = sq.get("top_scorer")
                if top and top.get("goals"):
                    bits.append(f"{top['name']} {top['goals']}G"
                                + (f" {top['assists']}A" if top.get("assists") else ""))
                if sq.get("reds"):
                    r = sq["reds"][0]
                    bits.append(f"{r['name']} 🟥{r['red']}")
                if sq.get("one_from_ban"):
                    b = sq["one_from_ban"][0]
                    bits.append(f"{b['name']} ⚠ {b['yellow']} kartu")
                elif sq.get("booked"):
                    b = sq["booked"][0]
                    bits.append(f"{b['name']} {b['yellow']} kartu")
                if not bits:
                    continue
                line = QLabel(f"{sq.get('team', '')}: " + "  ·  ".join(bits))
                line.setWordWrap(True)
                line.setFont(hud_font(7))
                line.setStyleSheet(f"color: {C.TEXT_MED}; background: transparent;")
                line.setToolTip("Data cedera tidak tersedia dari sumber ini. "
                                "Yang ditampilkan: gol, assist, dan kartu musim ini.")
                lay.addWidget(line)
            if not squads.get("injuries_available", False):
                noinj = QLabel("Status cedera tidak ada di feed ini — angka di atas "
                               "soal kartu dan pemakaian, bukan kebugaran.")
                noinj.setWordWrap(True)
                noinj.setFont(hud_font(6))
                noinj.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent;")
                lay.addWidget(noinj)

        # ── why ──────────────────────────────────────────────────────────────
        # The numbers alone invite "where did this come from?". These lines are
        # the same figures the forecast was computed from, written out — see
        # core/football.py _reasons(). Shown expanded on a single-match card
        # and collapsed to a count when ten fixtures share the window (there is
        # no tap gesture in this window, so the hint says how to get the detail
        # rather than promising a gesture that does not exist).
        # Squad notes are drawn above as their own section; repeating them under
        # KENAPA GITU would show the same sentence twice in one card.
        reasons = [x for x in (item.get("reasons") or [])
                   if x.get("kind") != "squad"]
        if reasons:
            if item.get("expanded"):
                head = QLabel("KENAPA GITU")
                head.setFont(hud_font(6, QFont.Weight.Bold))
                head.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent; "
                                   f"letter-spacing: 1px; padding-top: 2px;")
                lay.addWidget(head)
                for r in reasons[:8]:
                    line = QLabel(f"▸ {r.get('title', '')} — {r.get('detail', '')}")
                    line.setWordWrap(True)
                    line.setFont(hud_font(7))
                    line.setStyleSheet(f"color: {C.TEXT_MED}; background: transparent;")
                    lay.addWidget(line)
            else:
                hint = QLabel(f"{len(reasons)} alasan — minta analisa satu laga buat lihat detail")
                hint.setFont(hud_font(6))
                hint.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent;")
                lay.addWidget(hint)


class _ScheduleRow(QFrame):
    """One fixture in a timetable: competition, kick-off, the two teams.

    Deliberately not a _MatchCard. A ten-day, all-competitions timetable is
    around a thousand matches; a card carries a probability bar, a double
    chance row and reason lines, so a thousand of them is tens of thousands of
    widgets for a list nobody reads in full. Three labels and a line is the
    right weight, and it makes the day headings do the grouping work.
    """

    def __init__(self, item: dict, parent=None):
        super().__init__(parent)
        self.setObjectName("sched")
        self.setStyleSheet(
            f"#sched {{ background: transparent; "
            f"border-bottom: 1px solid {C.BORDER}; }}")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(2, 3, 2, 3)
        lay.setSpacing(7)

        when = _pretty_when(item.get("when", ""))
        # "today 20:00" → "20:00", because the day heading already said today.
        clock = when.rsplit(" ", 1)[-1] if ":" in when else when
        t = QLabel(clock)
        t.setFont(hud_font(8, QFont.Weight.Bold))
        t.setStyleSheet(f"color: {C.TEXT_MED}; background: transparent;")
        t.setFixedWidth(38)
        lay.addWidget(t, 0, Qt.AlignmentFlag.AlignTop)

        mid = QVBoxLayout()
        mid.setSpacing(0)
        teams = QLabel(f"{item.get('home', '')} v {item.get('away', '')}")
        teams.setFont(hud_font(8))
        teams.setStyleSheet(f"color: {C.TEXT}; background: transparent;")
        teams.setWordWrap(True)
        mid.addWidget(teams)
        comp = QLabel(str(item.get("league_name") or item.get("league") or ""))
        comp.setFont(hud_font(6))
        comp.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent; "
                           f"letter-spacing: 0.5px;")
        mid.addWidget(comp)
        lay.addLayout(mid, 1)

        if item.get("state") == "in":
            live = QLabel(f"● {item.get('score') or ''}".strip())
            live.setFont(hud_font(7, QFont.Weight.Bold))
            live.setStyleSheet(f"color: {C.ACC}; background: transparent;")
            lay.addWidget(live, 0, Qt.AlignmentFlag.AlignTop)


def _dc_meaning(key: str, home: str, away: str) -> str:
    """What a double-chance key actually covers, in words.

    "1X 74%" means nothing on its own if you do not already know the notation,
    so every chip says which two results are covered and whose they are.
    """
    home = home or "home"
    away = away or "away"
    return {
        "1X": f"{home} menang atau seri",
        "X2": f"seri atau {away} menang",
        "12": f"{home} atau {away} menang (tidak seri)",
    }.get(key, key)


def _day_label(day_iso: str) -> str:
    """'2026-11-21' → 'SAT 21 NOV', with today and tomorrow spelled out."""
    try:
        d = datetime.fromisoformat(day_iso).astimezone()
    except Exception:
        return day_iso
    today = datetime.now().astimezone().date()
    delta = (d.date() - today).days
    if delta == 0:
        return "TODAY"
    if delta == 1:
        return "TOMORROW"
    return d.strftime("%a %d %b").upper()


def _pretty_when(iso: str) -> str:
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        local = dt.astimezone()
        today = datetime.now().astimezone().date()
        day = local.date()
        prefix = ("today" if day == today else
                  "tomorrow" if (day - today).days == 1 else
                  local.strftime("%a"))
        return f"{prefix} {local.strftime('%H:%M')}"
    except Exception:
        return iso[:16]


class FootballWindow(QWidget):
    """Borderless, always-on-top scoreboard of the next ten fixtures."""

    closed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.Window
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
        )
        self.setWindowTitle("MARK — MATCH FORECAST")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setMinimumSize(340, 320)
        self.resize(380, 560)
        self.setStyleSheet(
            f"FootballWindow {{ background: {C.BG}; }}"
        )
        self._drag: Optional[QPoint] = None
        self._loading = False
        self._pending = None          # rows still to be drawn, see _drain_pending
        self._pending_i = 0
        self._pending_plain = False

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── title bar (this is the drag handle) ─────────────────────────────
        bar = QWidget()
        bar.setFixedHeight(34)
        bar.setStyleSheet(
            f"background: {C.PANEL2}; border-bottom: 1px solid {C.BORDER};"
        )
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(11, 0, 6, 0)
        bl.setSpacing(6)
        self._title = QLabel("◈  MATCH FORECAST")
        self._title.setFont(hud_font(8, QFont.Weight.Bold))
        self._title.setStyleSheet(f"color: {C.PRI}; background: transparent; "
                                  f"letter-spacing: 2px;")
        bl.addWidget(self._title)
        bl.addStretch(1)
        self._status = QLabel("")
        self._status.setFont(hud_font(7))
        self._status.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent;")
        bl.addWidget(self._status)
        self._refresh_btn = self._tiny_button("⟳", "Refresh now")
        self._refresh_btn.clicked.connect(lambda: self.request_refresh())
        bl.addWidget(self._refresh_btn)
        close = self._tiny_button("✕", "Close")
        close.clicked.connect(self.close)
        bl.addWidget(close)
        root.addWidget(bar)

        # ── scrollable list ─────────────────────────────────────────────────
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._scroll.setStyleSheet(
            f"QScrollArea {{ background: {C.BG}; border: none; }}"
            f"QScrollBar:vertical {{ background: transparent; width: 6px; "
            f"border: none; }}"
            f"QScrollBar::handle:vertical {{ background: {C.BORDER_B}; "
            f"min-height: 20px; }}"
            f"QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical "
            f"{{ height: 0; }}"
        )
        holder = QWidget()
        holder.setStyleSheet(f"background: {C.BG};")
        self._list = QVBoxLayout(holder)
        self._list.setContentsMargins(9, 9, 9, 9)
        self._list.setSpacing(7)
        self._list.addStretch(1)
        self._scroll.setWidget(holder)
        root.addWidget(self._scroll, 1)

        foot = QLabel("Model estimate from this season's results — not betting advice.")
        foot.setFont(hud_font(6))
        foot.setStyleSheet(
            f"color: {C.TEXT_DIM}; background: {C.PANEL2}; "
            f"border-top: 1px solid {C.BORDER}; padding: 5px 11px;"
        )
        root.addWidget(foot)

        # Data arrives on a worker thread; the owner of this window connects
        # `refresh_requested` and calls show_matches() on the Qt thread.
        self.refresh_requested = None        # set by MainWindow
        # A card is a snapshot of one match. The board self-refreshes because a
        # schedule goes stale; an analysis does not, and rebuilding it under a
        # reader every 45 seconds is a redraw, not an update.
        self.refresh_fn = None               # callable: () -> None
        # Which slot this window was opened for, so a timed refresh reloads
        # into THIS window instead of the shared board. Set by MainWindow.
        self.slot_key = None
        # Periodic refresh, on by default because a board is a live scoreboard.
        self._auto = True

        self._timer = QTimer(self)
        self._timer.timeout.connect(lambda: self.request_refresh())
        self._timer.start(_REFRESH_MS)

    # ── window chrome ────────────────────────────────────────────────────────

    def _tiny_button(self, text: str, tip: str) -> QPushButton:
        b = QPushButton(text)
        b.setToolTip(tip)
        b.setFixedSize(22, 22)
        b.setFont(hud_font(8, QFont.Weight.Bold))
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setStyleSheet(
            f"QPushButton {{ background: transparent; color: {C.TEXT_MED}; "
            f"border: none; }}"
            f"QPushButton:hover {{ color: {C.PRI}; }}"
        )
        return b

    def mousePressEvent(self, e: QMouseEvent):
        if e.button() == Qt.MouseButton.LeftButton and e.position().y() <= 34:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e: QMouseEvent):
        if self._drag is not None and e.buttons() & Qt.MouseButton.LeftButton:
            self.move(e.globalPosition().toPoint() - self._drag)
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e: QMouseEvent):
        self._drag = None
        super().mouseReleaseEvent(e)

    def closeEvent(self, e):
        self._timer.stop()
        self.closed.emit()
        super().closeEvent(e)

    def showEvent(self, e):
        super().showEvent(e)
        if getattr(self, "_auto", True) and not self._timer.isActive():
            self._timer.start(_REFRESH_MS)

    def set_autorefresh(self, on: bool) -> None:
        """Turn the periodic refresh on or off for this window alone."""
        self._auto = bool(on)
        if on:
            if not self._timer.isActive():
                self._timer.start(_REFRESH_MS)
        else:
            self._timer.stop()

    # ── data ─────────────────────────────────────────────────────────────────

    def request_refresh(self) -> None:
        """Ask the owner to fetch on a worker thread. Safe to call any time."""
        if self._loading:
            return
        cb = getattr(self, "refresh_requested", None)
        if not callable(cb):
            return
        # A window with no fetcher of its own (an analysis card) must not ask
        # the board's callback to run — that would fill THIS window with ten
        # unrelated fixtures.
        if getattr(self, "refresh_fn", None) is None and not getattr(self, "_auto", True):
            return
        self._loading = True
        self._status.setText("loading…")
        try:
            cb()
        except Exception:
            self._loading = False

    def _day_head(self, day_iso: str, items: list) -> QLabel:
        """Day divider: 'SAT 21 NOV — 189 matches'. The count matters because
        the only way to know a list is complete is to see how the days split."""
        n = sum(1 for it in items if str(it.get("when", ""))[:10] == day_iso)
        head = QLabel(f"{_day_label(day_iso)}   —   {n} matches")
        head.setFont(hud_font(7, QFont.Weight.Bold))
        head.setStyleSheet(
            f"color: {C.TEXT_DIM}; background: {C.PANEL2}; "
            f"letter-spacing: 1px; padding: 4px 2px; "
            f"border-top: 1px solid {C.BORDER};")
        return head

    def show_matches(self, items: list, note: str = "", expanded: bool = False,
                     mode: str = "forecast") -> None:
        """Draw the fixtures. Called on the Qt main thread only.

        Two shapes share this window because they are the same thing read at
        two depths: a forecast board of ten matches with model numbers, and a
        schedule of everything in a date range with no numbers at all. Drawing
        a hundred Poisson forecasts to answer "what is on this week" would be
        minutes of work for a question nobody asked, so schedule mode is
        fixtures only — and the window can therefore hold more than ten.
        """
        self._loading = False
        # A refresh can arrive mid-draw. Cancel the old queue first: otherwise
        # a queued _drain_pending appends the previous list into the new one.
        self._pending = None
        self._pending_i = 0
        plain = (mode == "schedule")
        cap = _MAX_SCHEDULE if plain else _MAX_ROWS
        items = list(items or [])[:cap]
        if plain:
            items = [{**it, "plain": True} for it in items]
            has_fc = any(it.get("forecast") for it in items)
            self._title.setText("◈  FIXTURES + FORECAST" if has_fc
                                else "◈  FIXTURES")
            self.setMinimumSize(380, 320)
        else:
            self._title.setText("◈  MATCH FORECAST")
        if expanded:
            items = [{**it, "expanded": True} for it in items]
        while self._list.count():
            it = self._list.takeAt(0)
            w = it.widget()
            if w is not None:
                w.deleteLater()
        if not items:
            empty = QLabel(note or "No upcoming fixtures found.")
            empty.setWordWrap(True)
            empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
            empty.setFont(hud_font(8))
            empty.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent; "
                                f"padding: 30px 12px;")
            self._list.addWidget(empty)
            self._list.addStretch(1)
            self._status.setText("")
            return

        if expanded and len(items) == 1:
            # One match is an analysis, not a scoreboard: it needs the room.
            self.setMinimumSize(400, 420)
            self.resize(440, 640)
        stamp = datetime.now().strftime("%H:%M")
        self._status.setText(f"{len(items)} matches · {stamp}")

        # A ten-day, all-competitions timetable is ~500 rows, and building 500
        # widgets in one go froze the window for most of a second — the window
        # appeared only after the work was done. Draw a screenful, then keep
        # going across idle turns so the first thing the user sees is already
        # the list.
        self._pending = items
        self._pending_i = 0
        self._pending_plain = plain
        self._list.addStretch(1)
        self._drain_pending()

    def _drain_pending(self) -> None:
        """Add the next chunk of rows, then yield to Qt. Called by a timer."""
        if not getattr(self, "_pending", None):
            return
        items = self._pending
        heavy = (not self._pending_plain) or bool(
            any(it.get("forecast") for it in items))
        chunk = 6 if heavy else 12
        end = min(self._pending_i + chunk, len(items))
        # Insert before the trailing stretch so the list never grows past it.
        stretch_at = max(0, self._list.count() - 1)
        last_day = None
        for it in items[max(0, self._pending_i - 1):self._pending_i]:
            last_day = str(it.get("when", ""))[:10]
        for item in items[self._pending_i:end]:
            if self._pending_plain:
                day = str(item.get("when", ""))[:10]
                if day and day != last_day:
                    last_day = day
                    self._list.insertWidget(
                        stretch_at, self._day_head(day, items))
                    stretch_at += 1
                if item.get("forecast"):
                    # A schedule row is deliberately three labels. Once the
                    # fixture carries numbers, three labels is the wrong shape:
                    # the user asked for today's matches AND the analysis, so
                    # draw the same card a forecast board draws.
                    self._list.insertWidget(stretch_at, _MatchCard(item))
                else:
                    self._list.insertWidget(stretch_at, _ScheduleRow(item))
            else:
                self._list.insertWidget(stretch_at, _MatchCard(item))
            stretch_at += 1
        self._pending_i = end
        if end >= len(items):
            self._pending = None
            return
        QTimer.singleShot(0, self._drain_pending)
