"""
core/sensors.py — CPU temperature, read the same way everywhere.

WHY THIS FILE EXISTS
    Temperature was read in three places (the HUD sampler, the system_status
    tool, and the alert monitor), each with its own copy of the same probe,
    and each with the same three faults:

    1. IT GAVE UP FOREVER. The WMI path set `_wmi_ok = False` on its first
       exception and never tried again. A machine that was simply busy during
       startup — or whose ACPI service had not started yet — reported "sensor
       unavailable" for the rest of the session. That is why the temperature
       stayed blank even when the hardware could report it.

    2. ONE METHOD PER PLATFORM. On Windows it tried psutil, then WMI. Many
       laptops expose the value through neither but do through a vendor
       interface (Lenovo, Dell), through OpenHardwareMonitor/LibreHardwareMonitor
       running locally, or through a Linux-style sysfs path on a non-Linux OS
       is not a thing — but the ACPI thermal zone almost always is, and the
       old code only asked for one entry of it.

    3. NOBODY SAID WHICH METHOD WORKED. So a wrong number (an ACPI zone that
       reports 27.8°C forever, a "temp1" that is really the chipset) could not
       be told apart from a right one.

    This module is the single probe. It tries the paths in order of quality,
    remembers the one that answered (and its name), retries after a cooldown
    instead of giving up, and reports a confidence with the number. Callers
    get (temp_c, source, confident); -1.0 means genuinely unknown.

WHAT IT DELIBERATELY DOES NOT DO
    No subprocess, no `wmic`, no PowerShell. A temperature read every two
    seconds cannot afford to spawn a process, and on a busy machine that is
    the difference between the HUD being cheap and being part of the problem.
"""
from __future__ import annotations

import os
import platform
import sys
import threading
import time
from pathlib import Path

_OS = platform.system()

# A failed method is retried, not written off. 30 s is short enough that a
# service which was not ready at launch is picked up while the user is still
# wondering, and long enough that a permanently absent sensor costs nothing.
_RETRY_AFTER = 30.0

# ACPI thermal zones that report a dead-flat value are not the CPU. 27.8 °C
# under load is the classic one; anything this stable and this cool is treated
# as uninformative rather than reported as a reading.
_SUSPECT_BELOW = 20.0

_lock = threading.Lock()
_state: dict = {
    "source": "",            # which method last answered
    "temp": -1.0,
    "at": 0.0,
    "cooldown": {},          # method -> monotonic time before which it is skipped
    "zone_index": None,      # ACPI zone that looked like the CPU
    "wmi": None,             # cached WMI connection
    "last_cpu": -1.0,        # last real reading, for the flat-value check
    "confident": True,       # confidence of the memoised reading
}

# psutil sensor bundle names that ARE the CPU, best first. `acpitz` is last
# because on many boards it is the chassis, not the cores.
_PSUTIL_CPU = ("coretemp", "k10temp", "zenpower", "cpu_thermal", "cpu-thermal",
               "it8688", "it87", "nct6775", "acpitz")

# Linux hwmon drivers in the order a real CPU would answer.
_HWMON_CPU = ("coretemp", "k10temp", "zenpower", "cpu_thermal", "it87", "nct6775")


def _usable(temp: float) -> bool:
    """Is this a temperature a CPU could plausibly be at?"""
    return 5.0 <= float(temp) <= 125.0


def _flat_suspect(temp: float) -> bool:
    """A report that never moves and sits near room temperature is a zone, not a core."""
    last = _state.get("last_cpu", -1.0)
    if temp < _SUSPECT_BELOW and last >= 0 and abs(temp - last) < 0.05:
        return True
    return False


def _skip(method: str) -> bool:
    return _state["cooldown"].get(method, 0.0) > time.monotonic()


def _failed(method: str, error: BaseException | None = None) -> None:
    """Record a failure — and how long to wait before asking this method again.

    NOT EVERY FAILURE MEANS "THIS MACHINE HAS NO SENSOR". Two are told apart:

      - LookupError  : the method ran fine and found nothing. The sensor may
                       still appear later (a driver loading, a hardware-monitor
                       app starting), so this is a short wait.
      - anything else: the interface itself broke (no module, permission, COM
                       error). That deserves the full cooldown.

    Both used to get 30 s, and a machine whose psutil call was momentarily
    empty — which is normal while the kernel module is still loading — was
    written off for half a minute at a time. That is one of the reasons "it
    still cannot show the temperature" happened right after launch.
    """
    _state["cooldown"][method] = time.monotonic() + (
        5.0 if isinstance(error, LookupError) else _RETRY_AFTER)


def _ok(method: str) -> None:
    _state["cooldown"].pop(method, None)


# ── method 1: psutil (Linux, and Windows when a driver provides it) ─────────
def _from_psutil() -> tuple[float, str]:
    import psutil
    temps = psutil.sensors_temperatures() or {}
    for name in _PSUTIL_CPU:
        entries = temps.get(name) or []
        # Prefer a package/core label over an arbitrary first entry: many
        # bundles list a 'Composite' or an ambient chip first.
        for want in ("package", "tctl", "tdie", "core"):
            for e in entries:
                label = (getattr(e, "label", "") or "").lower()
                if want in label and _usable(e.current):
                    return float(e.current), f"psutil:{name}:{label or want}"
        for e in entries:
            if _usable(e.current):
                return float(e.current), f"psutil:{name}"
    # Anything at all rather than nothing, but of lower confidence.
    for name, entries in temps.items():
        for e in entries or []:
            if _usable(e.current):
                return float(e.current), f"psutil:{name}"
    raise LookupError("psutil exposes no temperature sensor here")


# ── method 2: Windows ACPI thermal zone, via one cached COM connection ─────
def _from_acpi() -> tuple[float, str]:
    import wmi  # type: ignore
    conn = _state.get("wmi")
    if conn is None:
        conn = wmi.WMI(namespace="root/wmi")
        _state["wmi"] = conn
    zones = conn.MSAcpi_ThermalZoneTemperature() or []
    if not zones:
        raise LookupError("no ACPI thermal zones")

    # WHICH ZONE IS THE CPU
    #   Zone order is firmware-specific. The old code took the first usable
    #   value, and on the machine that exposed this that was a 27.8 °C chassis
    #   zone — a number that never moved, which reads as "the sensor does not
    #   work" while a real 58 °C zone sat next to it. The CPU is the hottest
    #   thing ACPI reports in normal use, so the hottest plausible zone wins.
    #   A zone this reading already came from is preferred, so the figure does
    #   not jump between zones as load moves around.
    found = []
    for i, z in enumerate(zones):
        kelvin10 = getattr(z, "CurrentTemperature", None)
        if not kelvin10:
            continue
        c = (float(kelvin10) / 10.0) - 273.15
        if _usable(c):
            found.append((c, i))
    if not found:
        raise LookupError("ACPI zones report no usable temperature")

    remembered = _state.get("zone_index")
    pick = next((f for f in found if f[1] == remembered), None)
    if pick is None:
        # Prefer a zone above room temperature; within that, the hottest.
        warm = [f for f in found if f[0] >= 30.0] or found
        pick = max(warm, key=lambda f: f[0])
    c, idx = pick
    _state["zone_index"] = idx
    return c, f"acpi:zone{idx}"


# ── method 3: LibreHardwareMonitor / OpenHardwareMonitor local bridge ──────
# Both expose a small HTTP endpoint while running. Optional, and only trusted
# because the user installed a tool that exists to measure exactly this.
def _from_lhm() -> tuple[float, str]:
    import json
    import urllib.request
    for port in (8085, 8086):
        try:
            with urllib.request.urlopen(
                    f"http://127.0.0.1:{port}/data.json", timeout=0.6) as r:
                doc = json.loads(r.read().decode("utf-8", "replace"))
        except Exception:
            continue
        found = []

        def walk(node):
            if isinstance(node, dict):
                text = str(node.get("Text") or "")
                if text.lower() in ("cpu package", "core (tctl/tdie)", "cpu"):
                    val = node.get("Value")
                    if isinstance(val, str) and val.endswith("°C"):
                        try:
                            found.append(float(val.replace("°C", "").strip()))
                        except ValueError:
                            pass
                for child in node.get("Children") or []:
                    walk(child)
            elif isinstance(node, list):
                for child in node:
                    walk(child)

        walk(doc)
        found = [v for v in found if _usable(v)]
        if found:
            return max(found), f"lhm:{port}"
    raise LookupError("no hardware monitor is listening")


# ── method 4: Linux hwmon sysfs, read directly ─────────────────────────────
def _from_hwmon() -> tuple[float, str]:
    base = Path("/sys/class/hwmon")
    if not base.exists():
        raise LookupError("no hwmon on this system")
    candidates = []
    for d in base.iterdir():
        try:
            name = (d / "name").read_text().strip()
        except Exception:
            continue
        rank = next((i for i, k in enumerate(_HWMON_CPU) if k in name), None)
        if rank is None:
            continue
        for f in sorted(d.glob("temp*_input")):
            try:
                v = float(f.read_text().strip()) / 1000.0
            except Exception:
                continue
            if _usable(v):
                # A 'package' label wins over an anonymous core.
                label_file = f.with_name(f.name.replace("_input", "_label"))
                label = ""
                try:
                    label = label_file.read_text().strip().lower()
                except Exception:
                    pass
                score = rank - (2 if "package" in label or "tctl" in label else 0)
                candidates.append((score, v, f"{name}:{f.stem}:{label}" if label else f"{name}:{f.stem}"))
    if not candidates:
        raise LookupError("hwmon exposes no CPU temperature")
    candidates.sort(key=lambda t: t[0])
    return candidates[0][1], "hwmon:" + candidates[0][2]


# ── method 5: macOS SMC through powermetrics is a subprocess; skip it ──────
# `sysctl` has no CPU die temperature and powermetrics costs a process per
# read. Apple Silicon reports through psutil on recent versions, which is
# method 1. When it does not, the honest answer is "not available".

_METHODS = [
    ("psutil", _from_psutil),
    ("acpi",   _from_acpi),
    ("lhm",    _from_lhm),
    ("hwmon",  _from_hwmon),
]


def cpu_temp(detail: bool = False, max_age: float = 3.0):
    """(temp_c, source, confident) — temp_c is -1.0 when nothing answered.

    `confident` is False for a value that came from a fallback bundle or an
    unchanged ACPI zone: still the best number available, but the caller
    should not present it as exact.

    A reading younger than `max_age` seconds is reused. The HUD samples every
    two seconds and a question can arrive between samples; without this the
    same machine was probed twice for one answer, and a temperature does not
    change meaningfully in three seconds. Pass max_age=0 to force a probe.
    """
    with _lock:
        age = time.time() - _state["at"]
        if _state["temp"] > 0 and age < max_age:
            return _state["temp"], _state["source"], bool(_state.get("confident"))
        for name, fn in _METHODS:
            if _skip(name):
                continue
            try:
                value, source = fn()
            except Exception as e:
                _failed(name, e)
                continue
            if not _usable(value):
                _failed(name, LookupError("value outside a plausible range"))
                continue
            confident = "psutil:" in source or "package" in source or "tctl" in source
            if "acpi:" in source:
                confident = ":zone" in source
            if _flat_suspect(value):
                confident = False
            _ok(name)
            _state.update(source=source, temp=float(value), at=time.time(),
                          last_cpu=float(value), confident=bool(confident))
            return float(value), source, confident
        return -1.0, "", False


def last_known() -> tuple[float, str]:
    """The most recent successful reading, without probing. (-1.0, '') if none."""
    return _state["temp"], _state["source"]


def describe(temp: float, source: str, confident: bool) -> str:
    """One honest line about where a number came from."""
    if temp < 0:
        return "sensor unavailable"
    where = source.split(":")[0] if source else "unknown"
    return f"{temp:.1f}°C via {where}" + ("" if confident else " (approximate reading)")


def fan_rpms() -> list[int]:
    """Fan speeds when the platform exposes them; [] otherwise."""
    out: list[int] = []
    try:
        import psutil
        for entries in (psutil.sensors_fans() or {}).values():
            for e in entries or []:
                v = getattr(e, "current", None)
                if v:
                    out.append(int(v))
    except Exception:
        pass
    return out
